#!/bin/bash
cd ~/Downloads
sudo pacman -S --needed --noconfirm git base-devel
git clone https://aur.archlinux.org/paru-bin
cd paru-bin
makepkg -si
homedir=$HOME
if [ ! -d "${homedir}/.local/bin" ]; then
  mkdir ${homedir}/.local/bin
fi
paru -S --needed --noconfirm xdotool redshift git xpad xclip libappindicator-gtk3 wmctrl
cp ~/Downloads/Arch-Scripts-Xfce/bash-scripts/copy2clipboard.sh ~/.local/bin
exit 0
