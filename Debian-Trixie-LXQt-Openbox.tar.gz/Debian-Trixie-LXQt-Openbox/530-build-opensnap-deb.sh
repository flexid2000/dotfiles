#!/usr/bin/env bash
# =============================================================================
# build-opensnap-deb.sh
# Lädt opensnap vom GitHub-Master, kompiliert es und baut ein .deb-Paket.
# Getestet auf Ubuntu 22.04/24.04 und Debian 12 (Bookworm/Trixie).
# Benötigt: sudo-Rechte für apt-get
# =============================================================================

set -euo pipefail

# ── Konfiguration ─────────────────────────────────────────────────────────────
PKG_NAME="opensnap"
PKG_VERSION="0.1+git$(date +%Y%m%d)"   # Versionsnummer mit heutigem Datum
PKG_ARCH="$(dpkg --print-architecture)"
MAINTAINER="${MAINTAINER:-"$(id -un) <$(id -un)@localhost>"}"
DESCRIPTION="Aero-ähnliche Snap-Funktion für Openbox und EWMH-konforme WMs"
BUILD_DIR="$(mktemp -d --tmpdir opensnap-build.XXXXXX)"

# ── Farbige Ausgabe ───────────────────────────────────────────────────────────
info()    { echo -e "\e[1;34m[INFO]\e[0m  $*"; }
success() { echo -e "\e[1;32m[OK]\e[0m    $*"; }
error()   { echo -e "\e[1;31m[ERR]\e[0m   $*" >&2; exit 1; }

# ── Aufräumen bei Abbruch ─────────────────────────────────────────────────────
trap 'echo; error "Abgebrochen – temporäres Verzeichnis: $BUILD_DIR"' INT TERM
trap 'rm -rf "$BUILD_DIR"' EXIT

# ── 1. Abhängigkeiten installieren ────────────────────────────────────────────
info "Installiere Build-Abhängigkeiten …"
sudo apt-get -y install \
    build-essential \
    libx11-dev \
    libgtk-3-dev \
    pkg-config \
    wmctrl \
    unzip \
    wget \
    fakeroot \
    dpkg-dev

success "Abhängigkeiten installiert."

# ── 2. Quellcode herunterladen ────────────────────────────────────────────────
info "Lade opensnap-Quellcode von GitHub …"
wget -q --show-progress \
    -O "$BUILD_DIR/master.zip" \
    "https://github.com/lawl/opensnap/archive/master.zip"

info "Entpacke Archiv …"
unzip -q "$BUILD_DIR/master.zip" -d "$BUILD_DIR"

SRC_DIR="$BUILD_DIR/opensnap-master"
[[ -d "$SRC_DIR" ]] || error "Quellverzeichnis nicht gefunden: $SRC_DIR"

# ── 3. Kompilieren ────────────────────────────────────────────────────────────
info "Kompiliere opensnap …"
(
    cd "$SRC_DIR"
    make
)
success "Kompilierung abgeschlossen."

# ── 4. DEBIAN-Paketstruktur anlegen ──────────────────────────────────────────
STAGING="$BUILD_DIR/staging"
DEBIAN_DIR="$STAGING/DEBIAN"
info "Erstelle Paketstruktur in $STAGING …"

# Installationspfade
install -Dm0755 "$SRC_DIR/bin/opensnap"           "$STAGING/usr/bin/opensnap"
install -dm0755                                    "$STAGING/etc/opensnap"
for f in "$SRC_DIR"/sample_configs/*; do
    install -m0644 "$f" "$STAGING/etc/opensnap/$(basename "$f")"
done

# Dateigröße in kB (für control-Datei)
INSTALLED_SIZE=$(du -sk "$STAGING" | awk '{print $1}')

# ── 5. DEBIAN/control ─────────────────────────────────────────────────────────
mkdir -p "$DEBIAN_DIR"
cat > "$DEBIAN_DIR/control" <<EOF
Package: ${PKG_NAME}
Version: ${PKG_VERSION}
Architecture: ${PKG_ARCH}
Maintainer: ${MAINTAINER}
Installed-Size: ${INSTALLED_SIZE}
Depends: wmctrl, libx11-6, libgtk-3-0
Section: x11
Priority: optional
Homepage: https://github.com/lawl/opensnap
Description: ${DESCRIPTION}
 Opensnap ist ein leichtgewichtiger Daemon, der Windows-7-ähnliches
 Fenster-Snapping für Openbox und andere EWMH-konforme Fenstermanager
 bereitstellt. Fenster werden automatisch an Bildschirmränder eingerastet,
 wenn sie dorthin gezogen werden.
EOF

# ── 6. DEBIAN/conffiles (Konfigurationsdateien nicht überschreiben) ───────────
find "$STAGING/etc" -type f \
    | sed "s|$STAGING||" \
    > "$DEBIAN_DIR/conffiles"

# ── 7. DEBIAN/postinst (Hinweis nach Installation) ───────────────────────────
cat > "$DEBIAN_DIR/postinst" <<'POSTINST'
#!/bin/sh
set -e
echo ""
echo "opensnap wurde installiert."
echo "Starten Sie es mit:  opensnap"
echo "Als Daemon:          opensnap --deamon"
echo ""
echo "Benutzerkonfiguration:"
echo "  mkdir -p ~/.config/opensnap"
echo "  cp /etc/opensnap/* ~/.config/opensnap/"
echo ""
POSTINST
chmod 0755 "$DEBIAN_DIR/postinst"

# ── 8. DEBIAN/postrm (Aufräumen nach Deinstallation) ─────────────────────────
cat > "$DEBIAN_DIR/postrm" <<'POSTRM'
#!/bin/sh
set -e
if [ "$1" = "purge" ] && [ -d /etc/opensnap ]; then
    rm -rf /etc/opensnap
fi
POSTRM
chmod 0755 "$DEBIAN_DIR/postrm"

# ── 9. md5sums generieren ─────────────────────────────────────────────────────
(
    cd "$STAGING"
    find . -type f ! -path './DEBIAN/*' -exec md5sum {} \; \
        | sed 's|\./||' \
        > DEBIAN/md5sums
)

# ── 10. .deb bauen ────────────────────────────────────────────────────────────
DEB_FILE="${PKG_NAME}_${PKG_VERSION}_${PKG_ARCH}.deb"
info "Baue Debian-Paket: $DEB_FILE …"
fakeroot dpkg-deb --build "$STAGING" "$DEB_FILE"

success "Paket erfolgreich erstellt: $(pwd)/$DEB_FILE"
echo
echo "  Installieren:    sudo dpkg -i $DEB_FILE"
echo "  Paketinfos:      dpkg-deb -I $DEB_FILE"
echo "  Paketinhalt:     dpkg-deb -c $DEB_FILE"
