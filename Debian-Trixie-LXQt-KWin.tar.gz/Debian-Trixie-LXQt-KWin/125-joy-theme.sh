#!/bin/bash
sudo update-alternatives --set desktop-background /usr/share/desktop-base/joy-theme/wallpaper/contents/images/1920x1080.svg
sudo update-alternatives --set desktop-background.xml /usr/share/desktop-base/joy-theme/wallpaper/gnome-background.xml
sudo update-alternatives --set desktop-grub /usr/share/desktop-base/joy-theme/grub/grub-16x9.png
sudo update-alternatives --set desktop-lockscreen.xml /usr/share/desktop-base/joy-theme/lockscreen/gnome-background.xml
sudo update-alternatives --set desktop-login-background /usr/share/desktop-base/joy-theme/login/background.svg
sudo update-alternatives --set  desktop-plasma5-wallpaper /usr/share/desktop-base/joy-theme/wallpaper
sudo update-alternatives --set desktop-theme /usr/share/desktop-base/joy-theme
sudo convert /usr/share/desktop-base/joy-theme/login/background.svg /usr/share/plymouth/themes/spinner/background-tile.png
sudo plymouth-set-default-theme -R spinner
exit 0

