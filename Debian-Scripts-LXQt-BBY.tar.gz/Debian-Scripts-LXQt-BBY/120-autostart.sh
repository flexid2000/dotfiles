#!/bin/bash
homedir=$HOME
if [ ! -d "${homedir}/.config/autostart" ]; then
  mkdir ~/.config/autostart
fi
cp autostart/*.desktop ~/.config/autostart
exit 0
