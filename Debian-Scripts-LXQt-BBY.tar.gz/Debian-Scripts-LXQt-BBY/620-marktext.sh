#!/bin/bash
wget https://github.com/marktext/marktext/releases/latest/download/marktext-x86_64.AppImage
if [ ! $HOME/.local/bin ] ; then
	mkdir -p ~/.local/bin
fi
mv marktext-x86_64.AppImage ~/.local/bin
chmod 755 ~/.local/bin/marktext-x86_64.AppImage
if [ ! $HOME/.local/share/applications ] ; then
	mkdir -p ~/.local/share/applications
fi
wget https://github.com/probonopd/go-appimage/releases/download/continuous/appimaged-650-x86_64.AppImage
mv appimaged-650-x86_64.AppImage ~/.local/bin
chmod 755 ~/.local/bin/appimaged-650-x86_64.AppImage
~/.local/bin/appimaged-650-x86_64.AppImage
exit 0
