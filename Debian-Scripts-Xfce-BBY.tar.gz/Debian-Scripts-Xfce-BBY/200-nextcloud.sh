#!/bin/bash
sudo apt -y install gvfs-fuse gvfs-backends gnome-keyring nextcloud-desktop
sudo modprobe fuse
sudo groupadd fuse
sudo usermod -aG fuse $USER
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
exit 0
