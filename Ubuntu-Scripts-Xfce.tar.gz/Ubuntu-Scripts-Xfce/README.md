## Bester Ubuntu-Mirror
2022-02-16  
`ftp.stw-bonn.de`

## Zeit einstellen
`$ timedatectl set-timezone Europe/Berlin`

