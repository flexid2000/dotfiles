#!/bin/bash
pandoc "$1" \
    -o "${1%.md}".pdf \
	-f markdown+emoji \
	-t html5 \
	-s \
    --pdf-engine=wkhtmltopdf \
    --css=$HOME/.local/bin/wkhtmltopdf.css \
    --pdf-engine-opt="--disable-smart-shrinking" \
	--pdf-engine-opt="-L" \
	--pdf-engine-opt="15mm" \
	--pdf-engine-opt="-R" \
	--pdf-engine-opt="15mm" \
	--pdf-engine-opt="-T" \
	--pdf-engine-opt="15mm" \
	--pdf-engine-opt="-B" \
	--pdf-engine-opt="15mm" \
	--pdf-engine-opt="--footer-center" \
	--pdf-engine-opt="[page]" \
	--pdf-engine-opt="--footer-font-size" \
	--pdf-engine-opt="11" \
	--lua-filter=pagebreak.lua \
    --metadata pagetitle="${1%.md}" \
    --metadata lang=de
exit 0
