#!/bin/bash

sudo apt-get -y install --no-install-recommends qml-module-qtquick-layouts qml-module-qtquick-controls2 qml-module-qtquick-window2 libqt6svg6 git desktop-base librsvg2-bin imagemagick papirus-icon-theme breeze-cursor-theme unzip
sudo sed -i 's/=5/=0/' /etc/default/grub
sudo sed -i '/GRUB_TIMEOUT=0/a GRUB_TIMEOUT_STYLE=hidden' /etc/default/grub
magick -size 16x9 xc:'#000000' -density 72 grub-16x9.png
magick -size 4x3 xc:'#000000' -density 72 grub-4x3.png
sudo mv grub-4x3.png grub-16x9.png /usr/share/desktop-base/active-theme/grub
sudo update-grub

# Set Default Stop Time to 20 sec

sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf

# SDDM Theme

wget https://github.com/catppuccin/sddm/releases/download/v1.1.2/catppuccin-macchiato-blue-sddm.zip
sudo unzip catppuccin-macchiato-blue-sddm.zip -d /usr/share/sddm/themes
sudo  magick -size 1920x1080 -density 300 xc:none /usr/share/sddm/themes/catppuccin-macchiato-blue/backgrounds/wall.png
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
sudo sed -i 's/CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo sed -i 's/^Current=.*/Current=catppuccin-macchiato-blue/' /etc/sddm.conf
sudo sed -i 's/^InputMethod=qtvirtualkeyboard/InputMethod=/' /etc/sddm.conf

if [ ! -d "$HOME/Bilder/artwork" ]; then
  mkdir -p ~/Bilder/artwork
fi
cp artwork/hashtags.png ~/Bilder/artwork

exit 0

