#!/bin/bash
sudo apt update && sudo apt -y full-upgrade
sudo apt-get -y install apt-file copyq curl fonts-firacode fonts-font-awesome foot foot-themes gammastep git grim hyprpicker isenkram-cli kanshi labwc libappindicator3-1 libvirglrenderer1 lxqt-wayland-session mako-notifier pipewire-audio qdbus-qt6 ranger rofi slurp swaybg swayidle swaylock systemd-zram-generator vim wayland-utils wdisplays wget wl-clipboard wlogout wlopm wlr-randr wlrctl xdg-desktop-portal-wlr
sudo apt -y purge pulseaudio-module-bluetooth pulseaudio ofono
systemctl --user --now enable wireplumber.service
sudo isenkram-autoinstall-firmware
exit 0
