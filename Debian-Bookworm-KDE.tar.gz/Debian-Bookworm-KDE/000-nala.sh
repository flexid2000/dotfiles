#"/bin/bash
pkgver=0.15.2
sudo apt-get -y install nala curl git vim aria2
sudo nala fetch
sudo nala update
sudo nala full-upgrade
# install apt-fast
# sudo /bin/bash -c "$(curl -sL https://git.io/vokNn)"
exit 0

