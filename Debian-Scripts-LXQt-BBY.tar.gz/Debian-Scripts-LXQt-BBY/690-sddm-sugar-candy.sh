#!/bin/bash
sudo apt-fast -y install --no-install-recommends sddm qml-module-qtquick-layouts qml-module-qtgraphicaleffects qml-module-qtquick-controls2 libqt5svg5
wget https://framagit.org/MarianArlt/sddm-sugar-candy/-/archive/master/sddm-sugar-candy-master.tar.gz
mv sddm-sugar-candy-master.tar.gz sugar-candy.tar.gz
sudo tar -xzvf sugar-candy.tar.gz -C /usr/share/sddm/themes
exit 0
