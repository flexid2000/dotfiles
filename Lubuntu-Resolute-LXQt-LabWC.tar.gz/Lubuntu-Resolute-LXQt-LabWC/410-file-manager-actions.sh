#!/bin/bash
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
cp file-manager-actions/custom-reference.odt ~/.local/share/pandoc
cp file-manager-actions/pagebreak.lua ~/.local/share/pandoc/filters
cp file-manager-actions/*.sh file-manager-actions/*.css ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
exit 0
