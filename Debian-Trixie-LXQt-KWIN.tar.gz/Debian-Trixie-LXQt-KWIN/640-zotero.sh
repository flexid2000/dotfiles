#!/bin/bash
curl -sL https://raw.githubusercontent.com/retorquere/zotero-deb/master/install.sh | sudo bash
sudo apt-get update
sudo apt-get -y install zotero
exit 0
