#!/bin/bash
sudo apt update && sudo apt -y full-upgrade
sudo apt-get -y install apt-file conky curl fonts-firacode fonts-font-awesome git grim isenkram-cli picom pipewire-audio systemd-zram-generator vim wget
sudo apt -y purge pulseaudio-module-bluetooth pulseaudio ofono
systemctl --user --now enable wireplumber.service
sudo isenkram-autoinstall-firmware
exit 0
