#!/bin/bash

set -eu

# Aurowaita Fensterdekoration
git clone https://github.com/sabaneko-run/aurowaita.git
cd aurowaita
mkdir -p ~/.local/share/aurorae/themes/
cp -r src/* ~/.local/share/aurorae/themes/
cd ..
sudo rm -r aurowaita

# Adwaita Theme 
sudo pacman -S --needed --noconfirm adw-gtk-theme gnome-themes-extra

# Kvantum Adwaita Theme
paru -S --needed kvantum-theme-libadwaita-git kvantum

