#!/bin/bash
if [ ! -d "$HOME/.config/gtk-3.0" ]; then
    mkdir -p ~/.config/gtk-3.0
fi
echo "gtk-decoration-layout=close,minimize,maximize:menu" >> ~/.config/gtk-3.0/settings.ini
exit 0
