#!/bin/bash

set -e  # Skript bei Fehler beenden

echo "📦 Installiere benötigte Pakete ..."
sudo apt-get update
sudo apt-get install -y \
    git sddm-theme-breeze desktop-base librsvg2-bin imagemagick \
    papirus-icon-theme arc-kde qt6-style-kvantum

echo "⚙️ Konfiguriere GRUB ..."
sudo sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT="3"/' /etc/default/grub
sudo sed -i 's/^GRUB_TIMEOUT_STYLE=.*/GRUB_TIMEOUT_STYLE="menu"/' /etc/default/grub
sudo sed -i '/^#GRUB_GFXMODE/c\
GRUB_GFXMODE="1024x768x32"\
GRUB_GFXPAYLOAD_LINUX="keep"\
GRUB_BACKGROUND="/usr/share/desktop-base/joy-theme/grub/grub-16x9.png"' /etc/default/grub
sudo update-grub

echo "🕐 Setze DefaultTimeoutStopSec auf 20s ..."
sudo sed -i 's/^#DefaultTimeoutStopSec=.*$/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf

echo "🖼️ Konfiguriere SDDM ..."
sddm --example-config | sudo tee /etc/sddm.conf > /dev/null
sudo sed -i 's/^CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo sed -i 's/^InputMethod=qtvirtualkeyboard/InputMethod=/' /etc/sddm.conf

echo "📁 Erstelle Artwork-Verzeichnis, falls nötig ..."
mkdir -p "$HOME/Bilder/artwork"
cp artwork/bby-wallpaper-shortcuts.png "$HOME/Bilder/artwork/"

echo "🎨 Erstelle Breeze-No-Blur-Theme für SDDM ..."
sudo cp -r /usr/share/sddm/themes/breeze /usr/share/sddm/themes/breeze-no-blur
sudo chown -R root:root /usr/share/sddm/themes/breeze-no-blur
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze-no-blur/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze-no-blur/' /etc/sddm.conf

echo "📄 Schreibe theme.conf.user für breeze-no-blur ..."
sudo tee /usr/share/sddm/themes/breeze-no-blur/theme.conf.user > /dev/null <<EOF
[General]
background=/usr/share/desktop-base/joy-theme/login/background.svg
type=image
EOF

echo "👤 Setze individuelles Benutzer-Icon ..."
sudo rm -f /usr/share/sddm/faces/.face.icon
rsvg-convert -a -w 144 -f svg /usr/share/icons/Papirus/22x22@2x/apps/distributor-logo-debian.svg -o /tmp/face.svg
mv /tmp/face.svg ~/.face.icon
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon

echo "🔐 Setze Berechtigungen für SDDM auf Benutzericon ..."
setfacl -m u:sddm:x "$HOME"
setfacl -m u:sddm:r "$HOME/.face.icon"

echo "✅ Alles erledigt."
exit 0


