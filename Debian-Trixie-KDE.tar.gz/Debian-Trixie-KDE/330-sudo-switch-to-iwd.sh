#!/bin/bash
# Robustes Skript für Wechsel zu iwd (Debian Trixie/KDE Plasma 6)
# Behandelt alle Sonderfälle korrekt
# Als root/sudo ausführen!

set -e  # Abbruch bei kritischen Fehlern

# 1. iwd installieren (Internet benötigt)
echo "=== Installiere iwd ==="
apt update
apt install -y iwd

# 2. wpa_supplicant nur deaktivieren, falls vorhanden
echo "=== Behandle wpa_supplicant ==="
if dpkg -l | grep -q wpa_supplicant; then
    echo "wpa_supplicant gefunden - deaktiviere..."
    systemctl disable --now wpa_supplicant 2>/dev/null || true

    # Optional entfernen (nur wenn keine Abhängigkeiten)
    echo "Prüfe Abhängigkeiten..."
    if ! apt-cache rdepends --installed wpa_supplicant | grep -qv "^ "; then
        echo "Deinstalliere wpa_supplicant..."
        apt purge -y wpa_supplicant
    else
        echo "wpa_supplicant wird benötigt - belassen."
    fi
else
    echo "wpa_supplicant nicht installiert - überspringe."
fi

# 3. NetworkManager konfigurieren (komplett neuer Ansatz)
echo "=== Konfiguriere NetworkManager ==="
# Sicherung der originalen Konfiguration
cp /etc/NetworkManager/NetworkManager.conf /etc/NetworkManager/NetworkManager.conf.bak

# Neue Konfiguration erstellen
{
    # [main]-Abschnitt beibehalten oder neu erstellen
    if grep -q "^\[main\]" /etc/NetworkManager/NetworkManager.conf; then
        sed -n '/^\[main\]/,/^\[/p' /etc/NetworkManager/NetworkManager.conf | head -n -1
    else
        echo "[main]"
        echo "plugins=ifupdown,keyfile"
    fi

    # [ifupdown]-Abschnitt beibehalten oder mit managed=false erstellen
    if grep -q "^\[ifupdown\]" /etc/NetworkManager/NetworkManager.conf; then
        sed -n '/^\[ifupdown\]/,/^\[/p' /etc/NetworkManager/NetworkManager.conf | head -n -1
    else
        echo "[ifupdown]"
        echo "managed=false"
    fi

    # [device]-Abschnitt mit iwd Backend
    echo "[device]"
    echo "wifi.backend=iwd"

    # Alle anderen Abschnitte übernehmen
    grep -Ev "^\[(main|ifupdown|device)\]" /etc/NetworkManager/NetworkManager.conf
} > /tmp/nm.conf && mv /tmp/nm.conf /etc/NetworkManager/NetworkManager.conf

# 4. Dienste neu starten
echo "=== Aktiviere Dienste ==="
systemctl enable --now iwd
systemctl restart NetworkManager

# 5. Statusbericht
echo -e "\n=== Fertig! Statusübersicht ==="
echo "NetworkManager Konfiguration:"
grep -A1 "^\[" /etc/NetworkManager/NetworkManager.conf
echo -e "\nAktive Dienste:"
systemctl status iwd NetworkManager --no-pager | grep -E "Active:|Loaded:"
echo -e "\nVerfügbare WLANs:"
nmcli device wifi list || echo "WLAN-Liste konnte nicht abgerufen werden"

