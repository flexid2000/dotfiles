#!/bin/bash
set -e

echo "🎨 Installiere Kvantum für Qt6 ..."
sudo apt-get purge -y qt5-style-kvantum qt5-style-kvantum-l10n qt5-style-quantum-themes

wget http://de.archive.ubuntu.com/ubuntu/pool/universe/q/qt6-style-kvantum/qt6-style-kvantum_1.1.2-0ubuntu1_amd64.deb
wget http://de.archive.ubuntu.com/ubuntu/pool/universe/q/qt6-style-kvantum/qt6-style-kvantum-l10n_1.1.2-0ubuntu1_all.deb
wget http://de.archive.ubuntu.com/ubuntu/pool/universe/q/qt6-style-kvantum/qt6-style-kvantum-themes_1.1.2-0ubuntu1_all.deb

sudo dpkg -i qt6-style-kvantum_*.deb
rm qt6-style-kvantum_*.deb

echo "✅ Kvantum Qt6 installiert."

