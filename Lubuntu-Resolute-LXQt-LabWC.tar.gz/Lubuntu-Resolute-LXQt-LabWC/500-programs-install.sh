#!/bin/bash
sudo apt-get update
sudo apt-get -y install accountsservice acpid alsa-firmware-loaders arj audacious bleachbit blueman bluetooth bluez-cups bluez-obexd bluez-tools breeze-cursor-theme cabextract conky-std copyq cups cups-browsed cups-client cups-common cups-core-drivers cups-filters cups-filters-core-drivers cups-ipp-utils cups-pk-helper cups-ppdc cups-server-common curl dkms exfalso faad ffmpeg ffmpegthumbnailer ffmpegthumbs flac flvstreamer fonts-cantarell fonts-croscore fonts-firacode fonts-font-awesome fonts-inconsolata fonts-open-sans fonts-roboto foot foot-themes fsearch galternatives ghostwriter gimp git graphicsmagick grsync haveged htop hunspell hunspell-de-de hwinfo hyphen-de icoextract-thumbnailer inkscape lame libcanberra-pulse libgpod-dev libgsf-bin libgsf-bin libimobiledevice-dev libnotify-bin libreoffice libreoffice-l10n-de libslf4j-java lxqt-archiver menu-xdg meteo-qt mjpegtools mpv mtp-tools mythes-de network-manager-gnome nextcloud-desktop numlockx pandoc paper-icon-theme papirus-icon-theme pdfarranger plocate plymouth-themes poppler-utils pwgen python3-pyinotify qpdfview qt5-style-kvantum seahorse shotwell skanpage strawberry subversion task-german-desktop task-laptop transmission-qt ttf-bitstream-vera ttf-mscorefonts-installer tumbler tumbler-plugins-extra unace unclutter unrar vim vlc vorbis-tools wavpack weasyprint wmctrl wv wx-common xbindkeys zip
sudo dpkg -i binaries/labconf* binaries/labwc*
sudo systemctl enable bluetooth.service
sudo systemctl start bluetooth.service
sudo sed -i 's/'#AutoEnable=false'/'AutoEnable=true'/g' /etc/bluetooth/main.conf
sudo systemctl enable acpid.service
exit 0
