#!/bin/bash
homedir=$HOME
cd confiles
if [ ! -d "${homedir}/.config/conky" ]; then
  mkdir -p ${homedir}/.config/conky
fi
cp conky.conf ~/.config/conky
cp redshift.conf ~/.config
if [ ! -d "${homedir}/.config/yt-dlp" ]; then
  mkdir ${homedir}/.config/yt-dlp
fi
cp config ~/.config/yt-dlp
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>w" --create --type string --set "exo-open --launch WebBrowser"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>m" --create --type string --set "exo-open --launch MailReader"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>t" --create --type string --set "exo-open --launch TerminalEmulator"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>f" --create --type string --set "exo-open --launch FileManager"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>e" --create --type string --set "geany"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>l" --create --type string --set "libreoffice --writer --nologo"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>x" --create --type string --set "xfce4-session-logout"
exit 0
