#!/bin/bash
sudo apt-fast -y install systemd-zram-generator systemd-boot
exit 0
