#!/bin/bash
mogrify -background white -alpha remove -alpha off -resize '1102x620>' -density '100x100' $@
img2pdf -o converted.pdf --fit into --pagesize 280mmx157.5mm $@
rm *~
exit 0
