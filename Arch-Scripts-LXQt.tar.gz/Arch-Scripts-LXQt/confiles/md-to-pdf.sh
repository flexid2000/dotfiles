#!/bin/bash
for FILE in "$@"; do
	md-to-pdf --stylesheet ~/.local/bin/stylesheet.css "${FILE}"
done
exit 0

