#!/bin/bash
sudo pacman -S --needed base-devel git accountsservice haveged nano
sudo systemctl enable accounts-daemon.service
sudo systemctl enable haveged.service
git clone https://aur.archlinux.org/paru-bin
cd paru-bin
makepkg -si
exit 0
