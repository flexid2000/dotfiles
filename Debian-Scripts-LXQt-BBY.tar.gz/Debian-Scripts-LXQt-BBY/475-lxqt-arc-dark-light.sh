#!/bin/bash
git clone https://gitlab.com/isseigx/lxqt-arc-dark-theme.git
if [ ! -d /usr/share/lxqt/themes/arc-dark ]; then
		sudo mkdir -p /usr/share/lxqt/themes/arc-dark
fi
sudo cp -r lxqt-arc-dark-theme/arc-dark/* /usr/share/lxqt/themes/arc-dark/
sudo rm -R lxqt-arc-dark-theme
git clone https://github.com/sparkylinux/sparky-lxqt-theme.git
if [ ! -d /usr/share/lxqt/themes/sparky ]; then
		sudo mkdir -p /usr/share/lxqt/themes/sparky
fi
sudo cp -r sparky-lxqt-theme/sparky/* /usr/share/lxqt/themes/sparky/
sudo rm -R sparky-lxqt-theme
wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/arc-kde/master/install.sh | sh
exit 0

