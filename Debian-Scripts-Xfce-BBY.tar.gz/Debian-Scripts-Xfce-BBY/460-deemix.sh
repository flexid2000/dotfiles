#!/bin/bash
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
cd ~/.local/bin
sudo apt-fast -y install wget
wget https://www.dropbox.com/s/odn4tnu9cqlmq8h/deemix-linux-x64.AppImage?dl=0
mv deemix-linux-x64.AppImage?dl=0 deemix-linux-x64.AppImage
chmod 755 deemix-linux-x64.AppImage
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
exit 0

