#!/bin/bash
set -euo pipefail

# Farben
RED="\033[1;31m"; GREEN="\033[1;32m"; YELLOW="\033[1;33m"; RESET="\033[0m"

# Funktion zum Bestätigen
confirm() {
  echo -en "${YELLOW}$1 [j/N]: ${RESET}"
  read -r reply
  [[ "$reply" =~ ^[JjYy]$ ]]
}

# 1. Vorbereitung
echo -e "${GREEN}1. Systemaktualisierung (Bookworm)${RESET}"
sudo apt update
sudo apt upgrade -y
sudo apt full-upgrade -y
sudo apt autoremove -y

# 1a. Root-Passwort setzen
echo "${YELLOW}=== Root-Passwort setzen ===${RESET}"
sudo passwd root

# 2. Essenzielle Pakete sichern
echo "${YELLOW}=== Installiere essentielle Pakete ===${RESET}"
sudo apt-get update
sudo apt-get install -y sudo network-manager wpasupplicant

# 3. LXQt deinstallieren
echo "${GREEN}=== LXQt Deinstallation ===${RESET}"
read -p "${YELLOW}LXQt deinstallieren? (j/n)${RESET} " answer
if [[ $answer =~ ^[Jj] ]]; then
    sudo apt --auto-remove purge liblxqt* lximage-qt* lxqt lxqt* pavucontrol-qt task-lxqt-desktop pcmanfm-qt* libfm-qt12
fi

# 3a. Entfernen obsoleter Pakete
echo -e "${GREEN}1. Suche nach obsoleten Paketen${RESET}"
OBSOLETE=$(apt list '~o' 2>/dev/null | grep -v "Listing..." || true)

if [ -n "$OBSOLETE" ]; then
  echo -e "${YELLOW}Gefundene obsolet gewordene Pakete:${RESET}"
  echo "$OBSOLETE"

  # Paketnamen extrahieren (alles vor dem ersten Slash)
  PKGNAMES=$(echo "$OBSOLETE" | cut -d/ -f1)

  echo
  sudo apt purge $PKGNAMES
else
  echo "Keine obsoleten Pakete gefunden."
fi

# 3b. Nicht-Debian-Pakete entfernen
if ! command -v apt-show-versions &> /dev/null; then
  echo "apt-show-versions wird installiert..."
  sudo apt-get update
  sudo apt-get install -y apt-show-versions
fi

echo "Nicht-Debian-Pakete werden gesucht..."

local_pkgs=$(apt-show-versions | grep "No available version" | awk '{print $1}')

echo "${GREEN}Nicht-Debian-Pakte entfernen?${RESET}"

sudo apt-get purge $local_pkgs

# 4. Quellen auf Trixie umstellen
echo -e "${GREEN}4. /etc/apt/sources.list auf Trixie umstellen${RESET}"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo sed -i 's/bookworm/trixie/g' /etc/apt/sources.list

# 5. Neue Paketlisten
echo -e "${GREEN}5. Neue Paketlisten einlesen${RESET}"
sudo apt update

# 6. Minimal-Upgrade
echo -e "${GREEN}6. Minimal-Upgrade (ohne neue Pakete)${RESET}"
sudo apt upgrade --without-new-pkgs

# 7. Volles Upgrade
echo -e "${GREEN}7. Volles System-Upgrade${RESET}"
sudo apt full-upgrade

# 8. Aufräumen, 2. Purgen obsoleter Pakete
echo -e "${GREEN}8. Aufräumen nach dem Upgrade${RESET}"
sudo apt autoremove --purge

echo -e "${GREEN}1. Suche nach obsoleten Paketen${RESET}"
OBSOLETE=$(apt list '~o' 2>/dev/null | grep -v "Listing..." || true)

if [ -n "$OBSOLETE" ]; then
  echo -e "${YELLOW}Gefundene obsolet gewordene Pakete:${RESET}"
  echo "$OBSOLETE"

  # Paketnamen extrahieren (alles vor dem ersten Slash)
  PKGNAMES=$(echo "$OBSOLETE" | cut -d/ -f1)

  echo
  sudo apt purge $PKGNAMES
else
  echo "Keine obsoleten Pakete gefunden."
fi

echo -e "${GREEN}8b. Entfernte, aber nicht gepurgte Pakete${RESET}"

REMOVED=$(dpkg -l | awk '/^rc/ { print $2 }')
if [ -n "$REMOVED" ]; then
  echo -e "${YELLOW}Purge für folgende entfernte Pakete:${RESET}"
  echo "$REMOVED"
  echo "$REMOVED" | xargs sudo apt purge
else
  echo "Keine entfernten Konfigurationsreste gefunden."
fi

# 9. Reboot-Vorschlag
echo -e "${GREEN}Upgrade abgeschlossen. Starte das System neu.${RESET}"
confirm "Jetzt neu starten?" && sudo reboot

