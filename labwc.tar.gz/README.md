## Installieren

paru -S --needed alacritty cliphist greetd greetd-agreety grim kanshi labwc libappindicator-gtk3 mako mesa network-manager-applet nwg-look pavucontrol-qt pcmanfm-qt power-profiles-daemon rofi-wayland slurp swaybg swayidle swaylock swaync virglrenderer vulkan-intel waybar wl-clipboard wlogout wlopm wlroots woff2-font-awesome

## Anmerkungen

ngw-look: GUI für die Konfiguration des Erscheinungsbilds

## Herunterladen

wget https://github.com/flexid2000/dotfiles/raw/refs/heads/master/labwc.tar.gz

## Entpacken

tar -xzf labwc.tar.gz
