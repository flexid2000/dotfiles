#!/bin/bash
wget https://github.com/probonopd/go-appimage/releases/download/continuous/appimaged-650-x86_64.AppImage
mv appimaged-650-x86_64.AppImage ~/.local/bin
chmod 755 ~/.local/bin/appimaged-650-x86_64.AppImage
~/.local/bin/appimaged-650-x86_64.AppImage
exit 0
