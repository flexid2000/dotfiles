#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget -qO- https://www.dropbox.com/scl/fi/yyrz4mydrlseepc2hi4d8/deemix-linux-x64.deb > deemix.deb
sudo dpkg -i deemix.deb
sudo nala install volumeicon-alsa pipewire pipewire-audio pipewire-alsa gstreamer1.0-pipewire vlc-plugin-pipewire pipewire-pulse pavucontrol-qt
sudo nala purge pulseaudio-alsa pulseaudio-bluetooth pulseaudio gstreamer1.0-pulseaudio
systemctl --user --now enable wireplumber.service
sudo apt-fast -t bookworm-backports install yt-dlp
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
