#!/bin/bash
sudo pacman -S spice-vdagent xf86-video-qxl spice-gtk --needed
if [ ! -d "$HOME/shared" ]; then
  mkdir -p ~/shared
fi
if ! grep "sharepoint" /etc/fstab; then
	sudo sh -c "printf '/sharepoint\t/home/kay/shared\t9p\ttrans=virtio,version=9p2000.L,rw\t0\t0\n' >> /etc/fstab"
fi
# Set SDDM login screen to fullscreen
if ! grep "xrandr" /usr/share/sddm/scripts/Xsetup; then
	sudo sh -c "printf 'xrandr --output \"Virtual-1\" --mode 1920x1080 --rate 60.00' >> /usr/share/sddm/scripts/Xsetup"
fi
printf '[Desktop Entry]\nExec=xrandr --output \"Virtual-1\" --mode 1920x1080 --rate 60.00\nName=Fullscreen\nType=Application\nVersion=1.0' > ~/.config/autostart/fullscreen.desktop
exit 0
