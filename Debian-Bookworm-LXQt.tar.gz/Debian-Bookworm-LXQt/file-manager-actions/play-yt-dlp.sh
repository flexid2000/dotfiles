#!/bin/bash
LINK=$1
yt-dlp -f "best[height<=?720]" -o - $LINK | mpv --title="Play with yt-dlp" -
exit 0
