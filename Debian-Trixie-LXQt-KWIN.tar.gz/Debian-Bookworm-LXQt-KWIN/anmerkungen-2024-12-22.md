## Anmerkungen

- Datum: 23.12.2024
- Debian 13 (Trixie)
- In den Repositories fehlen:
    - gimp
    - gimp-plugin-repository
    - speedcrunch
    - software-properties-gtk  
- `730-qemu-shared-folder` führt zu Bootversagen
- Kurzbefehle für `KWIN` funktionieren nicht
- `kvantum-qt6` noch nicht vorhanden
- Alternative: `Qt-Stil`: `Fusion`  
	Thema: `Frost`

