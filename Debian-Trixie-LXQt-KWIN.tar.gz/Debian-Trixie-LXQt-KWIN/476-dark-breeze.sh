#!/bin/bash
git clone https://www.opencode.net/nudnik/lxqt-theme-dark-breeze-by-nudnik.git
mkdir -p ~/.local/share/lxqt/themes
tar -xzf lxqt-theme-dark-breeze-by-nudnik/Dark_Breeze_by_Nudnik.tar.gz -C ~/.local/share/lxqt/themes
exit 0

