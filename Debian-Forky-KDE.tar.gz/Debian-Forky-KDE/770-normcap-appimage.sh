#!/bin/bash

set -e

pkgver=0.6.0
sudo apt update
sudo apt -y install libfuse2t64 wl-clipboard
wget https://github.com/dynobo/normcap/releases/download/v$pkgver/NormCap-$pkgver-x86_64.AppImage
mv NormCap-$pkgver-x86_64.AppImage $HOME/.local/bin/
chmod 755 $HOME/.local/bin/NormCap-$pkgver-x86_64.AppImage
tee $HOME/.local/share/applications/normcap.desktop > /dev/null <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NormCap
Comment=OCR von Screenshot
Exec=$HOME/.local/bin/NormCap-$pkgver-x86_64.AppImage
Icon=normcap
Categories=Graphics;
Terminal=false
StartupWMClass=normcap
EOF
exit 0
