#!/bin/bash
pkgver=0.17.1
wget https://github.com/marktext/marktext/releases/download/v${pkgver}/marktext-x86_64.AppImage
chmod 755 marktext-x86_64.AppImage
./marktext-x86_64.AppImage --appimage-extract
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
cp squashfs-root/marktext.desktop ~/.local/share/applications
rm -r squashfs-root
mv marktext-x86_64.AppImage ~/.local/bin
sed -i 's/AppRun \-\-no-sandbox %U/\$\{HOME\}\/.local\/bin\/marktext-x86_64.AppImage \-\-no\-sandbox %F/g' ~/.local/share/applications/marktext.desktop
sudo apt-get install npm
sudo npm install picgo -g
picgo upload /usr/share/xml/docbook/stylesheet/docbook-xsl/images/callouts/1.png
cp confiles/config.json ~/.picgo
firefox-esr https://smms.app
exit 0

