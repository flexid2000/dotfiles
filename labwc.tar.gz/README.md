## Installieren

paru -S --needed pcmanfm-qt kanshi waybar labwc mako network-manager-applet swayidle swaylock wlopm wlroots virglrenderer mesa vulkan-intel wlogout pavucontrol-qt power-profiles-daemon woff2-font-awesome libappindicator-gtk3 wofi swaybg grim slurp wl-clipboard alacritty greetd greetd-agreety

## Herunterladen

wget https://github.com/flexid2000/dotfiles/raw/refs/heads/master/labwc.tar.gz

## Entpacken

tar -xzf labwc.tar.gz
