#!/bin/bash
sudo apt-fast -y install python3-setuptools
wget https://bootstrap.pypa.io/get-pip.py
sudo python3 get-pip.py
rm get-pip.py
pip3 install --user img2pdf
sudo ln -s $HOME/.local/bin/img2pdf /usr/local/bin/img2pdf
exit 0
