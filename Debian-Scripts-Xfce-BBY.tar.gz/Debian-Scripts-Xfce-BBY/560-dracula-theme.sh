#!/bin/bash
sudo apt -y install git arc-theme qt5-style-kvantum faba-icon-theme moka-icon-theme papirus-icon-theme
mkdir -p dracula-tmp
cd dracula-tmp
git clone https://github.com/dracula/gtk.git
mv gtk Dracula
sudo mkdir -p /usr/share/Kvantum
sudo cp -r Dracula/kde/kvantum/* /usr/share/Kvantum/
sudo cp -r Dracula /usr/share/themes
sudo rm -R Dracula
git clone https://github.com/matheuuus/dracula-icons.git
mv dracula-icons Dracula
sed -i 's/Inherits=/Inherits=Faba,Moka,Papirus/g' Dracula/index.theme
sudo cp -r Dracula /usr/share/icons/
git clone https://github.com/dracula/wallpaper.git
mv wallpaper ~/Bilder/Dracula
git clone https://github.com/dracula/xfce4-terminal.git
mkdir -p ~/.local/share/xfce4/terminal/colorschemes
mv xfce4-terminal/Dracula.theme ~/.local/share/xfce4/terminal/colorschemes/
git clone https://github.com/dracula/geany.git
homedir=$HOME
if [ ! -d "${homedir}/.config/geany" ]; then
  mkdir -p ${homedir}/.config/geany
fi
mkdir -p ~/.config/geany/colorschemes
cp geany/Dracula-Theme.conf ~/.config/geany/colorschemes/
git clone https://github.com/dracula/libreoffice.git
mkdir -p ~/.config/libreoffice/4/user/config/
cp libreoffice/dracula.soc ~/.config/libreoffice/4/user/config/
git clone https://github.com/dracula/ghostwriter.git
mkdir -p ~/.config/ghostwriter/themes/Dracula
cp ghostwriter/theme.cfg ~/.config/ghostwriter/themes/Dracula/theme.cfg
cd ..
sudo rm -R dracula-tmp
exit 0




