#!/bin/bash
sudo pacman --noconfirm --needed -S plasma-workspace plasma-desktop papirus-icon-theme kvantum kvantum-qt5 arc-gtk-theme qt6-multimedia-gstreamer systemsettings kitemmodels
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze/' /etc/sddm.conf
wget https://salsa.debian.org/debian-desktop-team/desktop-base/-/raw/master/joy-theme/plymouth/background.png
sudo mv background.png /usr/share/sddm/themes/breeze
sudo printf '[General]\nbackground=background.png\ntype=image\n' > theme.conf.user
sudo mv theme.conf.user /usr/share/sddm/themes/breeze
exit 0
