#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# md2pdf-weasy.sh
# Konvertiert Markdown-Dateien nach PDF mit Pandoc + WeasyPrint
# Unterstützt \pagebreak durch Platzhalter-Ersatz
# -----------------------------------------------------------------------------

set -euo pipefail

# --- Eingabe prüfen ----------------------------------------------------------
if [[ $# -ne 1 ]]; then
  echo "Verwendung: $(basename "$0") <datei.md>" >&2
  exit 1
fi

SRC_MD="$1"
[[ -f "$SRC_MD" ]] || { echo "Datei nicht gefunden: $SRC_MD" >&2; exit 1; }

BASENAME="${SRC_MD%.md}"
TMP_MD="$(mktemp /tmp/weasy.XXXXXX.md)"
TMP_HTML="$(mktemp /tmp/weasy.XXXXXX.html)"
CSS_FILE="$HOME/.local/bin/weasyprint.css"
OUT_PDF="${BASENAME}.pdf"

# --- Schritt 1: Platzhalter einsetzen ---------------------------------------
# Ersetzt \pagebreak durch <PAGEBREAK> (Pandoc filtert das nicht weg)
sed 's|\\pagebreak|<PAGEBREAK>|g' "$SRC_MD" > "$TMP_MD"

# --- Schritt 2: Markdown → HTML ---------------------------------------------
pandoc \
  --from markdown \
  --to html5 \
  --standalone \
  --metadata title:"" \
  --css "$CSS_FILE" \
  -o "$TMP_HTML" \
  "$TMP_MD"

# --- Schritt 3: Platzhalter ersetzen durch HTML-Div --------------------------
sed -i 's|<PAGEBREAK>|<div class="pagebreak"></div>|g' "$TMP_HTML"

# --- Schritt 4: PDF erzeugen -------------------------------------------------
weasyprint "$TMP_HTML" "$OUT_PDF"

# --- Aufräumen ---------------------------------------------------------------
rm -f "$TMP_MD" "$TMP_HTML"

echo "PDF erstellt: $OUT_PDF"
