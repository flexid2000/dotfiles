#!/bin/bash
notmuch tag +sent -- "folder:posteo/Sent or folder:babylonia/Sent"

