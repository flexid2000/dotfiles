#!/bin/bash
set -e

echo "🧰 Installiere Dienstprogramme und Fonts ..."
sudo apt-get install -y \
    fonts-croscore fonts-inter fonts-firacode \
    fcitx5 fcitx5-frontend-qt5 fcitx5-frontend-gtk2 \
    fcitx5-frontend-gtk3 fcitx5-config-qt \
    im-config

mkdir -p ~/.local/bin ~/.local/share/applications ~/.config/yt-dlp
cp config ~/.config/yt-dlp
cp .bash_aliases ~/

echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
echo "GTK_IM_MODULE=fcitx" >> ~/.profile
echo "QT_IM_MODULE=fcitx" >> ~/.profile
echo "XMODIFIERS=@im=fcitx" >> ~/.profile

sudo cp local.conf /etc/fonts
sudo fc-cache -frv

echo "✅ Tools & Fonts konfiguriert."

