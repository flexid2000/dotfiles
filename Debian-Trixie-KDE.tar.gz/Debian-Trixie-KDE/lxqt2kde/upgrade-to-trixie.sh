#!/bin/bash
set -euo pipefail

# ==================== #
# KONFIGURATION        #
# ==================== #

# Farbdefinitionen (ohne Escape-Codes für bessere Lesbarkeit)
RED='\e[31m'
GREEN='\e[32m'
YELLOW='\e[33m'
NC='\e[0m'

# Protokolldatei
LOG_FILE="/tmp/debian-upgrade-$(date +%Y%m%d).log"

# ==================== #
# FUNKTIONEN           #
# ==================== #

# Funktion für sudo mit Passwortabfrage
sudo_with_check() {
    echo -e "${YELLOW}[sudo] Passwort für $(whoami) eingeben:${NC}"
    if ! sudo -S -v; then
        echo -e "${RED}Fehler: sudo-Authentifizierung fehlgeschlagen${NC}"
        exit 1
    fi
    sudo "$@"
}

confirm() {
    local prompt="$1"
    while true; do
        read -rp "${YELLOW}${prompt} (j/n)${NC} " answer
        case "$answer" in
            [JjYy]* ) return 0;;
            [Nn]* ) exit 1;;
            * ) echo -e "${YELLOW}Bitte mit j/ja oder n/nein antworten.${NC}";;
        esac
    done
}

# ==================== #
# HAUPTSKRIPT          #
# ==================== #

# Protokollierung
exec > >(tee -a "$LOG_FILE") 2>&1
echo -e "${GREEN}=== Debian Upgrade-Skript gestartet: $(date) ===${NC}"

# 1. Initiale sudo-Überprüfung
sudo_with_check true

# 2. Systemvorbereitung
echo -e "${GREEN}=== Phase 1: Systemvorbereitung ===${NC}"
sudo_with_check apt-get update
sudo_with_check apt-get install -y --no-install-recommends \
    aptitude \
    apt-transport-https \
    debian-archive-keyring

# 3. LXQt Deinstallation
echo -e "${GREEN}=== Phase 2: LXQt Deinstallation ===${NC}"
confirm "LXQt deinstallieren?"

# Temporäre Umgebung für sichere Deinstallation
export SUDO_FORCE_REMOVE=yes
sudo_with_check apt-mark hold sudo network-manager

# LXQt-Paketliste (validiert)
LXQT_PKGS=(
    lxqt* pcmanfm-qt* qterminal* lximage-qt* featherpad* 
    openbox* obconf* lxmenu-data* xarchiver* xfwm4*
)

# Geschützte Pakete
PROTECTED_PKGS=(
    sudo network-manager wpasupplicant net-tools 
    iproute2 ifupdown resolvconf
)

# Schutz aktivieren
for pkg in "${PROTECTED_PKGS[@]}"; do
    sudo_with_check apt-mark manual "$pkg" || sudo_with_check apt-get install -y "$pkg"
done

# Deinstallation
sudo_with_check apt-get purge -y "${LXQT_PKGS[@]}"
sudo_with_check apt-get autoremove --purge -y

# Schutz deaktivieren
for pkg in "${PROTECTED_PKGS[@]}"; do
    sudo_with_check apt-mark auto "$pkg"
done
unset SUDO_FORCE_REMOVE
sudo_with_check apt-mark unhold sudo network-manager

# 3. Systembereinigung
echo -e "${GREEN}=== Phase 3: Systembereinigung ===${NC}"
confirm "Soll das System bereinigt werden?"

# Nicht-Debian Pakete
sudo aptitude update
sudo aptitude purge '?narrow(?installed, ?not(?origin(Debian)))' --assume-yes

# Obsolete Pakete
sudo aptitude purge '~o' --assume-yes

# Konfigurationsreste
sudo aptitude purge '~c' --assume-yes

# 4. Upgrade auf Trixie
echo -e "${GREEN}=== Phase 4: Upgrade auf Trixie ===${NC}"
confirm "Soll das Upgrade auf Debian Trixie durchgeführt werden?"

# Quellen umstellen
cp /etc/apt/sources.list /etc/apt/sources.list.bak
cat > /etc/apt/sources.list <<EOF
deb https://deb.debian.org/debian trixie main contrib non-free
deb https://deb.debian.org/debian trixie-updates main contrib non-free
deb https://security.debian.org/debian-security trixie-security main
EOF

# Upgrade durchführen
apt-get update
apt-get upgrade --without-new-pkgs -y
apt-get dist-upgrade -y

# 5. KDE Installation
echo -e "${GREEN}=== Phase 5: KDE Plasma Installation ===${NC}"
confirm "Soll KDE Plasma installiert werden?"
tasksel install kde-desktop

# 6. Netzwerkkonfiguration
echo -e "${GREEN}=== Phase 6: Netzwerkkonfiguration ===${NC}"

# NetworkManager aktivieren
sed -i '/^\[ifupdown\]$/,/^\[/ s/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf

# Alte interfaces deaktivieren
INTERFACE=$(ip -o -4 route show default | awk '{print $5}' || echo "enp0s3")
sed -i "/^allow-hotplug ${INTERFACE}/s/^/#/" /etc/network/interfaces
sed -i "/^iface ${INTERFACE} inet dhcp/s/^/#/" /etc/network/interfaces

# Dienste neu starten
systemctl restart NetworkManager
systemctl disable networking 2>/dev/null || true

# 7. Finale Bereinigung
echo -e "${GREEN}=== Phase 7: Finale Bereinigung ===${NC}"
aptitude purge '~o' --assume-yes
apt-get autoremove --purge -y
apt-get clean

echo -e "${GREEN}=== Upgrade erfolgreich abgeschlossen! ===${NC}"
echo -e "Bitte neu starten: ${YELLOW}reboot${NC}"
echo -e "Protokoll: ${YELLOW}${LOG_FILE}${NC}"
