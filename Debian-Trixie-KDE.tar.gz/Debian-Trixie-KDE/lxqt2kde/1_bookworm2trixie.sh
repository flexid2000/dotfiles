#!/bin/bash

# Farben
RED="\033[1;31m"; GREEN="\033[1;32m"; YELLOW="\033[1;33m"; RESET="\033[0m"

# Bestätigungsfunktion
confirm() {
  echo -en "${YELLOW}$1 [j/N]: ${RESET}"
  read -r reply
  [[ "$reply" =~ ^[JjYy]$ ]]
}

set -euo pipefail

echo -e "${GREEN}1. Systemaktualisierung (Bookworm)${RESET}"
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get full-upgrade -y
sudo apt-get autoremove -y

echo -e "${YELLOW}=== Installiere essentielle Pakete ===${RESET}"
sudo apt-get update
sudo apt-get install -y sudo network-manager wpasupplicant aptitude

echo -e "${GREEN}=== LXQt Deinstallation ===${RESET}"
if confirm "LXQt deinstallieren?"; then
    sudo apt-get --auto-remove purge liblxqt-* lximage-qt* lxqt lxqt-* pavucontrol-qt task-lxqt-desktop pcmanfm-qt* libfm-qt12
fi

echo -e "${GREEN}Entferne obsolete Pakete mit aptitude.${RESET}"
sudo aptitude update
sudo aptitude purge '~o'

echo -e "${GREEN}Obsolete Pakete entfernt.${RESET}"

# Nicht-Debian-Pakete entfernen
if ! command -v apt-show-versions &> /dev/null; then
  echo "apt-show-versions wird installiert..."
  sudo apt-get update
  sudo apt-get install -y apt-show-versions
fi

echo -e "${GREEN}Nicht-Debian-Pakete werden gesucht...${RESET}"
local_pkgs=$(apt-show-versions | grep "No available version" | awk -F: '{print $1}' || true)
if [ -n "$local_pkgs" ]; then
  echo -e "${GREEN}Nicht-Debian-Pakete entfernen.${RESET}"
  sudo apt-get purge $local_pkgs
else
  echo -e "${GREEN}Keine Nicht-Debian-Pakete gefunden.${RESET}"
fi

# Hinweis auf Drittquellen
echo -e "${YELLOW}Prüfe gegebenenfalls auch /etc/apt/sources.list.d/ auf Bookworm-Einträge!${RESET}"

echo -e "${GREEN}4. /etc/apt/sources.list auf Trixie umstellen${RESET}"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo sed -i 's/bookworm/trixie/g' /etc/apt/sources.list

echo -e "${GREEN}5. Neue Paketlisten einlesen${RESET}"
sudo apt-get update

echo -e "${GREEN}6. Minimal-Upgrade (ohne neue Pakete)${RESET}"
sudo apt-get upgrade --without-new-pkgs

echo -e "${GREEN}7. Volles System-Upgrade${RESET}"
sudo apt-get full-upgrade

echo -e "${GREEN}Erster Teil des Upgrades abgeschlossen. Starte das System neu.${RESET}"
if confirm "Jetzt neu starten?"; then
  sudo reboot
fi
