#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
sudo apt-fast -y install volumeicon-alsa
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
sudo apt -y -t bookworm-backports install yt-dlp
exit 0
