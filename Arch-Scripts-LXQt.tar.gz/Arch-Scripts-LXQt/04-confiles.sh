#!/bin/bash
cp confiles/picom.conf ~/.config
if [ ! -d $HOME/.config/conky ]; then
  mkdir -p ~/.config/conky
fi
cp confiles/conky.conf ~/.config/conky
if [ ! -d $HOME/.config/openbox ]; then
  mkdir -p ~/.config/openbox
fi
cp confiles/rc.xml ~/.config/openbox/rc.xml
cp confiles/redshift.conf ~/.config
if [ ! -d $HOME/.config/yt-dlp ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if [ ! -d $HOME/.config/meteo-qt ]; then
  mkdir -p ~/.config/meteo-qt
fi
cp confiles/meteo-qt.conf ~/.config/meteo-qt/
if [ ! -d $HOME/.config/mpv ]; then
  mkdir -p ~/.config/mpv
fi
cp confiles/mpv.conf ~/.config/mpv
cp confiles/globalkeyshortcuts.conf ~/.config/lxqt
sudo cp confiles/policy.xml /etc/ImageMagick-7/policy.xml
# arc.obt installieren
git clone https://github.com/dglava/arc-openbox.git
obconf-qt --install arc-openbox/arc.obt
obconf-qt --install arc-openbox/arc-darker.obt
sudo rm -R arc-openbox
mkdir -p ~/Bilder/artwork
cp artwork/clipboard-dark.png ~/Bilder/artwork/
# ksuperkey
sudo pacman --needed --noconfirm -S libx11 libxtst
git clone https://github.com/hanschen/ksuperkey.git
cd ksuperkey
make
sudo make install
rm -R ksuperkey
exit 0
