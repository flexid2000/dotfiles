#!/bin/bash
sudo dd if=/dev/zero of=/swapfile bs=1M count=2048 status=progress
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
cp /etc/fstab /tmp/fstab
echo "/swapfile none swap sw 0 0" >> /tmp/fstab
echo " " >> /tmp/fstab
sudo cp /tmp/fstab /etc/fstab
exit 0
