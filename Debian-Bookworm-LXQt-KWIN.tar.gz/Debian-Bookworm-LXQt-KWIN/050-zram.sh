#!/bin/bash
sudo nala install systemd-zram-generator
exit 0
