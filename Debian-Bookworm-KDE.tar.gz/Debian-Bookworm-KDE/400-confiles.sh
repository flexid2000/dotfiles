#!/bin/bash
wget https://deac-ams.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky* ~/.config/conky
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp slugify.sh ~/.local/bin
cp deemix.desktop ~/.local/share/applications
cp config ~/.config/yt-dlp
cp .bash_aliases ~/
source ~/.bashrc
mkdir -p ~/.config/libreoffice/4/user/template
cp babylonia.ott ~/.config/libreoffice/4/user/template
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo apt-fast -y install fonts-croscore
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
sudo apt install ibus ibus-gtk4 ibus-gtk3 ibus-m17n
echo "GTK_IM_MODULE=ibus" >> ~/.bashrc
echo "QT_IM_MODULE=ibus" >> ~/.bashrc
echo "XMODIFIERS=@im=ibus" >> ~/.bashrc
cp dolphinrc katerc konsolerc okularpartrc ~/.config
cp .hidden ~/
echo "konsole neu starten"
exit 0
