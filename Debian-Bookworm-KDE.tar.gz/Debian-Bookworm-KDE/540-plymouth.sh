#!/bin/bash
sudo apt-fast -y install plymouth plymouth-themes plymouth-x11
#sudo sed -i 's/BackgroundStartColor=0x000000/BackgroundStartColor=0x282a36/' /usr/share/plymouth/themes/spinner/spinner.plymouth
#sudo sed -i 's/BackgroundEndColor=0x000000/BackgroundEndColor=0x282a36/' /usr/share/plymouth/themes/spinner/spinner.plymouth
sudo plymouth-set-default-theme -R spinner
sudo sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="quiet"/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"/' /etc/default/grub
sudo update-grub
sudo apt-fast -y install systemd-boot
exit 0
