#!/bin/bash
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky.conf ~/.config/conky/
cp conky-shortcuts.conf ~/.config/conky/
cp redshift.conf ~/.config
cp .xprofile ~/.xprofile
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
echo "alias upgrade='sudo apt update && sudo apt -y full-upgrade && sudo apt -y autoremove --purge && sudo apt-get clean'" > ~/.bash_aliases
source ~/.bashrc
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo apt -y install fonts-croscore
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
sudo apt -y install imagemagick
sudo cp policy.xml /etc/ImageMagick-6
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>w" --create --type string --set "exo-open --launch WebBrowser"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>m" --create --type string --set "exo-open --launch MailReader"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>t" --create --type string --set "exo-open --launch TerminalEmulator"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>f" --create --type string --set "exo-open --launch FileManager"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>e" --create --type string --set "geany"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>l" --create --type string --set "libreoffice --writer --nologo"
xfconf-query --channel xfce4-keyboard-shortcuts --property "/commands/custom/<Super>x" --create --type string --set "xfce4-session-logout"
exit 0
