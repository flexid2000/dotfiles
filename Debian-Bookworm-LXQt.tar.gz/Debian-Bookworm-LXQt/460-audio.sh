#!/bin/bash
sudo apt-fast -y install pipewire-audio
systemctl --user --now enable wireplumber.service
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget https://www.dropbox.com/s/njh0fsoftw2kutc/linux-x64-latest.AppImage?dl=0
mv linux-x64-latest.AppImage?dl=0 ~/.local/bin/deemix.AppImage
chmod 755 ~/.local/bin/deemix.AppImage
cp confiles/deemix.desktop ~/.local/share/applications
sudo apt-fast -y install python3-pip
python3 -m pip install -U yt-dlp
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
