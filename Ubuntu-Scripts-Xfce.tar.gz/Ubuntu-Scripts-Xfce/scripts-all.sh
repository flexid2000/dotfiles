#!/bin/bash
sh 000-apt-fast.sh
sh 575-firefox.sh
sh 110-system-conf.sh
sh 120-autostart.sh
sh 600-programs-install.sh
sh 520-recoll.sh
sh 300-binaries-install.sh
sh 400-confiles.sh
sh 460-deemix.sh
sh 510-yt-dlp.sh
sh 570-brave-browser.sh
sh 580-img2pdf.sh
sh 590-typora.sh
sh 610-courier-prime-fonts.sh
sh 630-signal-desktop.sh
sh 640-zotero.sh
exit 0
