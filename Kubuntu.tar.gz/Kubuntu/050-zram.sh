#!/bin/bash
sudo apt-fast -y install systemd-zram-generator
# systemctl --user --now enable wireplumber.service
exit 0
