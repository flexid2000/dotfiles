#!/bin/bash
sudo apt-fast update
sudo apt-fast -y install accountsservice acpid alsa-firmware-loaders arandr arc-theme arj audacious bleachbit blueman bluetooth bluez-cups bluez-obexd bluez-tools breeze-cursor-theme cabextract caffeine conky-std curl cups cups-browsed cups-client cups-common cups-core-drivers cups-filters cups-filters-core-drivers cups-ipp-utils cups-pk-helper cups-ppdc cups-server-common dkms icoextract-thumbnailer exfalso faad ffmpeg ffmpegthumbnailer ffmpegthumbs firefox-esr-l10n-de flac flvstreamer fonts-cantarell fonts-croscore fonts-inconsolata fonts-roboto galternatives ghostwriter gimp gimp-plugin-registry git gpa graphicsmagick graphicsmagick-imagemagick-compat grsync haveged htop hunspell hunspell-de-de hwinfo hyphen-de inkscape kcolorchooser lame libcanberra-pulse libgsf-bin libgpod-dev libgsf-bin libimobiledevice-dev libnotify-bin libreoffice libreoffice-l10n-de libreoffice-help-de libslf4j-java lxqt-archiver menu-xdg meteo-qt mjpegtools mpv mtp-tools mythes-de netselect-apt network-manager-gnome nextcloud-desktop numlockx package-update-indicator papirus-icon-theme pdfarranger plank plocate plymouth-themes plymouth-x11 poppler-utils pulseaudio-module-bluetooth python3-pyinotify pwgen qapt-deb-installer qpdfview qt5-style-kvantum redshift seahorse shotwell skanpage software-properties-gtk speedcrunch strawberry subversion task-german-desktop task-laptop telegram-desktop thunderbird thunderbird-l10n-de transmission-qt ttf-bitstream-vera ttf-mscorefonts-installer tumbler tumbler-plugins-extra unace unclutter unrar vim vlc vorbis-tools wavpack wmctrl wv wx-common xbindkeys xdotool zip x11-xserver-utils xscreensaver xsettingsd
## ghostwirter from trixie
wget http://ftp.de.debian.org/debian/pool/main/g/ghostwriter/ghostwriter_23.04.3+ds-1_amd64.deb
sudo dpkg -i ghostwriter_23.04.3+ds-1_amd64.deb
sudo systemctl enable bluetooth.service
sudo systemctl start bluetooth.service
sudo sed -i 's/'#AutoEnable=false'/'AutoEnable=true'/g' /etc/bluetooth/main.conf
sudo systemctl enable acpid.service
exit 0
