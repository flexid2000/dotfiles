#!/bin/bash
VER=1.0.3
sudo apt-get install python3-pyqt5xdg-utils python3-gi xdotool
sudo mkdir /usr/share/angrysearch
wget https://github.com/DoTheEvo/ANGRYsearch/archive/refs/tags/v$VER.tar.gz
tar xzf v$VER.tar.gz
cd ANGRYsearch-$VER/
sudo cp -r * /usr/share/angrysearch
sudo chmod +x /usr/share/angrysearch/angrysearch.py
sudo chmod +x /usr/share/angrysearch/angrysearch_update_database.py
sudo ln -s /usr/share/angrysearch/angrysearch.desktop /usr/share/applications
sudo ln -s /usr/share/angrysearch/angrysearch.svg /usr/share/pixmaps
sudo ln -s /usr/share/angrysearch/angrysearch.py /usr/bin/angrysearch
sudo cp confiles/angrysearchupdate /etc/cron.daily
sudo chmod 755 /etc/cron.daily/angrysearchupdate
sudo rm -R ANGRYsearch-$VER
rm v$VER.tar.gz
exit 0
