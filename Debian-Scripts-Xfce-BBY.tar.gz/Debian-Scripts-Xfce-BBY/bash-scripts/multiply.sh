#!/bin/bash
name="${1%.*}"
mkdir "${name}"
mv "$1" "${name}"
cd "${name}"
for num in {01..13}; do cp "$1" $num."$1"; done
rm "$1"
exit 0


