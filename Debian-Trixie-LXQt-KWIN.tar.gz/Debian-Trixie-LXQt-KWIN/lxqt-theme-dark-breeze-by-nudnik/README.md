# LXQT Theme Dark Breeze by Nudnik

A LXQT theme based on the Dark Breeze theme with added support for LXQT 2.0 and Fancy Menu

Just extract folder and copy to ~/.local/share/lxqt/themes/. Theme can now be selected in the LXQT configuration center.
As Icons I used the Tela Light icons and on the panel settings I selected Tela Dark separately.

Credits:
- included wallpaper "Altai" made by Alesya Khoteeva of the KDE Visual Design Group (VDG), https://github.com/KDE/plasma-workspace-wallpapers
- some included icons from the Breeze icon theme made by the KDE Visual Design Group (VDG), https://github.com/KDE/breeze
- based on the "KDE-Plasma" LXQt theme made by the LXQt team, https://github.com/lxqt/lxqt-themes
- Startmenu Button for Fancy Menu taken from Dark Leaves Theme

