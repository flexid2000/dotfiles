#!/usr/bin/env bash
# resize-center-window.sh
# Verkleinert das aktive Fenster auf 960x540 und zentriert es auf dem Bildschirm.
# Voraussetzung: xdotool, xrandr

set -euo pipefail

TARGET_W=960
TARGET_H=540

# Aktives Fenster ermitteln
WIN_ID=$(xdotool getactivewindow)

SCREEN_W=1920
SCREEN_H=1080

# Zielposition berechnen (zentriert)
POS_X=$(( (SCREEN_W - TARGET_W) / 2 ))
POS_Y=$(( (SCREEN_H - TARGET_H) / 2 ))

# Fenster ggf. aus Maximierung/Vollbild lösen (benötigt wmctrl)
wmctrl -ir "$WIN_ID" -b remove,maximized_vert,maximized_horz
wmctrl -ir "$WIN_ID" -b remove,fullscreen

# Größe und Position setzen
xdotool windowsize "$WIN_ID" "$TARGET_W" "$TARGET_H"
xdotool windowmove "$WIN_ID" "$POS_X"    "$POS_Y"

echo "Fenster $WIN_ID → ${TARGET_W}x${TARGET_H} @ ${POS_X},${POS_Y}"