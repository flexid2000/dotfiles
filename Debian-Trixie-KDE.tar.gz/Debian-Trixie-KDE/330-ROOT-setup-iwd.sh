#!/bin/bash

# iwd Installation und Konfiguration für Debian Trixie KDE Plasma 6
# Dieses Skript muss mit Root-Rechten ausgeführt werden

set -e  # Bei Fehlern abbrechen

# Farben für Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funktion für farbige Ausgabe
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNUNG]${NC} $1"
}

print_error() {
    echo -e "${RED}[FEHLER]${NC} $1"
}

# Root-Rechte prüfen
if [[ $EUID -ne 0 ]]; then
   print_error "Dieses Skript muss mit Root-Rechten ausgeführt werden (sudo)"
   exit 1
fi

print_info "Starte iwd Installation und Konfiguration..."
echo ""

# 1. System aktualisieren
print_info "Aktualisiere Paketlisten..."
apt update

# 2. iwd installieren
print_info "Installiere iwd..."
apt install -y iwd

# 3. wpa_supplicant deaktivieren
print_info "Deaktiviere wpa_supplicant..."
systemctl stop wpa_supplicant 2>/dev/null || true
systemctl disable wpa_supplicant 2>/dev/null || true
systemctl mask wpa_supplicant 2>/dev/null || true

# 4. iwd-Konfigurationsverzeichnis erstellen
print_info "Erstelle iwd-Konfiguration..."
mkdir -p /etc/iwd

# 5. iwd Hauptkonfiguration erstellen
cat > /etc/iwd/main.conf << 'EOF'
[General]
EnableNetworkConfiguration=false
UseDefaultInterface=true
EOF

print_info "iwd-Konfiguration erstellt: /etc/iwd/main.conf"

# 6. NetworkManager conf.d Verzeichnis erstellen
print_info "Konfiguriere NetworkManager für iwd..."
mkdir -p /etc/NetworkManager/conf.d

# 7. NetworkManager für iwd-Backend konfigurieren
cat > /etc/NetworkManager/conf.d/wifi-backend.conf << 'EOF'
[device]
wifi.backend=iwd
EOF

print_info "NetworkManager-Konfiguration erstellt: /etc/NetworkManager/conf.d/wifi-backend.conf"

# 8. /etc/network/interfaces überprüfen und ggf. bereinigen
print_info "Überprüfe /etc/network/interfaces..."

if grep -q "iface wlan" /etc/network/interfaces || grep -q "iface wlp" /etc/network/interfaces; then
    print_warning "WLAN-Interfaces in /etc/network/interfaces gefunden!"
    print_warning "Diese sollten entfernt werden, damit NetworkManager sie verwalten kann."
    
    # Backup erstellen
    cp /etc/network/interfaces /etc/network/interfaces.backup.$(date +%Y%m%d_%H%M%S)
    print_info "Backup erstellt: /etc/network/interfaces.backup.*"
fi

# 9. iwd aktivieren und starten
print_info "Aktiviere und starte iwd..."
systemctl enable iwd
systemctl start iwd

# 10. NetworkManager neu starten
print_info "Starte NetworkManager neu..."
systemctl restart NetworkManager

# 11. Status prüfen
echo ""
print_info "Warte 3 Sekunden auf Systeminitialisierung..."
sleep 3

echo ""
print_info "=== Status-Check ==="
echo ""

if systemctl is-active --quiet iwd; then
    print_info "✓ iwd läuft"
else
    print_error "✗ iwd läuft NICHT"
fi

if systemctl is-active --quiet NetworkManager; then
    print_info "✓ NetworkManager läuft"
else
    print_error "✗ NetworkManager läuft NICHT"
fi

if systemctl is-active --quiet wpa_supplicant 2>/dev/null; then
    print_warning "✗ wpa_supplicant läuft noch (sollte gestoppt sein)"
else
    print_info "✓ wpa_supplicant ist deaktiviert"
fi

# WLAN-Interface ermitteln
WLAN_INTERFACE=$(ip link | grep -o 'wl[^:]*' | head -n1)

if [ -n "$WLAN_INTERFACE" ]; then
    print_info "✓ WLAN-Interface gefunden: $WLAN_INTERFACE"
else
    print_warning "Kein WLAN-Interface gefunden (möglicherweise kein WLAN-Adapter vorhanden)"
fi

echo ""
print_info "=== Installation abgeschlossen ==="
echo ""
print_info "Du kannst jetzt WLAN-Netzwerke wie gewohnt über das KDE Plasma Netzwerk-Widget verwalten."
echo ""
print_info "Nützliche Befehle:"
echo "  - Status prüfen:           systemctl status iwd"
echo "  - Verfügbare Netzwerke:    iwctl station $WLAN_INTERFACE get-networks"
echo "  - Logs anzeigen:           journalctl -u iwd -f"
echo "  - NetworkManager-Logs:     journalctl -u NetworkManager -f"
echo ""

# Optional: WLAN-Scan durchführen, wenn Interface vorhanden
if [ -n "$WLAN_INTERFACE" ]; then
    print_info "Führe WLAN-Scan durch..."
    iwctl station "$WLAN_INTERFACE" scan 2>/dev/null || true
    sleep 2
    echo ""
    print_info "Verfügbare WLAN-Netzwerke:"
    iwctl station "$WLAN_INTERFACE" get-networks 2>/dev/null || print_warning "Konnte keine Netzwerke abrufen"
fi

echo ""
print_info "Bei Problemen bitte die Logs überprüfen und ggf. das System neu starten."
