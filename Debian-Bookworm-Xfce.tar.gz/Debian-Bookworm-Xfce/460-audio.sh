#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget https://www.dropbox.com/s/njh0fsoftw2kutc/linux-x64-latest.AppImage?dl=0
mv linux-x64-latest.AppImage?dl=0 ~/.local/bin/deemix.AppImage
chmod 755 ~/.local/bin/deemix.AppImage
cp confiles/deemix.desktop ~/.local/share/applications
sudo apt -y purge yt-dlp
sudo apt-fast -y install python3-pip volumeicon-alsa
#sudo python3 -m pip install -U yt-dlp --break-system-packages
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
sudo apt -y -t bookworm-backports install yt-dlp
exit 0
