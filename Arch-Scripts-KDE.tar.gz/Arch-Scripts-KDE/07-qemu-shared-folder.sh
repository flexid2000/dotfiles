#!/bin/bash
set -e

echo "📦 Installiere SPICE-Gästeintegration ..."
sudo pacman -S --needed --noconfirm spice-vdagent xf86-video-qxl spice-gtk --needed

echo "📁 Erstelle lokalen shared-Ordner ..."
mkdir -p "$HOME/shared"

echo "🔧 Füge 9p-Mountpoint zu /etc/fstab hinzu ..."
if ! grep -q "/sharepoint" /etc/fstab; then
    printf '/sharepoint\t%s/shared\t9p\ttrans=virtio,version=9p2000.L,rw\t0\t0\n' "$HOME" | sudo tee -a /etc/fstab > /dev/null
    sudo sed -i -e '$a\' /etc/fstab
fi

echo "✅ Fertig."
