#!/bin/bash
for FILE in "$@"; do
	NAME="${FILE%.*}"
	echo "${NAME}"
	pandoc -s -o "${NAME}".pdf --pdf-engine=xelatex --metadata title=" " \
	-V papersize=A4 \
	-V margin-top=72pt \
	-V margin-right=72pt \
	-V margin-bottom=72pt \
	-V margin-left=72pt \
	-V fontsize=10pt \
	-V linestretch=1.2 \
	-V mainfont=NotoSans-Regular \
	-V colorlinks:linkcolor:blue \
	"${FILE}"
done
exit 0

