#!/bin/bash
if [ ! -f /usr/bin/curl ]; then
	sudo apt-fast -y install curl
fi
curl -fsSL https://deb.nodesource.com/setup_current.x | sudo bash -
sudo apt-fast -y install nodejs
cp file-manager-actions/markdown-pdf.sh ~/.local/bin/
cp file-manager-actions/markdown-pdf.desktop ~/.local/share/file-manager/actions/
cp file-manager-actions/style.css ~/.local/bin/
cd ~/.local
npm install markdown-pdf
exit 0

