#!/bin/bash
mkdir "${1%.*}"
mv "$1" "${1%.*}"
cd "${1%.*}"
for num in {01..13}; do cp "$1" $num."$1"; done
rm "$1"
exit 0
