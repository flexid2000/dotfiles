#!/bin/bash
#
# sources.list anpassen
#
sudo apt-get install curl
echo "deb http://mirror.ipb.de/debian/ trixie main contrib non-free" > /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ trixie-updates main contrib non-free" >> /tmp/sources.list
#echo "deb http://mirror.ipb.de/debian/ trixie-backports main contrib non-free" >> /tmp/sources.list
echo "deb http://deb.debian.org/debian-security trixie-security main" >> /tmp/sources.list
sudo cp /tmp/sources.list /etc/apt
sudo apt update
exit 0
