#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
sudo pacman -S --noconfirm --needed materia-kde
sudo sed -i 's/Session=/Session=lxqt.desktop/' /etc/sddm.conf
sudo sed -i "s|User=|User=$USER|g" /etc/sddm.conf
sudo sed -i 's/Current=/Current=materia/' /etc/sddm.conf
sudo sed -i 's/CursorTheme=/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo cp artwork/grub-16x9.png /usr/share/sddm/themes/materia/images/background.png
exit 0
