#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget -O- https://uc6b2fdec7bbcd5e0875876a4499.dl.dropboxusercontent.com/cd/0/get/CTRAWxBF-DLyICwEYAjb4JxCCkQJ_t8a8nTkHqgtMgd1Dbw83AdBKCQDvT2zytdhzWpUhj3WIIwxcpm833j446-lxMioT34dZv7a26RJJmmBaBdrrP-rVvL_6Oq-gqDCSss/file?dl=1 > deemix-linux-x64.deb
sudo dpkg -i deemix-linux-x64.deb
sudo apt-get -y install volumeicon-alsa pipewire pipewire-audio pipewire-alsa gstreamer1.0-pipewire vlc-plugin-pipewire pipewire-pulse pavucontrol-qt
sudo apt-get -y purge pulseaudio-alsa pulseaudio-bluetooth pulseaudio gstreamer1.0-pulseaudio
systemctl --user --now enable wireplumber.service
sudo apt-get -t bookworm-backports install yt-dlp
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
