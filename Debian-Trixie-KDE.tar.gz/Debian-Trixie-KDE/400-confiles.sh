#!/bin/bash
wget https://deac-ams.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky* ~/.config/conky
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp config ~/.config/yt-dlp
cp .bash_aliases ~/
source ~/.bashrc
mkdir -p ~/.config/libreoffice/4/user/template
cp babylonia.ott ~/.config/libreoffice/4/user/template
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo apt-get install fonts-croscore fonts-inter fonts-firacode fcitx5 fcitx5-frontend-qt5 fcitx5-frontend-gtk2 fcitx5-frontend-gtk3 fcitx5-config-qt
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
echo "GTK_IM_MODULE=fcitx" >> ~/.profile
echo "QT_IM_MODULE=fcitx" >> ~/.profile
echo "XMODIFIERS=@im=fcitx" >> ~/.profile
cp dolphinrc katerc konsolerc okularpartrc ~/.config
cp .hidden ~/
echo "konsole neu starten"
exit 0
