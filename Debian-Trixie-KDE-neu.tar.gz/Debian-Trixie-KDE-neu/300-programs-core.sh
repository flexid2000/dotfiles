#!/bin/bash
set -e

echo "📦 Installiere zentrale Desktop-Programme ..."
sudo apt-fast update
sudo apt-get install -y \
    accountsservice acpid arandr arc-theme bleachbit bluez-tools \
    breeze-cursor-theme dolphin ffmpeg flac gimp htop inkscape \
    libreoffice libreoffice-help-de libreoffice-l10n-de \
    mpv papirus-icon-theme pavucontrol-qt pdfarranger \
    pipewire-audio plank recoll smplayer synaptic thunderbird \
    vlc weasyprint zip unzip

echo "✅ Desktop-Basispakete installiert."

