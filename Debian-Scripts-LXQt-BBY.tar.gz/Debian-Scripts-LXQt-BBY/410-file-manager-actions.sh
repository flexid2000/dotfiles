#!/bin/bash
sudo apt -y install rename
cd file-manager-actions
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
cp copy2clipboard.desktop img2pdf.desktop multiply.desktop setaswallpaper.desktop terminal.desktop slugify.desktop ~/.local/share/file-manager/actions
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir ~/.local/bin
fi
cp copy2clipboard.sh ~/.local/bin
cp ../bash-scripts/remove-alpha-img2pdf.sh ~/.local/bin
sudo apt install xclip
cp ../confiles/multiply.sh ~/.local/bin
cp file-manager-actions.desktop ~/Vorlagen
exit 0
