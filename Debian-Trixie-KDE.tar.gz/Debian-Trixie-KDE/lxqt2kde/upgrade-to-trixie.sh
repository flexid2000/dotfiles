#!/bin/bash
set -euo pipefail

# Farben
RED="\033[1;31m"; GREEN="\033[1;32m"; YELLOW="\033[1;33m"; RESET="\033[0m"

# Funktion zum Bestätigen
confirm() {
  echo -en "${YELLOW}$1 [j/N]: ${RESET}"
  read -r reply
  [[ "$reply" =~ ^[JjYy]$ ]]
}

# 1. Vorbereitung
echo -e "${GREEN}1. Systemaktualisierung (Bookworm)${RESET}"
sudo apt update
sudo apt upgrade -y
sudo apt full-upgrade -y
sudo apt autoremove -y

# 1. Root-Passwort setzen
echo "${YELLOW}=== Root-Passwort setzen ===${NC}"
sudo passwd root

# 2. Essential Packages sichern
echo "${YELLOW}=== Installiere essentielle Pakete ===${NC}"
sudo apt-get update
sudo apt-get install -y sudo network-manager wpasupplicant

# 3. LXQt deinstallieren (SIMPLE Version)
echo "${GREEN}=== LXQt Deinstallation ===${NC}"
read -p "${YELLOW}LXQt deinstallieren? (j/n)${NC} " answer
if [[ $answer =~ ^[Jj] ]]; then
    sudo apt-get purge -y lxqt-* pcmanfm-qt* qterminal*
    sudo apt-get autoremove --purge -y
fi

# 2. Entfernen obsoleter Pakete
echo -e "${GREEN}2. Entfernen obsoleter Pakete${RESET}"
OBSOLETE=$(apt list '~o' 2>/dev/null | grep -v "Listing..." || true)
if [ -n "$OBSOLETE" ]; then
  echo -e "${YELLOW}Gefundene obsolet gewordene Pakete:${RESET}"
  echo "$OBSOLETE"
  if confirm "Obsolete Pakete entfernen?"; then
    echo "$OBSOLETE" | cut -d/ -f1 | xargs sudo apt purge -y
  fi
else
  echo "Keine obsoleten Pakete gefunden."
fi

# 3. Drittanbieterpakete prüfen
echo -e "${GREEN}3. Drittanbieterpakete prüfen${RESET}"
THIRDPARTY=$(apt list '?origin(!=Debian)' 2>/dev/null | grep -v "Listing..." || true)
if [ -n "$THIRDPARTY" ]; then
  echo -e "${RED}Achtung: Folgende Pakete stammen NICHT aus Debian:${RESET}"
  echo "$THIRDPARTY"
  echo "Bitte entferne diese manuell, falls sie beim Upgrade stören könnten."
  confirm "Fortfahren trotz Drittanbieterpakete?" || exit 1
else
  echo "Keine Fremdquellen-Pakete gefunden."
fi

# 4. Quellen auf Trixie umstellen
echo -e "${GREEN}4. /etc/apt/sources.list auf Trixie umstellen${RESET}"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo sed -i 's/bookworm/trixie/g' /etc/apt/sources.list

# 5. Neue Paketlisten
echo -e "${GREEN}5. Neue Paketlisten einlesen${RESET}"
sudo apt update

# 6. Minimal-Upgrade
echo -e "${GREEN}6. Minimal-Upgrade (ohne neue Pakete)${RESET}"
sudo apt upgrade --without-new-pkgs -y

# 7. Volles Upgrade
echo -e "${GREEN}7. Volles System-Upgrade${RESET}"
sudo apt full-upgrade -y

# 8. Aufräumen
echo -e "${GREEN}8. Aufräumen nach dem Upgrade${RESET}"
sudo apt autoremove -y

echo -e "${GREEN}8b. Entfernte, aber nicht gepurgte Pakete${RESET}"
REMOVED=$(dpkg -l | awk '/^rc/ { print $2 }')
if [ -n "$REMOVED" ]; then
  echo -e "${YELLOW}Purge für folgende entfernte Pakete:${RESET}"
  echo "$REMOVED"
  echo "$REMOVED" | xargs sudo apt purge -y
else
  echo "Keine entfernten Konfigurationsreste gefunden."
fi

# 9. Reboot-Vorschlag
echo -e "${GREEN}Upgrade abgeschlossen. Starte das System neu.${RESET}"
confirm "Jetzt neu starten?" && sudo reboot
