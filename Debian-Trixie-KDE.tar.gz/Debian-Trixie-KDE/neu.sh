#!/bin/bash

set -e

echo "👤 Setze individuelles Benutzer-Icon ..."
sudo rm -f /usr/share/sddm/faces/.face.icon
rsvg-convert -a -w 144 -f svg /usr/share/icons/Papirus/22x22@2x/apps/distributor-logo-debian.svg -o /tmp/face.svg
mv /tmp/face.svg ~/.face.icon
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon

echo "🔐 Setze Berechtigungen für SDDM auf Benutzericon ..."
setfacl -m u:sddm:x "$HOME"
setfacl -m u:sddm:r "$HOME/.face.icon"

exit 0

