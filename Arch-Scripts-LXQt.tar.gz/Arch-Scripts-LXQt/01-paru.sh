#!/bin/bash
sudo pacman -S --needed --noconfirm base-devel git accountsservice haveged reflector bat rsync openssl-1.1
sudo systemctl enable accounts-daemon.service
sudo systemctl enable haveged.service
sudo pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com
sudo pacman-key --lsign-key 3056513887B78AEB
sudo pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst'
sudo pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst'
cp /etc/pacman.conf /tmp/pacman.conf
echo -e '[chaotic-aur]\nInclude = /etc/pacman.d/chaotic-mirrorlist' >> /tmp/pacman.conf
sudo cp /tmp/pacman.conf /etc/pacman.conf
sudo pacman -Syu
sudo pacman -S paru
sudo reflector --protocol http,https --country Germany --latest 5 --sort rate --save /etc/pacman.d/mirrorlist
sudo pacman -Syu
sudo sed -i 's/#ParallelDownloads/ParallelDownloads/' /etc/pacman.conf
sudo sed -i 's/MAKEFLAGS="-j1"/MAKEFLAGS="-j$(nproc)"/' /etc/makepkg.conf
exit 0
