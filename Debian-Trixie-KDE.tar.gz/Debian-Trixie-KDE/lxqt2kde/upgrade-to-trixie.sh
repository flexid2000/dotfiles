#!/bin/bash
set -euo pipefail

# Farbdefinitionen
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Protokollierung
LOG_FILE="/var/log/debian-upgrade-$(date +%Y%m%d).log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo -e "${GREEN}=== Debian Bookworm zu Trixie Upgrade ===${NC}"

# 0. Root-Passwort setzen (KRITISCH für sudo-Erhalt)
echo -e "${YELLOW}=== Root-Passwort setzen ===${NC}"
if ! sudo passwd root; then
    echo -e "${RED}Fehler: Root-Passwort konnte nicht gesetzt werden${NC}"
    exit 1
fi

# 1. Vorbereitung
echo -e "${YELLOW}=== Systemvorbereitung ===${NC}"
sudo apt-get update
sudo apt-get install -y --no-install-recommends \
    aptitude \
    apt-transport-https \
    debian-archive-keyring \
    network-manager \
    wpasupplicant

# 2. LXQt Deinstallation (mit SUDO-SCHUTZ)
echo -e "${GREEN}=== Phase 1: LXQt Deinstallation ===${NC}"

# a) Temporär sudo schützen
echo -e "${YELLOW}>>> Aktiviere SUDO-Schutz${NC}"
export SUDO_FORCE_REMOVE=yes
sudo apt-mark hold sudo
sudo apt-get install --reinstall -y sudo

# b) Paketliste (ohne sudo/lxqt-sudo)
LXQT_PKGS=(
    feathernotes feathernotes-l10n featherpad featherpad-l10n libfm-qt12 
    liblxqt-globalkeys1 liblxqt-l10n liblxqt1 lximage-qt lximage-qt-l10n 
    lxqt-about lxqt-about-l10n lxqt-admin lxqt-admin-l10n lxqt-config 
    lxqt-config-l10n lxqt-core lxqt-globalkeys lxqt-globalkeys-l10n 
    lxqt-notificationd lxqt-openssh-askpass lxqt-openssh-askpass-l10n 
    lxqt-panel lxqt-panel-l10n lxqt-policykit lxqt-policykit-l10n 
    lxqt-powermanagement lxqt-powermanagement-l10n lxqt-qtplugin lxqt-runner 
    lxqt-runner-l10n lxqt-session pcmanfm-qt pcmanfm-qt-l10n qterminal 
    qterminal-l10n task-lxqt-desktop
)

# c) Geschützte Pakete
PROTECTED_PKGS=(network-manager wpasupplicant net-tools iproute2 ifupdown resolvconf sudo)
for pkg in "${PROTECTED_PKGS[@]}"; do
    sudo apt-mark manual "$pkg" 2>/dev/null || sudo apt-get install -y "$pkg"
done

# d) LXQt deinstallieren
echo -e "${YELLOW}>>> Deinstalliere LXQt-Pakete${NC}"
sudo apt-get purge -y "${LXQT_PKGS[@]}"
sudo apt-get autoremove --purge -y

# e) Schutz zurücksetzen
for pkg in "${PROTECTED_PKGS[@]}"; do
    sudo apt-mark auto "$pkg" 2>/dev/null
done
sudo apt-mark unhold sudo
unset SUDO_FORCE_REMOVE

# 1. Systembereinigung (Bookworm)
echo -e "${GREEN}=== Phase 1: Systembereinigung ===${NC}"

# a) Nicht-Debian-Pakete mit aptitude
echo -e "${YELLOW}>>> Entferne Nicht-Debian-Pakete${NC}"
sudo aptitude update
sudo aptitude purge '?narrow(?installed, ?not(?origin(Debian)))' --assume-yes

# b) Obsolete Pakete
echo -e "${YELLOW}>>> Entferne obsolete Pakete${NC}"
sudo aptitude purge '~o' --assume-yes

# c) Konfigurationsreste
echo -e "${YELLOW}>>> Bereinige Konfigurationsdateien${NC}"
sudo aptitude purge '~c' --assume-yes

# 3. Upgrade auf Trixie
echo -e "${GREEN}=== Phase 3: Upgrade auf Trixie ===${NC}"

# Quellen umstellen
confirm "Paketquellen auf Trixie umstellen?"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo tee /etc/apt/sources.list <<EOF
deb https://deb.debian.org/debian trixie main contrib non-free
deb https://deb.debian.org/debian trixie-updates main contrib non-free
deb https://security.debian.org/debian-security trixie-security main
EOF

# Upgrade-Phasen
echo -e "${GREEN}>>> Schritt 1: Upgrade ohne neue Pakete${NC}"
sudo apt-get update
sudo apt-get upgrade --without-new-pkgs -y

echo -e "${GREEN}>>> Schritt 2: Vollständiges Upgrade${NC}"
sudo apt-get dist-upgrade -y

# 4. Post-Upgrade-Bereinigung (KRITISCH)
echo -e "${GREEN}=== Phase 4: Post-Upgrade-Bereinigung ===${NC}"

echo -e "${YELLOW}>>> Entferne obsolete Pakete (~o)${NC}"
sudo aptitude purge '~o' --assume-yes

echo -e "${YELLOW}>>> Bereinige Konfigurationsdateien (~c)${NC}"
sudo aptitude purge '~c' --assume-yes

# 5. KDE Installation (Trixie)
echo -e "${GREEN}=== Phase 5: KDE Installation ===${NC}"
confirm "KDE Plasma installieren?"
sudo tasksel install kde-desktop

# 5. NETZWERK KONFIGURATION (nach KDE-Installation)
echo -e "${GREEN}=== Finale Netzwerkkonfiguration ===${NC}"

# a) NetworkManager.conf
sudo sed -i '/^\[ifupdown\]$/,/^\[/ s/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf || {
    echo -e "${YELLOW}NetworkManager.conf Anpassung fehlgeschlagen, manuell prüfen!${NC}"
}

# b) interfaces-Datei bereinigen
INTERFACE=$(ip -o -4 route show default | awk '{print $5}' || echo "enp0s3")
sudo cp /etc/network/interfaces /etc/network/interfaces.bak
sudo sed -i "/^allow-hotplug ${INTERFACE}/s/^/#/" /etc/network/interfaces
sudo sed -i "/^iface ${INTERFACE} inet dhcp/s/^/#/" /etc/network/interfaces

# c) Dienste neu starten
sudo systemctl restart NetworkManager
sudo systemctl disable networking.service 2>/dev/null || true

echo -e "${GREEN}=== Upgrade abgeschlossen! ===${NC}"
echo -e "Bitte neu starten: ${YELLOW}sudo reboot${NC}"
