#!/bin/bash
set -e

echo "🎞️ Konfiguriere Plymouth ..."
sudo apt-get install -y plymouth plymouth-themes
sudo plymouth-set-default-theme -R spinner

sudo sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="quiet"/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"/' /etc/default/grub
sudo update-grub

echo "✅ Plymouth-Theme gesetzt."

