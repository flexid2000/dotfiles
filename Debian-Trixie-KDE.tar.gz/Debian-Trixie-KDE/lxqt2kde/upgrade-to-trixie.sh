#!/bin/bash
set -e

# Farbdefinitionen
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funktion zur Bestätigung
confirm() {
    read -p "${YELLOW}$1 (j/n)${NC} " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[JjYy]$ ]]; then
        echo -e "${RED}Abbruch durch Benutzer.${NC}"
        exit 1
    fi
}

# 1. Überprüfen, ob wir auf TTY sind
if [[ $(tty) != /dev/tty* ]]; then
    echo -e "${RED}Fehler: Dieses Skript muss von einem TTY aus ausgeführt werden!${NC}"
    echo "Wechseln Sie mit Strg+Alt+F2 zu einem TTY und melden Sie sich an."
    exit 1
fi

# 2. SDDM stoppen und deaktivieren
echo -e "${GREEN}=== Beende Display-Manager (SDDM) ===${NC}"
if systemctl is-active --quiet sddm; then
    echo -e "${YELLOW}SDDM ist aktiv. Stoppe Dienst...${NC}"
    sudo systemctl stop sddm
    sudo systemctl disable sddm
    confirm "SDDM wurde gestoppt. Fortfahren?"
else
    echo -e "${GREEN}SDDM ist bereits inaktiv.${NC}"
fi


# 3. LXQt restlos entfernen
echo -e "${GREEN}=== Entferne LXQt vollständig ===${NC}"
confirm "LXQt und alle Komponenten deinstallieren? Dies ist unwiderruflich!"

LXQT_PKGS=(
    feathernotes feathernotes-l10n featherpad featherpad-l10n libfmqt12 
    liblxqt-globalkeys-ui1 liblxqt-l10n liblxqt1 libxfce4ui-2-0 
    libxfce4ui-common libxfce4util-bin libxfce4util-common libxfce4util7 
    libxfconf-0-3 lilxqt-globalkeys1 lximage-qt lximage-qt-l10n lxqt 
    lxqt-about lxqt-about-l10n lxqt-admin lxqt-admin-l10n lxqt-branding-debian 
    lxqt-config lxqt-config-l10n lxqt-core lxqt-globalkeys lxqt-globalkeys-l10n 
    lxqt-l10n lxqt-notificationd lxqt-openssh-askpass lxqt-openssh-askpass-l10n 
    lxqt-panel lxqt-panel-l10n lxqt-policykit lxqt-policykit-l10n 
    lxqt-powermanagement lxqt-powermanagement-l10n lxqt-qtplugin lxqt-runner 
    lxqt-runner-l10n lxqt-session lxqt-sudo lxqt-sudo-l10n lxqt-system-theme 
    lxqt-theme-debian lxqt-themes meteo-qt meteo-qt-l10n pavucontrol-qt 
    pcmanfm-qt pcmanfm-qt-l10n qlipper qpdfview qpdfview-djvu-plugin 
    qpdfview-pdf-poppler-plugin qpdfview-ps-plugin qpdfview-translations qps 
    qterminal qterminal-l10n quassel quassel-data screengrab task-lxqt-desktop 
    xarchiver xfwm4 xfwm4-theme-breeze
)

sudo apt purge -y "${LXQT_PKGS[@]}"
sudo apt autoremove --purge -y

# 4. System vorbereiten
echo -e "${GREEN}=== Systemvorbereitung ===${NC}"
confirm "Systemaktualisierung durchführen?"

sudo apt -y install aptitude vim
sudo aptitude update
sudo aptitude full-upgrade
sudo apt -y autoremove --purge
sudo apt-get clean

# 5. Nicht-Debian-Pakete entfernen
echo -e "${GREEN}=== Nicht-Debian-Pakete bereinigen ===${NC}"
confirm "Nicht-Debian-Pakete anzeigen und entfernen?"

NON_DEBIAN=$(aptitude search '?narrow(?installed, ?not(?origin(Debian)))' -F "%p")
if [[ -n "$NON_DEBIAN" ]]; then
    echo -e "${YELLOW}Folgende Nicht-Debian-Pakete wurden gefunden:${NC}"
    echo "$NON_DEBIAN"
    confirm "Diese Pakete entfernen?"
    sudo aptitude purge $NON_DEBIAN
else
    echo -e "${GREEN}Keine Nicht-Debian-Pakete gefunden.${NC}"
fi

# 6. Obsolete Pakete entfernen
echo -e "${GREEN}=== Obsolete Pakete bereinigen ===${NC}"
confirm "Obsolete Pakete anzeigen und entfernen?"

OBSOLETE=$(aptitude search '~o' -F "%p")
if [[ -n "$OBSOLETE" ]]; then
    echo -e "${YELLOW}Folgende obsolete Pakete wurden gefunden:${NC}"
    echo "$OBSOLETE"
    confirm "Diese Pakete entfernen?"
    sudo aptitude purge $OBSOLETE
else
    echo -e "${GREEN}Keine obsolete Pakete gefunden.${NC}"
fi

# 7. Paketquellen auf Trixie umstellen
echo -e "${GREEN}=== Paketquellen auf Trixie umstellen ===${NC}"
confirm "Paketquellen auf Debian Trixie aktualisieren?"

sudo tee /etc/apt/sources.list <<EOF
deb http://mirror.ipb.de/debian/ trixie main contrib non-free
deb http://mirror.ipb.de/debian/ trixie-updates main contrib non-free
deb http://deb.debian.org/debian-security trixie-security main
EOF

sudo apt modernize-sources

# 8. Signed-By in .sources-Dateien ergänzen
echo -e "${GREEN}=== Signed-By-Zeilen ergänzen ===${NC}"
for file in /etc/apt/sources.list.d/*.sources; do
    if grep -q '^Signed-By: *$' "$file"; then
        echo "🛠️  Ergänze Signed-By in $file ..."
        sudo sed -i "s|^Signed-By: *$|Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg|" "$file"
    fi
done

# 9. Upgrade durchführen
echo -e "${GREEN}=== Upgrade auf Trixie durchführen ===${NC}"
confirm "Upgrade auf Debian Trixie starten? Dies kann einige Zeit dauern."

sudo apt update
sudo apt upgrade --without-new-pkgs
sudo apt full-upgrade
sudo apt -y autoremove --purge

# 10. KDE Plasma installieren
echo -e "${GREEN}=== KDE Plasma installieren ===${NC}"
confirm "KDE Plasma Desktop installieren?"

sudo tasksel install kde-desktop

# 11. Finale Bereinigung
echo -e "${GREEN}=== Finale Bereinigung ===${NC}"
confirm "Letzte Bereinigungen durchführen?"

sudo apt -y install deborphan
ORPHANED=$(sudo deborphan --guess-dummy)
if [[ -n "$ORPHANED" ]]; then
    echo -e "${YELLOW}Folgende verwaiste Pakete wurden gefunden:${NC}"
    echo "$ORPHANED"
    confirm "Diese Pakete entfernen?"
    sudo apt purge $ORPHANED
fi

sudo aptitude purge '~c'  # Purge entfernte Pakete

# 12. Netzwerk-Konfiguration für KDE Plasma
echo -e "${GREEN}=== Netzwerk-Konfiguration für KDE ===${NC}"

# 12a. NetworkManager.conf anpassen
echo -e "${YELLOW}>>> Aktiviere NetworkManager Management${NC}"
sudo sed -i '/^\[ifupdown\]$/,/^\[/ s/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf

# 12b. Alte interfaces-Konfiguration deaktivieren
echo -e "${YELLOW}>>> Deaktiviere legacy network-interfaces${NC}"
sudo cp /etc/network/interfaces /etc/network/interfaces.bak
sudo sed -i '/^allow-hotplug enp[0-9]s[0-9]/s/^/#/' /etc/network/interfaces
sudo sed -i '/^iface enp[0-9]s[0-9] inet dhcp/s/^/#/' /etc/network/interfaces

# 12c. Dienste neu starten
echo -e "${YELLOW}>>> Starte Netzwerkdienste neu${NC}"
sudo systemctl restart NetworkManager
sudo systemctl disable networking.service 2>/dev/null || true

echo -e "${GREEN}=== Netzwerk-Konfiguration abgeschlossen ===${NC}"

# Finale Meldung
echo -e "${GREEN}=== Upgrade vollständig abgeschlossen! ===${NC}"
echo -e "Bitte neu starten: ${YELLOW}sudo reboot${NC}"
echo -e "Protokoll: ${YELLOW}$LOG_FILE${NC}"

