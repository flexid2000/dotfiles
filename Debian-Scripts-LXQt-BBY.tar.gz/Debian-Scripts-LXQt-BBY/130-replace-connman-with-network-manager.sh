#!/bin/bash
homedi=$HOME
sudo apt-get -y install network-manager network-manager-gnome gnome-keyring
sudo systemctl stop connman.service
sudo systemctl stop connman-wait-online.service
sudo systemctl disable connman-wait-online.service
sudo systemctl mask connman-wait-online.service
sudo systemctl disable connman.service
sudo systemctl mask connman.service
sudo systemctl enable NetworkManager.service
sudo systemctl start NetworkManager.service
sudo sed -i 's/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf
if [ ! -f "/etc/network/interfaces" ]; then
  echo "/etc/network/interfaces existiert nicht"
  exit
fi
sudo sed -i 's/allow-hotplug/# allow-hotplug/' /etc/network/interfaces
nic=$(grep "allow-hotplug" /etc/network/interfaces | awk '{ print $3 }')
sudo sed -i "s|iface $nic inet dhcp|# iface $nic inet dhcp|g" /etc/network/interfaces
sudo apt -y purge connman cmst
sudo systemctl start NetworkManager.service
exit 0
