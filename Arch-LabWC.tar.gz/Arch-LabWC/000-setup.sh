#!/bin/bash

set -e

SCRIPTS=(
  "010-base-system.sh"
  "020-programs-core.sh"
  "030-configs.sh"
)

for script in "${SCRIPTS[@]}"; do
  echo "🔧 Starte $script ..."
  bash "./$script"
done

echo "✅ System vollständig eingerichtet."

exit 0
