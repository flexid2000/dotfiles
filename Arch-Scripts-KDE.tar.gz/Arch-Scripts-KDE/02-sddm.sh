#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
if [ ! -d /etc/sddm.conf.d ]; then
  sudo mkdir -p /etc/sddm.conf.d
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sudo cp confiles/kde_settings.conf /etc/sddm.conf.d
sudo sed -i 's/^timeout.*/timeout=0/' /boot/loader/loader.conf
sudo pacman --needed --noconfirm -S papirus-icon-theme kvantum qt6-multimedia-gstreamer plasma-workspace librsvg

echo "Erstelle Hintergrundsbild"
sudo mkdir -p /usr/share/sddm/backgrounds
sudo magick -size 1920x1080 xc:"#1e1e2e" /usr/share/sddm/backgrounds/schwarz.png

echo "📄 Schreibe theme.conf.user für breez ..."
sudo tee /usr/share/sddm/themes/breeze/theme.conf.user > /dev/null <<EOF
[General]
background=/usr/share/sddm/backgrounds/schwarz.png
type=image
EOF

echo "👤 Setze individuelles Benutzer-Icon ..."
sudo rm -f /usr/share/sddm/faces/.face.icon
rsvg-convert -a -w 144 -f svg /usr/share/icons/Papirus/22x22/apps/distributor-logo-archlinux.svg -o /tmp/face.svg
mv /tmp/face.svg ~/.face.icon
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon

echo "🔐 Setze Berechtigungen für SDDM auf Benutzericon ..."
setfacl -m u:sddm:x "$HOME"
setfacl -m u:sddm:r "$HOME/.face.icon"

echo "✅ Alles erledigt."

exit 0
