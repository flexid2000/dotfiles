#!/bin/bash
sudo nala install git sddm-theme-breeze desktop-base librsvg2-bin imagemagick papirus-icon-theme
sudo sed -i 's/=5/=0/' /etc/default/grub
sudo sed -i '/GRUB_TIMEOUT=0/a GRUB_TIMEOUT_STYLE=hidden' /etc/default/grub
sudo update-grub
# Set Default Stop Time to 20 sec
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/materia-kde/master/install.sh | sh
sudo sed -i 's/CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
if [ ! -d "$HOME/Bilder/artwork" ]; then
  mkdir -p ~/Bilder/artwork
fi
cp artwork/bby-wallpaper-shortcuts.png artwork/clipboard-dark.png ~/Bilder/artwork
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze/' /etc/sddm.conf
sudo sed -i 's/^InputMethod=qtvirtualkeyboard/InputMethod=/' /etc/sddm.conf
convert -size 16x9 xc:'#44475A' -density 72 sddm-background.png
sudo mv sddm-background.png /usr/share/sddm/themes/breeze
sudo printf '[General]\nbackground=sddm-background.png\ntype=image\n' > theme.conf.user
sudo mv theme.conf.user /usr/share/sddm/themes/breeze
sudo rm /usr/share/sddm/faces/.face.icon
rsvg-convert -a -w 144 -f svg /usr/share/icons/Papirus/22x22@2x/apps/distributor-logo-debian.svg -o /tmp/face.svg
mv /tmp/face.svg ~/.face
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon
setfacl -m u:sddm:x ~/
setfacl -m u:sddm:r ~/.face.icon
exit 0

