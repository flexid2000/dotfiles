## Anmerkungen

- Datum: 23.12.2024
- Debian 13 (Trixie)
- In den Repositories fehlen:
    - gimp
    - gimp-plugin-repository
    - speedcrunch
    - software-properties-gtk  
- `730-qemu-shared-folder` führt zu Bootversagen
- Kurzbefehle für `KWIN` funktionieren nicht
	- Lösung: `cp /etc/xdg/autostart/kglobalacceld.desktop ~/.config/autostart`
	- `OnlyShowIn=KDE` entfernen
- `kvantum-qt6` noch nicht vorhanden
	- Lösung:
	- Deinstallaltion von `qt5-style-kvantum` und abhängiger Paketen
	- Installation aus den Ubuntu 24.10 Repositories:
	- <https://packages.ubuntu.com/search?keywords=qt6-style-kvantum&searchon=names&suite=all&section=all>


