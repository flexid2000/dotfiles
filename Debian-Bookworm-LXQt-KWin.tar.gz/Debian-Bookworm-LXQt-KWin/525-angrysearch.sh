#!/bin/bash
VER=1.0.3
sudo apt-get install python3-pyqt5 xdg-utils python3-gi xdotool
sudo mkdir /usr/share/angrysearch
wget https://github.com/DoTheEvo/ANGRYsearch/archive/refs/tags/v$VER.tar.gz
tar xzf v$VER.tar.gz
rm v$VER.tar.gz
cd ANGRYsearch-$VER/
chmod +x install.sh
sudo ./install.sh
rm -r ../ANGRYsearch-$VER/
exit 0
