#!/bin/bash
for f in "$@"; do
	pandoc --reference-doc=$HOME/.local/share/pandoc/custom-reference-12pt.odt -o "${f%.*}".odt "$f"
done
exit 0
