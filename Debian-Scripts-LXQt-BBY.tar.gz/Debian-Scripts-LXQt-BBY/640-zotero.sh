#!/bin/bash
wget -qO- https://zotero.retorque.re/file/apt-package-archive/install.sh | sudo bash
sudo apt-fast -y update
sudo apt-fast -y install zotero
exit 0
