alias upgrade='sudo apt update && sudo apt -y full-upgrade && sudo apt -y autopurge && sudo apt-get clean'

