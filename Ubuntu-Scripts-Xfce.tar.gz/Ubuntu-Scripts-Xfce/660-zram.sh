#!/bin/bash
sudo swapoff /swapfile
sudo rm -f /swapfile
sed -i '/swapfile/d' /etc/fstab
sudo apt-fast -y install systemd-zram-generator
exit 0

