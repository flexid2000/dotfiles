#!/bin/bash
sudo apt-fast -y install git
sudo sed -i 's/=5/=0/' /etc/default/grub
sudo sed -i '/GRUB_TIMEOUT=0/a GRUB_TIMEOUT_STYLE=hidden' /etc/default/grub
sudo update-grub
# Set Default Stop Time to 20 sec
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
sudo apt-fast -y install qml-module-qtgraphicaleffects qml-module-qtquick-controls2 libqt5quickcontrols2-5
git clone https://gitlab.com/isseigx/simplicity-sddm-theme.git
sudo cp -r simplicity-sddm-theme/simplicity /usr/share/sddm/themes
sudo rm -r simplicity-sddm-theme
echo "[General]" > /tmp/theme.conf.user
echo "background=/usr/share/sddm/themes/simplicity/images/background.png" >> /tmp/theme.conf.user
sudo cp /tmp/theme.conf.user /usr/share/sddm/themes/simplicity/
#wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/materia-kde/master/install.sh | sh
if ! command -v convert &> /dev/null
then
    sudo apt-fast -y install imagemagick graphicsmagick
fi
sudo apt -y install breeze-cursor-theme
#sudo convert /usr/share/desktop-base/homeworld-theme/login/background-nologo.svg /usr/share/sddm/themes/materia/images/background.png
#sudo sed -i 's/Session=/Session=lxqt.desktop/' /etc/sddm.conf
#sudo sed -i "s|User=|User=${myuser}|g" /etc/sddm.conf
sudo sed -i 's/Current=debian-theme/Current=simplicity/' /etc/sddm.conf
#sudo sed -i 's/Current=debian-theme/Current=materia/' /etc/sddm.conf
sudo sed -i 's/CursorTheme=/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo cp artwork/background.png /usr/share/sddm/themes/simplicity/images
sudo cp artwork/grub-4x3.png ~/Downloads/Debian-Scripts-LXQt-BBY/artwork/grub-16x9.png /usr/share/desktop-base/active-theme/grub
if [ ! -d "$HOME/Bilder/artwork" ]; then
  mkdir -p ~/Bilder/artwork
fi
cp artwork/bby-wallpaper-shortcuts.png ~/Bilder/artwork
exit 0

