alias upgrade='sudo apt update && sudo apt -y full-upgrade && sudo apt -y autoremove --purge && sudo apt-get clean'
alias slug='slugify.sh '
