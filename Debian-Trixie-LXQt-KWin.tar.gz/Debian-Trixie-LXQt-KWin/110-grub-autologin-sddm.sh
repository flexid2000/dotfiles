#!/bin/bash
sudo apt-get install git sddm-theme-breeze desktop-base librsvg2-bin imagemagick papirus-icon-theme arc-kde
sudo sed -i 's/=5/=0/' /etc/default/grub
sudo sed -i '/GRUB_TIMEOUT=0/a GRUB_TIMEOUT_STYLE=hidden' /etc/default/grub
convert -size 16x9 xc:'#000000' -density 72 grub-16x9.png
convert -size 4x3 xc:'#000000' -density 72 grub-4x3.png
sudo mv grub-4x3.png grub-16x9.png /usr/share/desktop-base/active-theme/grub
sudo update-grub
# Set Default Stop Time to 20 sec
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
sudo sed -i 's/CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
if [ ! -d "$HOME/Bilder/artwork" ]; then
  mkdir -p ~/Bilder/artwork
fi
cp artwork/bby-wallpaper-shortcuts.png ~/Bilder/artwork
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze/' /etc/sddm.conf
sudo sed -i 's/^InputMethod=qtvirtualkeyboard/InputMethod=/' /etc/sddm.conf
convert -size 16x9 xc:'#44475A' -density 72 sddm-background.png
sudo mv sddm-background.png /usr/share/sddm/themes/breeze
sudo printf '[General]\nbackground=sddm-background.png\ntype=image\n' > theme.conf.user
sudo mv theme.conf.user /usr/share/sddm/themes/breeze
sudo rm /usr/share/sddm/faces/.face.icon
cp /etc/skel/.face ~/
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon
setfacl -m u:sddm:x ~/
setfacl -m u:sddm:r ~/.face.icon
exit 0

