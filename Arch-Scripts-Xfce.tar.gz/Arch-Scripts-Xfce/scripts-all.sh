#!/bin/bash
sh 01-autologin.sh
sh 02-autostart.sh
sh 03-paru.sh
sh 04-confiles.sh
sh 06-programs-install.sh
sh 08-deemix.sh
sh 09-recoll.sh
exit 0
