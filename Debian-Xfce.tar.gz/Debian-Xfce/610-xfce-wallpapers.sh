#!/bin/bash
set -e

if [ ! -d "$HOME/Bilder/wallpaper" ]; then
  mkdir -p ~/Bilder/wallpapers
fi
cp /usr/share/backgrounds/bluebird.svg /usr/share/backgrounds/greybird.svg ~/Bilder/wallpapers
cp /usr/share/backgrounds/xfce/* ~/Bilder/wallpapers/
cp /usr/share/desktop-base/futureprototype-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/futureprototype.svg
cp /usr/share/desktop-base/homeworld-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/homeworld.svg
cp /usr/share/desktop-base/joy-inksplat-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/joy-inksplat.svg
cp /usr/share/desktop-base/joy-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/joy.svg
cp /usr/share/desktop-base/lines-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/lines.svg
cp /usr/share/desktop-base/moonlight-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/moonlight.svg
cp /usr/share/desktop-base/softwaves-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/softwaves.svg
cp /usr/share/desktop-base/spacefun-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpapers/spacefun.svg
cp artwork/babylonia* ~/Bilder/wallpapers/
wget https://raw.githubusercontent.com/lxqt/lxqt-themes/master/wallpapers/simple_blue_widescreen.png
mv simple_blue_widescreen.png ~/Bilder/wallpapers

exit 0
