#!/bin/bash
sudo apt purge qt5-style-kvantum qt5-style-kvantum-l10n
wget http://de.archive.ubuntu.com/ubuntu/pool/universe/q/qt6-style-kvantum/qt6-style-kvantum_1.1.2-0ubuntu1_amd64.deb
wget http://de.archive.ubuntu.com/ubuntu/pool/universe/q/qt6-style-kvantum/qt6-style-kvantum-l10n_1.1.2-0ubuntu1_all.deb
wget http://de.archive.ubuntu.com/ubuntu/pool/universe/q/qt6-style-kvantum/qt6-style-kvantum-themes_1.1.2-0ubuntu1_all.deb
sudo dpkg -i qt6-style-kvantum_1.1.2-0ubuntu1_amd64.deb qt6-style-kvantum-l10n_1.1.2-0ubuntu1_all.deb qt6-style-kvantum-themes_1.1.2-0ubuntu1_all.deb
exit 0

