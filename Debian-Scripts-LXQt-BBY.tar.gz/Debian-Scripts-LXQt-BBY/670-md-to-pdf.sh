#!/bin/bash
if [ ! -f /usr/bin/curl ]; then
	sudo apt-fast -y install curl
fi
curl -fsSL https://deb.nodesource.com/setup_current.x | sudo bash -
sudo apt-fast -y install nodejs
sudo npm i -g md-to-pdf
cp confiles/md-to-pdf.sh ~/.local/bin/
cp confiles/md-to-pdf.desktop ~/.local/share/file-manager/actions/
exit 0

