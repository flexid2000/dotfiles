#!/bin/bash
# install Persepolis Download Manager Integration Chrome extension
sudo pacman -S --noconfirm --needed persepolis
echo $HOME
if [ ! $HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts ] ; then
	mkdir -p ~/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts
fi
echo "{"name": "com.persepolis.pdmchromewrapper", "type": "stdio", "path": "$HOME/.config/persepolis_download_manager/persepolis_run_shell", "description": "Integrate Persepolis with chromium using WebExtensions", "allowed_origins": ["chrome-extension://legimlagjjoghkoedakdjhocbeomojao/"]}" > ~/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts/com.persepolis.pdmchromewrapper.json
exit 0

