#!/bin/bash
set -e

SCRIPTS=(
  "010-base-system.sh"
  "020-zram.sh"
  "030-pipewire.sh"
  "110-grub-autologin-sddm.sh"
  "300-programs-core.sh"
  "310-tools.sh"
  "320-desktop.sh"
  "400-servicemenus.sh"
  "410-dotfiles.sh"
  "420-recoll.sh"
  "430-autostart.sh"
  "500-touchpad-settings.sh"
  "510-plymouth.sh"
  "520-kvantum-qt6.sh"
  "610-courier-prime-fonts.sh"
  "630-signal-desktop.sh"
  "640-zotero.sh"
  "650-joplin.sh"
  "660-brave-browser.sh"
  "740-marktext.sh"
  "760-spotify-adblock-trixie.sh"
  "900-kernel-remover.sh"
)

for script in "${SCRIPTS[@]}"; do
  echo "🔧 Starte $script ..."
  bash "./$script"
done

echo "✅ System vollständig eingerichtet."

