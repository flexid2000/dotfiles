#!/bin/bash
wget https://typora.io/linux/typora_0.11.18_amd64.deb
sudo dpkg -i typora_0.11.18_amd64.deb
rm typora_0.11.18_amd64.deb
sudo apt install ghostwriter cmark discount pandoc wkhtmltopdf context-nonfree
exit 0
