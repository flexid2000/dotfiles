#!/bin/bash
# Skript zum Automatisieren der Umstellung auf Deutsch unter Debian Bookworm LXQt nach Installation mit mini.iso
# Führt die Locale-Umstellung und die Umbenennung der Benutzerordner im HOME-Verzeichnis durch.

set -e

# 1. Locale systemweit auf de_DE.UTF-8 setzen
echo "Setze Locale auf de_DE.UTF-8 ..."
sudo sed -i '/^en_US.UTF-8 UTF-8/s/^/# /' /etc/locale.gen
sudo sed -i '/^de_DE.UTF-8 UTF-8/s/^# //' /etc/locale.gen
sudo locale-gen
sudo update-locale LANG=de_DE.UTF-8 LC_ALL=de_DE.UTF-8

# 2. LXQt-Settings für regionales Format (optional, für LXQt eigene Settings)
CONFIG_DIR="$HOME/.config/lxqt"
mkdir -p "$CONFIG_DIR"
LOCALE_FILE="$CONFIG_DIR/lxqt-config-locale.conf"
cat <<EOF > "$LOCALE_FILE"
[General]
LANG=de_DE.UTF-8
LC_NUMERIC=de_DE.UTF-8
LC_TIME=de_DE.UTF-8
LC_MONETARY=de_DE.UTF-8
LC_MEASUREMENT=de_DE.UTF-8
LC_COLLATE=de_DE.UTF-8
EOF
echo "LXQt Locale-Konfiguration geschrieben: $LOCALE_FILE"

# 3. HOME-Verzeichnisse ins Deutsche umbenennen und XDG-User-Dirs anpassen
declare -A ORDNER=( ["Desktop"]="Schreibtisch" ["Documents"]="Dokumente" ["Music"]="Musik" ["Pictures"]="Bilder" ["Public"]="Öffentlich" ["Templates"]="Vorlagen" )
USERDIRSF="$HOME/.config/user-dirs.dirs"

echo "Benutzerordner umbenennen und XDG-Konfiguration anpassen ..."
for ENG in "${!ORDNER[@]}"; do
    [ -d "$HOME/$ENG" ] && mv "$HOME/$ENG" "$HOME/${ORDNER[$ENG]}"
done

# Schreibe neue user-dirs.dirs
cat <<EOF > "$USERDIRSF"
XDG_DESKTOP_DIR="\$HOME/Schreibtisch"
XDG_DOCUMENTS_DIR="\$HOME/Dokumente"
XDG_MUSIC_DIR="\$HOME/Musik"
XDG_PICTURES_DIR="\$HOME/Bilder"
XDG_PUBLICSHARE_DIR="\$HOME/Öffentlich"
XDG_TEMPLATES_DIR="\$HOME/Vorlagen"
XDG_TEMPLATES_DIR="\$HOME/Downloads"
XDG_TEMPLATES_DIR="\$HOME/Videos"
EOF

echo "Neue Ordnernamen und XDG-User-Dirs gesetzt."

# 4. Optionale Anpassung der Umgebungsvariablen beim nächsten Start
grep -q 'LANG=de_DE.UTF-8' ~/.profile || echo 'export LANG=de_DE.UTF-8' >> ~/.profile

echo "Fertig. Bitte ab- und wieder anmelden, damit die Änderungen übernommen werden."
