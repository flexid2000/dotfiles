#!/bin/bash
#
# sources.list anpassen
#
sudo apt-get install curl
echo "deb http://mirror.ipb.de/debian/ forky main contrib non-free" > /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ forky-updates main contrib non-free" >> /tmp/sources.list
#echo "deb http://mirror.ipb.de/debian/ trixie-backports main contrib non-free" >> /tmp/sources.list
echo "deb http://deb.debian.org/debian-security forky-security main" >> /tmp/sources.list
sudo cp /tmp/sources.list /etc/apt
sudo apt update
sudo apt modernize-sources
sudo apt update
exit 0
