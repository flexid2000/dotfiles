#!/bin/bash

set -eu

# Catppuccin SDDM
sudo pacman -Syu --needed qt6-svg qt6-declarative qt5-quickcontrols2 \
qt5-graphicaleffects unzip breeze-cursors
wget https://github.com/catppuccin/sddm/releases/download/v1.1.2/catppuccin-mocha-blue-sddm.zip
sudo unzip catppuccin-mocha-blue-sddm.zip -d /usr/share/sddm/themes/

echo "🖼️ Konfiguriere SDDM ..."
sddm --example-config | sudo tee /etc/sddm.conf > /dev/null
sudo sed -i 's/^CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo sed -i 's/^InputMethod=qtvirtualkeyboard/InputMethod=/' /etc/sddm.conf

