#!/bin/bash
sudo apt-get -y install rename poppler-utils pandoc xclip poppler-utils mupdf-tools libnotify-bin img2pdf librsvg2-bin libc6 libgcc-s1 libqt5core5a libqt5gui5 libqt5network5 libqt5printsupport5 libqt5svg5 libqt5webkit5 libqt5widgets5 libstdc++6 python3-pikepdf python3-pil python3-deprecated python3-wrapt wkhtmltopdf
## pandoc
wget https://github.com/jgm/pandoc/releases/download/3.6.2/pandoc-3.6.2-1-amd64.deb
sudo dpkg -i pandoc-3.6.2-1-amd64.deb
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
cp file-manager-actions/custom-reference.odt ~/.local/share/pandoc
cp file-manager-actions/pagebreak.lua ~/.local/share/pandoc/filters
cp file-manager-actions/*.sh file-manager-actions/*.css ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
exit 0
