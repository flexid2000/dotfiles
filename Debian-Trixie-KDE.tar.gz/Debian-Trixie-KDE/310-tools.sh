#!/bin/bash
set -e

echo "🧰 Installiere Dienstprogramme und Fonts ..."
sudo apt-get install -y \
    fonts-croscore fonts-inter fonts-firacode \
    ttf-mscorefonts-installer \

mkdir -p ~/.local/bin ~/.local/share/applications ~/.config/yt-dlp
cp confiles/config ~/.config/yt-dlp
cp confiles/.bash_aliases ~/

echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile

sudo cp confiles/local.conf /etc/fonts
sudo fc-cache -frv

echo -e 'SAL_USE_VCLPLUGIN=qt6' | sudo tee -a /etc/environment > /dev/null

wget https://altushost-swe.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt

echo "✅ Tools & Fonts konfiguriert."

