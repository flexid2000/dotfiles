#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget https://www.dropbox.com/scl/fi/yyrz4mydrlseepc2hi4d8/deemix-linux-x64.deb?rlkey=1n8xr29xe446wj997mauq52vf
mv deemix-linux-x64.deb?rlkey=1n8xr29xe446wj997mauq52vf ~/.local/bin/deemix.AppImage
chmod 755 ~/.local/bin/deemix.AppImage
cp confiles/deemix.desktop ~/.local/share/applications
exit 0



