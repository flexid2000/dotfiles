#!/bin/bash
#
# sources.list in Debian bullseye anpassen
#
sudo apt-get install curl
echo "deb http://mirror.ipb.de/debian/ bookworm main contrib non-free" > /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ bookworm-updates main contrib non-free" >> /tmp/sources.list
#echo "deb http://mirror.ipb.de/debian/ bullseye-backports main contrib non-free" >> /tmp/sources.list
echo "deb http://deb.debian.org/debian-security bookworm-security main" >> /tmp/sources.list
sudo cp /tmp/sources.list /etc/apt
sudo apt update
exit 0
