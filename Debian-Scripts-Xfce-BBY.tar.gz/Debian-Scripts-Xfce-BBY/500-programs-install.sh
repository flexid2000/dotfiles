#!/bin/bash
sudo apt update
sudo apt -y -t bullseye-backports install libreoffice libreoffice-l10n-de libreoffice-help-de libreoffice-style-sifr
sudo apt update
sudo apt -y install alsa-firmware-loaders apt-transport-https arandr arc-theme arj audacious baobab bleachbit blueman bluetooth bluez-cups bluez-firmware bluez-obexd bluez-tools breeze-cursor-theme cabextract calibre catfish clementine fonts-sil-charis conky cups cups-browsed cups-client cups-common cups-core-drivers cups-filters cups-filters-core-drivers cups-ipp-utils cups-pk-helper cups-ppdc cups-server-common curl dconf-editor default-jre default-jre-headless dkms exfalso file-roller evince faad feh ffmpeg ffmpegthumbnailer firmware-linux flac flvstreamer fonts-cantarell fonts-croscore fonts-inconsolata fonts-roboto-unhinted galternatives gcolor3 geany ghostwriter gigolo gimagereader gimp gimp-help-de gimp-plugin-registry git gnome-font-viewer gnome-calculator gnome-packagekit gnome-system-tools gpa gparted grsync gstreamer1.0-gtk3 gvfs-backends gvfs-bin gvfs-fuse hardinfo haveged htop hunspell hwinfo imagemagick lame libcanberra-pulse libdvd-pkg libgpod-dev libimobiledevice-dev lightdm-gtk-greeter-settings menu-xdg mjpegtools mpv mtp-tools murrine-themes netselect-apt nextcloud-desktop ntp numlockx papirus-icon-theme pdfarranger plank playerctl plymouth-themes plymouth-x11 poppler-utils pulseaudio-module-bluetooth python3-pyinotify qt5-style-kvantum qt5-style-kvantum-l10n qt5-style-kvantum-themes qt5-style-plugins qt5ct redshift-gtk rar rfkill scrot seahorse shotwell simple-scan smplayer software-properties-gtk soundconverter subversion task-laptop task-german task-german-desktop task-xfce-desktop tesseract-ocr tesseract-ocr-deu tesseract-ocr-eng thunderbird thunderbird-l10n-de transmission-gtk ttf-bitstream-vera ttf-mscorefonts-installer ttf-ubuntu-font-family tumbler-plugins-extra unace unclutter unrar vlc vnstat vorbis-tools wavpack wmctrl wv wx-common xbindkeys xdg-user-dirs-gtk xdg-utils xdotool xsettingsd xpad zip
sudo apt -y purge atril quodlibet
sudo apt -y autoremove --purge
sudo dpkg-reconfigure libdvd-pkg
sudo systemctl enable bluetooth.service
sudo systemctl start bluetooth.service
sudo sed -i 's/'#AutoEnable=false'/'AutoEnable=true'/g' /etc/bluetooth/main.conf
exit 0
