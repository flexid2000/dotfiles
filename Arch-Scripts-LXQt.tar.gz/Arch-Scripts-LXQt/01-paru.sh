#!/bin/bash
sudo pacman -S --needed base-devel git accountsservice haveged reflector bat rsync
sudo systemctl enable accounts-daemon.service
sudo systemctl enable haveged.service
git clone https://aur.archlinux.org/paru-bin
cd paru-bin
makepkg -si
sudo reflector --protocol http,https --country Germany --latest 5 --sort rate --save /etc/pacman.d/mirrorlist
sudo pacman -Syu
exit 0
