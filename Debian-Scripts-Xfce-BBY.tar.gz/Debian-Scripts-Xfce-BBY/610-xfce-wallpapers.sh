#!/bin/bash
if [ ! -d "$HOME/Bilder/wallpaper" ]; then
  mkdir -p ~/Bilder/wallpaper
fi
cp /usr/share/backgrounds/bluebird.svg /usr/share/backgrounds/greybird.svg ~/Bilder/wallpaper
cp /usr/share/backgrounds/xfce/* ~/Bilder/wallpaper/
cp /usr/share/desktop-base/futureprototype-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/futureprototype.svg
cp /usr/share/desktop-base/homeworld-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/homeworld.svg
cp /usr/share/desktop-base/joy-inksplat-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/joy-inksplat.svg
cp /usr/share/desktop-base/joy-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/joy.svg
cp /usr/share/desktop-base/lines-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/lines.svg
cp /usr/share/desktop-base/moonlight-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/moonlight.svg
cp /usr/share/desktop-base/softwaves-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/softwaves.svg
cp /usr/share/desktop-base/spacefun-theme/wallpaper/contents/images/1920x1080.svg ~/Bilder/wallpaper/spacefun.svg
cp artwork/babylonia* ~/Bilder/wallpaper/
exit 0
