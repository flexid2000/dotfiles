#!/bin/bash
sleep 5
xset +dpms
xset s 600 600
xset dpms 600 600 600
exit 0

