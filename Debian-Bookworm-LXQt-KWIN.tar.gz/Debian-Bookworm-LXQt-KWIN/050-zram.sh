#!/bin/bash
sudo apt-get -y install systemd-zram-generator
exit 0
