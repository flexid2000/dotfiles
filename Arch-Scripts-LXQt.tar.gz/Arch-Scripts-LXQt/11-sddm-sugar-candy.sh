#!/bin/bash
sudo pacman -S --needed --noconfirm sddm qt5-graphicaleffects qt5-quickcontrols2 qt5-svg
wget https://framagit.org/MarianArlt/sddm-sugar-candy/-/archive/master/sddm-sugar-candy-master.tar.gz
mv sddm-sugar-candy-master.tar.gz sugar-candy.tar.gz
sudo tar -xzvf sugar-candy.tar.gz -C /usr/share/sddm/themes
exit 0
