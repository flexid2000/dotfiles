#!/bin/bash
sudo sed -i 's/=5/=0/' /etc/default/grub
sudo sed -i '/GRUB_TIMEOUT=0/a GRUB_TIMEOUT_STYLE=hidden' /etc/default/grub
sudo update-grub
# Set Default Stop Time to 20 sec
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
sudo sed -i 's/#greeter-hide-users=false/greeter-hide-users=false/' /etc/lightdm/lightdm.conf
sudo sed -i 's/#allow-user-switching=true/allow-user-switching=true/' /etc/lightdm/lightdm.conf
sudo cp artwork/grub-4x3.png artwork/grub-16x9.png /usr/share/desktop-base/active-theme/grub
exit 0

