#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
sudo pacman -U binaries/openbox-window-snap-3.6.1-1-x86_64.pkg.tar.zst
paru -S --needed xdotool redshift obconf-qt git xpad xclip picom caffeine-ng redshift-qt libayatana-appindicator meteo-qt obconf-qt xorg-xwininfo nextcloud-client gnome-keyring seahorse
sudo cp binaries/winfuncs /usr/local/bin
cp bash-scripts/copy2clipboard.sh ~/.local/bin
exit 0
