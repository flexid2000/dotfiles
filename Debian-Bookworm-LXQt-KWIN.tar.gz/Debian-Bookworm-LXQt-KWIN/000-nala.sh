#"/bin/bash
pkgver=0.15.2
sudo apt-get -y install python3-anyio python3-h11 python3-httpcore python3-httpx python3-sniffio python3-tomli python3-typer python3-pexpect python3-ptyprocess python3-typing-extensions curl git vim
wget -q https://gitlab.com/volian/nala/uploads/e230845dd7df230898bd96cacec15978/nala_${pkgver}_all.deb
sudo dpkg -i nala_${pkgver}_all.deb
rm nala_${pkgver}_all.deb
sudo nala fetch
sudo nala update
sudo nala full-upgrade
exit 0

