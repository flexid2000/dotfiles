#!/bin/bash
paru -S --needed recoll chmlib xapian-core qt5-base qt5-webkit libxslt unzip poppler pstotext antiword catdoc unrtf djvulibre id3lib python-mutagen perl-image-exiftool python-lxml python-pychm aspell-de aspell-en cronie
mkdir -p ~/.recoll
cp confiles/mimeview ~/.recoll/
cp confiles/recoll.conf ~/.recoll/
sudo cp confiles/recoll-index /etc/cron.daily/
exit 0
