#!/bin/bash

# Skript zum Wechsel von LXQt zu KDE Plasma auf Debian Trixie
# Bereinigt um Problemquellen und mit stabilen Paketquellen

# Farben für die Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funktion zur Überprüfung, ob ein Befehl erfolgreich war
check_command() {
    if [ $? -ne 0 ]; then
        echo -e "${RED}Fehler beim Ausführen des vorherigen Befehls${NC}"
        echo -e "${YELLOW}Möchten Sie fortfahren? (j/n)${NC}"
        read -r answer
        if [ "$answer" != "${answer#[Jj]}" ]; then
            echo "Fortfahren..."
        else
            echo "Abbruch."
            exit 1
        fi
    fi
}

# Überprüfen, ob das Skript als root ausgeführt wird
if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}Dieses Skript muss mit root-Rechten ausgeführt werden!${NC}"
    echo "Versuchen Sie es mit sudo zu starten: sudo $0"
    exit 1
fi

# Repository-Probleme bereinigen
echo -e "${YELLOW}Bereinige Paketquellen...${NC}"
if [ -f "/etc/apt/sources.list.d/backports.list" ]; then
    rm /etc/apt/sources.list.d/backports.list
fi
apt update

echo -e "${GREEN}=== Beginn der Umstellung von LXQt zu KDE Plasma ===${NC}"

# 1. System aktualisieren
echo -e "${YELLOW}Systemaktualisierung wird durchgeführt...${NC}"
apt update && apt upgrade -y
check_command

# 2. LXQt und zugehörige Komponenten deinstallieren
echo -e "${YELLOW}Deinstalliere LXQt und zugehörige Komponenten...${NC}"
apt purge --auto-remove -y \
breeze-icon-theme featherpad liblxqt-backlight-helper liblxqt-l10n \
liblxqt2 lximage-qt lxmenu-data lxqt-admin lxqt-admin-l10n \
lxqt-archiver lxqt-archiver-l10n lxqt-branding-debian lxqt-config \
lxqt-core lxqt-panel lxqt-session lxqt-sudo lxqt-sudo-l10n \
lxqt-system-theme lxqt-theme-debian obconf openbox oxygen-icon-theme \
pavucontrol-qt pcmanfm-qt qps qterminal screengrab libfm-qt6-15 \
lxqt-menu-data

# Bereinigung von nicht mehr benötigten Paketen
apt autoremove -y
apt autoclean
check_command

# 3. KDE Plasma und empfohlene Anwendungen installieren
echo -e "${YELLOW}Installiere KDE Plasma und empfohlene Anwendungen...${NC}"

# Hauptpakete installieren
apt install -y \
    task-kde-desktop \
    sddm \
    sddm-theme-breeze \
    kde-config-gtk-style \
    kde-config-screenlocker \
    kde-config-sddm \
    kde-style-breeze \
    kdegraphics-thumbnailers \
    kdenetwork-filesharing \
    kscreen \
    kwin-x11 \
    dolphin \
    konsole \
    kate \
    gwenview \
    ark

# Optionale KDE-Anwendungen (verfügbare Alternativen)
apt install -y \
    plasma-widgets-addons \
    plasma-nm \
    plasma-pa \
    kwalletmanager \
    partitionmanager

check_command

# 4. Display Manager auf SDDM umstellen
echo -e "${YELLOW}Setze SDDM als Display Manager...${NC}"
systemctl enable sddm
check_command

# 5. Breeze-Themes und Icons einrichten
echo -e "${YELLOW}Richte Breeze-Themes und Icons ein...${NC}"
apt install -y breeze-icon-theme breeze-gtk-theme
check_command

# 6. System bereinigen
echo -e "${YELLOW}Bereinige das System...${NC}"
apt autoremove -y
apt autoclean

echo -e "${GREEN}=== Umstellung abgeschlossen ===${NC}"
echo -e "Das System wurde erfolgreich auf KDE Plasma umgestellt."
echo -e "Bitte starten Sie das System neu, um die Änderungen zu übernehmen:"
echo -e "reboot"
