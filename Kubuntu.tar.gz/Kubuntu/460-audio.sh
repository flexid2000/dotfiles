!/bin/bash
sudo apt-fast -y install pipewire gstreamer1.0-pipewire pipewire-bin pipewire-pulse wireplumber yt-dlp
systemctl --user --now enable wireplumber.service
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
