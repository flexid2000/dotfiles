#!/bin/bash
wget https://github.com/marktext/marktext/releases/latest/download/marktext-x86_64.AppImage
if [ ! $HOME/.local/bin ] ; then
	mkdir -p $HOME/.local/bin
fi
mv marktext-x86_64.AppImage ~/.local/bin
chmod 755 ~/.local/bin/marktext-x86_64.AppImage
if [ ! $HOME/.local/share/applications ] ; then
	mkdir -p $HOME/.local/share/applications
fi
if [ ! $HOME/.local/bin/appimaged-*-x86_64.AppImage ] ; then
	wget -c https://github.com/$(wget -q https://github.com/probonopd/go-appimage/releases -O - | grep "appimaged-.*-x86_64.AppImage" | head -n 1 | cut -d '"' -f 2) -P ~/.local/bin/
	chmod 755 ~/.local/bin/appimaged-*-x86_64.AppImage
	~/.local/bin/appimaged-*-x86_64.AppImage
fi	
exit 0
