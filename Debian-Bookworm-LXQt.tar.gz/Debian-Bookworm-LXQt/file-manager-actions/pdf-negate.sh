#!/bin/bash
DIRNAME="${1%.*}"
mkdir $DIRNAME
cp "$1" "$DIRNAME"
cd "$DIRNAME"
pdftocairo -jpeg "$1"
for FILE in "*.jpg"; do
	mogrify -negate $FILE
done
img2pdf -o "$DIRNAME"-inverted.pdf *.jpg
cp "$DIRNAME"-inverted.pdf ..
rm *
cd ..
rmdir "$DIRNAME"
exit 0
