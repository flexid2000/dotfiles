#!/bin/bash
for FILE in "$@"; do
	pdftocairo -jpeg "${FILE}"
	img2pdf -o "${FILE%.*}"-a4quer.pdf -S A4^T "${FILE%.*}"-*.jpg
	rm "${FILE%.*}"-*.jpg
done
exit 0
