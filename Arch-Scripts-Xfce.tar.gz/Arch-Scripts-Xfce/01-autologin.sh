#!/bin/bash
sudo sed -i 's/timeout\ 3/timeout\ 0/' /boot/loader/loader.conf
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
sudo sed -i 's/#greeter-hide-users=false/greeter-hide-users=false/' /etc/lightdm/lightdm.conf
sudo sed -i 's/#allow-user-switching=true/allow-user-switching=true/' /etc/lightdm/lightdm.conf
sudo sed -i 's/#autologin-user=/autologin-user=kay/' /etc/lightdm/lightdm.conf
sudo sed -i 's/#autologin-session=/autologin-session=xfce/' /etc/lightdm/lightdm.conf
sudo groupadd -r autologin
sudo usermod -aG autologin kay
exit 0
