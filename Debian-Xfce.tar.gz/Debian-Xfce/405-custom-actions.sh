#!/bin/bash
sudo apt-get -y install accountsservice dkms fsearch ghostwriter ghostwriter git haveged img2pdf libc6 libgcc-s1 libnotify-bin libqt5core5t64 libqt5gui5t64 libqt5network5t64 libqt5printsupport5t64 libqt5svg5 libqt5widgets5t64 librsvg2-bin libstdc++6 mupdf-tools pandoc poppler-utils redshift redshift-gtk rename weasyprint xclip xdotool

if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
if [ ! -d "$HOME/.config/Thunar" ]; then
	mkdir -p ~/.config/Thunar
fi
cp custom-actions/uca.xml ~/.config/Thunar
cp custom-actions/custom-reference.odt ~/.local/share/pandoc
cp custom-actions/pagebreak.lua ~/.local/share/pandoc/filters
cp custom-actions/*.sh custom-actions/*.css ~/.local/bin
exit 0
