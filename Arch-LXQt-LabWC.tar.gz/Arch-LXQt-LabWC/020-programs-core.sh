#!/bin/bash

set -e

# Pakete aus den offiziellen Repos installieren
paru -S --needed accountsservice adwaita-cursors adwaita-fonts adwaita-icon-theme adwaita-qt5-git adw-gtk-theme cliphist copyq feathernotes featherpad firefox firefox-i18n-de gammastep greetd greetd-tuigreet grim gvfs gvfs-mtp haveged hunspell hunspell-de hyprpicker ibus ibus-unikey inter-font kanshi kimageformats kvantum labwc libappindicator-gtk3 libheif lxqt-wayland-session mako mesa network-manager-applet networkmanager nwg-look papirus-icon-theme pcmanfm-qt pixman qemu-guest-agent qt6ct rofi seatd slurp spice-gtk spice-vdagent swaybg swayidle swaylock ttf-croscore ttf-dejavu ttf-firacode-nerd virglrenderer vulkan-intel waybar wl-clipboard

# Pakete aus dem AUR
paru -S --needed meteo-qt wdisplays wlogout wlopm wlrctl labwc-tweaks-git labconf-git labhotkey kvantum-theme-libadwaita-git labwc-theme-adwaita lxqt-arc-dark-theme-git

