#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
if [ ! -d /etc/sddm.conf.d ]; then
  sudo mkdir -p /etc/sddm.conf.d
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sudo cp confiles/kde_settings.conf /etc/sddm.conf.d
sudo sed -i 's/^timeout.*/timeout=0/' /boot/loader/loader.conf
sudo pacman --needed -S papirus-icon-theme kvantum kvantum-qt5 arc-gtk-theme qt6-multimedia-gstreamer plasma-workspace
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze/' /etc/sddm.conf
wget https://salsa.debian.org/debian-desktop-team/desktop-base/-/raw/master/joy-theme/plymouth/background.png
sudo mv background.png /usr/share/sddm/themes/breeze
sudo printf '[General]\nbackground=background.png\ntype=image\n' > theme.conf.user
sudo mv theme.conf.user /usr/share/sddm/themes/breeze
exit 0
