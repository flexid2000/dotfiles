#!/bin/bash

set -e

sudo apt update
sudo apt -y install libfuse2t64
wget https://github.com/dynobo/normcap/releases/download/v0.6.0/NormCap-0.6.0-x86_64.AppImage
mv NormCap-0.6.0-x86_64.AppImage $HOME/.local/bin/
tee $HOME/.local/share/applications/normcap.desktop > /dev/null <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=NormCap
Comment=OCR von Screenshot
Exec=$HOME/.local/bin/NormCap-0.6.0-x86_64.AppImage
Icon=normcap
Categories=Graphics;
Terminal=false
StartupWMClass=normcap
EOF
exit 0
