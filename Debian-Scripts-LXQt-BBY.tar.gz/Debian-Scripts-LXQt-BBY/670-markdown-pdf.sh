#!/bin/bash
sudo apt-fast -y install npm
cp file-manager-actions/markdown-pdf.sh ~/.local/bin/
cp file-manager-actions/markdown-pdf.desktop ~/.local/share/file-manager/actions/
cp file-manager-actions/style.css ~/.local/bin/
cd ~/.local
sudo npm install markdown-pdf
exit 0

