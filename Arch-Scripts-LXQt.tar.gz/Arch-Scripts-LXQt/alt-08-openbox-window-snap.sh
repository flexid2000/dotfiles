#!/bin/bash
cd ~/Downloads/Arch-Scripts-LXQt/binaries
wget https://github.com/Mikachu/openbox/archive/refs/tags/release-3.6.1.tar.gz
tar -xzf release-3.6.1.tar.gz
mv openbox-release-3.6.1 openbox-3.6.1
git clone https://github.com/emilypeto/openbox-window-snap.git
cp ~/Downloads/Arch-Scripts-LXQt/binaries/openbox-window-snap/openbox-window-snap.diff /home/kay/Downloads/Arch-Scripts-LXQt/binaries/openbox-3.6.1/
cd openbox-3.6.1
git apply openbox-window-snap.diff
sudo pacman -S --needed imlib2 librsvg libsm libxcursor libxinerama libxml2 libxrandr pango startup-notification python-pyxdg obconf-qt
yay -S --needed docbook-to-man
./bootstrap
./configure --prefix=/usr --with-x --enable-startup-notification --sysconfdir=/etc --libexecdir=/usr/lib/openbox
make
sudo make install
cd ..
sudo rm -R openbox-3.6.1
rm release-3.6.1.tar.gz
exit 0
