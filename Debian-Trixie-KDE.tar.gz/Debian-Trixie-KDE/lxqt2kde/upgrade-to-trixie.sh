#!/bin/bash
set -euo pipefail

# ==================== #
# KONFIGURATION        #
# ==================== #

# Farbdefinitionen
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Protokolldatei
LOG_FILE="/var/log/debian-upgrade-$(date +%Y%m%d).log"

# ==================== #
# FUNKTIONEN           #
# ==================== #

# Funktion zur Bestätigung
confirm() {
    local prompt="$1"
    while true; do
        read -rp "${YELLOW}${prompt} (j/n)${NC} " answer
        case "$answer" in
            [JjYy]* ) return 0;;
            [Nn]* ) 
                echo -e "${RED}Abbruch durch Benutzer.${NC}"
                exit 1
                ;;
            * ) 
                echo -e "${YELLOW}Bitte mit j/ja oder n/nein antworten.${NC}"
                ;;
        esac
    done
}

# Netzwerkcheck
check_network() {
    if ! ping -c 1 deb.debian.org &>/dev/null; then
        echo -e "${RED}Netzwerkfehler! Bitte prüfen Sie:${NC}"
        echo -e "1. Ist das Netzwerkkabel eingesteckt?"
        echo -e "2. Funktionieren die DNS-Server?"
        ip -br a
        exit 1
    fi
}

# ==================== #
# HAUPTSKRIPT          #
# ==================== #

# Protokollierung starten
exec > >(tee -a "$LOG_FILE") 2>&1
echo -e "${GREEN}=== Debian Upgrade-Skript gestartet: $(date) ===${NC}"


# 0. Root-Passwort setzen (KRITISCH für sudo-Erhalt)
echo -e "${YELLOW}=== Root-Passwort setzen ===${NC}"
if ! sudo passwd root; then
    echo -e "${RED}Fehler: Root-Passwort konnte nicht gesetzt werden${NC}"
    exit 1
fi

# 1. Systemvorbereitung
echo -e "${GREEN}=== Phase 1: Systemvorbereitung ===${NC}"
check_network

confirm "Soll ich mit der Systemvorbereitung fortfahren?"
apt-get update
apt-get install -y --no-install-recommends \
    aptitude \
    apt-transport-https \
    debian-archive-keyring \
    network-manager \
    wpasupplicant

# 2. LXQt Deinstallation
echo -e "${GREEN}=== Phase 2: LXQt Deinstallation ===${NC}"
confirm "Soll LXQt vollständig deinstalliert werden?"

# Temporären Schutz für essentielle Pakete aktivieren
PROTECTED_PKGS=(sudo network-manager wpasupplicant net-tools iproute2 ifupdown resolvconf)
for pkg in "${PROTECTED_PKGS[@]}"; do
    apt-mark manual "$pkg" || apt-get install -y "$pkg"
done

# LXQt Paketliste (vollständig und validiert)
LXQT_PKGS=(
    feathernotes feathernotes-l10n featherpad featherpad-l10n libfm-qt12 
    liblxqt-globalkeys1 liblxqt-l10n liblxqt1 lximage-qt lximage-qt-l10n 
    lxqt-about lxqt-about-l10n lxqt-admin lxqt-admin-l10n lxqt-config 
    lxqt-config-l10n lxqt-core lxqt-globalkeys lxqt-globalkeys-l10n 
    lxqt-notificationd lxqt-openssh-askpass lxqt-openssh-askpass-l10n 
    lxqt-panel lxqt-panel-l10n lxqt-policykit lxqt-policykit-l10n 
    lxqt-powermanagement lxqt-powermanagement-l10n lxqt-qtplugin lxqt-runner 
    lxqt-runner-l10n lxqt-session lxqt-sudo lxqt-sudo-l10n lxqt-theme-debian 
    pcmanfm-qt pcmanfm-qt-l10n qterminal qterminal-l10n task-lxqt-desktop
)

# Deinstallation durchführen
export SUDO_FORCE_REMOVE=yes
apt-get purge -y "${LXQT_PKGS[@]}"
apt-get autoremove --purge -y
unset SUDO_FORCE_REMOVE

# Schutz zurücksetzen
for pkg in "${PROTECTED_PKGS[@]}"; do
    apt-mark auto "$pkg"
done

# 3. Systembereinigung
echo -e "${GREEN}=== Phase 3: Systembereinigung ===${NC}"
confirm "Soll das System bereinigt werden?"

# Nicht-Debian Pakete
aptitude purge '?narrow(?installed, ?not(?origin(Debian)))' --assume-yes

# Obsolete Pakete
aptitude purge '~o' --assume-yes

# Konfigurationsreste
aptitude purge '~c' --assume-yes

# 4. Upgrade auf Trixie
echo -e "${GREEN}=== Phase 4: Upgrade auf Trixie ===${NC}"
confirm "Soll das Upgrade auf Debian Trixie durchgeführt werden?"

# Quellen umstellen
cp /etc/apt/sources.list /etc/apt/sources.list.bak
cat > /etc/apt/sources.list <<EOF
deb https://deb.debian.org/debian trixie main contrib non-free
deb https://deb.debian.org/debian trixie-updates main contrib non-free
deb https://security.debian.org/debian-security trixie-security main
EOF

# Upgrade durchführen
apt-get update
apt-get upgrade --without-new-pkgs -y
apt-get dist-upgrade -y

# 5. KDE Installation
echo -e "${GREEN}=== Phase 5: KDE Plasma Installation ===${NC}"
confirm "Soll KDE Plasma installiert werden?"
tasksel install kde-desktop

# 6. Netzwerkkonfiguration
echo -e "${GREEN}=== Phase 6: Netzwerkkonfiguration ===${NC}"

# NetworkManager aktivieren
sed -i '/^\[ifupdown\]$/,/^\[/ s/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf

# Alte interfaces deaktivieren
INTERFACE=$(ip -o -4 route show default | awk '{print $5}' || echo "enp0s3")
sed -i "/^allow-hotplug ${INTERFACE}/s/^/#/" /etc/network/interfaces
sed -i "/^iface ${INTERFACE} inet dhcp/s/^/#/" /etc/network/interfaces

# Dienste neu starten
systemctl restart NetworkManager
systemctl disable networking 2>/dev/null || true

# 7. Finale Bereinigung
echo -e "${GREEN}=== Phase 7: Finale Bereinigung ===${NC}"
aptitude purge '~o' --assume-yes
apt-get autoremove --purge -y
apt-get clean

echo -e "${GREEN}=== Upgrade erfolgreich abgeschlossen! ===${NC}"
echo -e "Bitte neu starten: ${YELLOW}reboot${NC}"
echo -e "Protokoll: ${YELLOW}${LOG_FILE}${NC}"
