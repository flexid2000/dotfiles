#!/bin/bash

set -eu

sudo apt-get -y install build-essential libx11-dev libgtk-3-dev wmctrl unzip
wget https://github.com/lawl/opensnap/archive/master.zip
unzip master.zip
cd opensnap*
make
sudo make install

exit 0

