#!/bin/bash
sudo apt-get -y install xcur2png libfm4t64
cd binaries
sudo dpkg -i *
cd ..

