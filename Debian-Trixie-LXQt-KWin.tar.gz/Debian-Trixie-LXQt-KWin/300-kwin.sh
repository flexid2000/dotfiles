#!/bin/bash
sudo apt-get -y install plasma-workspace systemsettings plasma-desktop kwin-x11
cd binaries
chmod 755 *
sudo apt-get -y install xdotool redshift git xclip gvfs-fuse dbus-x11 git
exit 0
