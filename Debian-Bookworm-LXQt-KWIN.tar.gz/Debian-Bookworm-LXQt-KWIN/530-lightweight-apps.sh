#!/bin/bash
sudo nala install abiword falkon link-grammar-dictionaries-all claws-mail claws-mail-i18n aspell-de claws-mail-plugins claws-mail-extra-plugins claws-mail-themes gnumeric
exit 0
