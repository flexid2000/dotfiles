#!/bin/bash

sudo cp confiles/ubuntu.sources /etc/apt/sources.list.d/
sudo rm /etc/apt/*.list 2>/dev/null
sudo apt modernize-sources
sudo apt-file update
sudo apt update

exit 0
