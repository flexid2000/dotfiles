#!/bin/sh

if pgrep swayidle >/dev/null; then
    pkill swayidle
    notify-send -a swayidle -u critical -t 3000 -i caffeine 'AUS' 
else
    swayidle -w \
    timeout 600 'swaylock -f -c 000000' \
    timeout 900 'wlopm --off \*' \
    resume 'wlopm --on \*' \
    before-sleep 'swaylock -f -c 000000' &
    notify-send -a swayidle -u critical -t 3000 -i caffeine 'AN' 
fi
