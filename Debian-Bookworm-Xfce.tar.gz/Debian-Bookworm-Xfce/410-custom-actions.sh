#!/bin/bash
sudo apt-fast -y install accountsservice dkms git graphicsmagick-imagemagick-compat haveged img2pdf libc6 libgcc-s1 libnotify-bin libqt5core5a libqt5gui5 libqt5network5 libqt5printsupport5 libqt5svg5 libqt5webkit5 libqt5widgets5 librsvg2-bin libstdc++6 mupdf-tools pandoc poppler-utils redshift redshift-gtk rename unoconv xclip xdotool
wget https://github.com/wkhtmltopdf/packaging/releases/download/0.12.6.1-3/wkhtmltox_0.12.6.1-3.bookworm_amd64.deb
sudo dpkg -i wkhtmltox_0.12.6.1-3.bookworm_amd64.deb
wget https://github.com/jgm/pandoc/releases/download/3.1.4/pandoc-3.1.4-1-amd64.deb
sudo dpkg -i pandoc-3.1.4-1-amd64.deb
wget http://ftp.de.debian.org/debian/pool/main/g/ghostwriter/ghostwriter_23.04.2+ds-1_amd64.deb
sudo dpkg -i ghostwriter_23.04.2+ds-1_amd64.deb
wget https://ftp.gwdg.de/pub/opensuse/repositories/home%3A/cboxdoerfer/Debian_12/amd64/fsearch_0.2.2-1%2B3.2_amd64.deb
sudo dpkg -i fsearch_0.2.2-1%2B3.2_amd64.deb
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
if [ ! -d "$HOME/.config/Thunar" ]; then
	mkdir -p ~/.config/Thunar
fi
cp uca.xml ~/.config/Thunar
cp custom-actions/custom-reference.odt ~/.local/share/pandoc
cp custom-actions/pagebreak.lua ~/.local/share/pandoc/filters
cp custom-actions/*.sh custom-actions/*.css ~/.local/bin
exit 0
