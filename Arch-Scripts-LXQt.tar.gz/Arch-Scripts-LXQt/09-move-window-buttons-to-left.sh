#!/bin/bash
echo "gtk-decoration-layout=close,minimize,maximize:menu" >> /home/kay/.config/gtk-3.0/settings.ini
exit 0

