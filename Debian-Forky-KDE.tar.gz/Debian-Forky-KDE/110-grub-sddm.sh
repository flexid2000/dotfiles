#!/bin/bash

set -e  # Skript bei Fehler beenden

echo "📦 Installiere benötigte Pakete ..."
sudo apt-get update
sudo apt-get install -y \
    git sddm-theme-breeze desktop-base libqt6svg6 imagemagick \
    papirus-icon-theme arc-kde qt6-style-kvantum qml-module-qtquick-layouts \
    qml-module-qtquick-controls2 qml-module-qtquick-window2

echo "GRUB-Background erstellen"
sudo mkdir -p /usr/share/images/grub /usr/share/images/background
sudo magick -size 1x1 xc:black /usr/share/images/grub/grub-background.tga
sudo magick -size 1920x1080 xc:"#404552" /usr/share/images/background/1920x1080-black.png

echo "⚙️ Konfiguriere GRUB ..."
sudo sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT="3"/' /etc/default/grub
sudo sed -i 's/^GRUB_TIMEOUT_STYLE=.*/GRUB_TIMEOUT_STYLE="menu"/' /etc/default/grub
sudo sed -i '/^#GRUB_GFXMODE/c\
GRUB_GFXMODE="1024x768x32"\
GRUB_GFXPAYLOAD_LINUX="keep"\
GRUB_BACKGROUND="/usr/share/images/grub/grub-background.tga"\
GRUB_THEME="/usr/share/grub/themes/breeze/theme.txt"' /etc/default/grub
sudo update-grub

echo "🕐 Setze DefaultTimeoutStopSec auf 20s ..."
sudo sed -i 's/^#DefaultTimeoutStopSec=.*$/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf

echo "📁 Erstelle Artwork-Verzeichnis, falls nötig ..."
mkdir -p "$HOME/Bilder/artwork"
cp artwork/bby-wallpaper-shortcuts.png "$HOME/Bilder/artwork/"

echo "Konfiguriere SDDM"
sudo cp confiles/kde_settings.conf /etc/sddm.conf.d/

echo "📄 Schreibe theme.conf.user für breeze"
sudo tee /usr/share/sddm/themes/breeze/theme.conf.user > /dev/null <<EOF
[General]
showClock=true
type=color
color=#1e1e2e
EOF

echo "✅ Alles erledigt."
exit 0


