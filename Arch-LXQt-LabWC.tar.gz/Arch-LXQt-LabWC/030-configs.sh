#!/bin/bash

set -e

# Ordner anlegen
if [ ! -d $HOME/.config ]; then
  mkdir -p ~/.config
fi
if [ ! -d $HOME/.local/share ]; then
  mkdir -p ~/.local/share
fi
if [ ! -d $HOME/Bilder/artwork ]; then
  mkdir -p ~/Bilder/artwork
fi

# Konfigurationsdateien kopieren
cp -R config/conky config/foot config/kanshi config/labwc config/lxqt config/mako config/meteo-qt config/rofi config/themes config/waybar $HOME/.config/
cp -R local_share/themes $HOME/.local/share

# Hintergrundsbild
cp artwork/hashtags.png $HOME/Bilder/artwork

# GTK-Settings
gsettings set org.gnome.desktop.interface gtk-theme Adwaita-dark
gsettings set org.gnome.desktop.interface color-scheme prefer-dark
gsettings set org.gnome.desktop.wm.preferences button-layout "close,minimize,maximize:"

# Login-Manager
sudo useradd -r -M -G seat -s /bin/nologin greetd
sudo usermod -aG seat $USER
sudo usermod -aG video $USER
sudo systemctl enable seatd
sudo cp config/config.toml /etc/greetd/

exit 0
