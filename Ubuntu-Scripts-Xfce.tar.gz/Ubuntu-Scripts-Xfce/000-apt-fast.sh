#!/bin/bash
sudo apt update
sudo apt -y full-upgrade
sudo apt -y install curl
sudo /bin/bash -c "$(curl -sL https://git.io/vokNn)"
sudo apt-fast update
sudo apt-fast -y full-upgrade
sudo apt -y purge snapd
sudo apt-fast -y install vim git arc-theme papirus-icon-theme qt5-style-kvantum qt5ct
#sudo apt-fast -y install virtualbox-guest-utils
#sudo usermod -aG vboxsf kay
exit 0
