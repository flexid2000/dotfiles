#!/bin/bash
for FILE in "$@"; do
	md-to-pdf --css "body { font-size: 1.3em; }" "${FILE}"
done
exit 0

