#!/bin/bash
wget https://deac-ams.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky* ~/.config/conky
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
if [ ! -d "$HOME/.config/foot" ]; then
  mkdir -p ~/.config/foot
fi
if [ ! -d "$HOME/.config/gtk-3.0" ]; then
  mkdir -p ~/.config/gtk-3.0
fi
if [ ! -d "$HOME/.config/labwc" ]; then
  mkdir -p ~/.config/labwc
fi
if [ ! -d "$HOME/.config/lxqt" ]; then
  mkdir -p ~/.config/lxqt
fi
if [ ! -d "$HOME/.config/rofi" ]; then
  mkdir -p ~/.config/rofi
fi
if [ ! -d "$HOME/.local/share/themes" ]; then
  mkdir -p ~/.local/share/themes
fi
sudo cp pdf.thumbnailer /usr/share/thumbnailers
cp slugify.sh ~/.local/bin
cp yt-dlp/config ~/.config/yt-dlp
cp ghostwriter.conf ~/.config/kde.org
cp .bash_aliases ~/
source ~/.bashrc
sudo apt-get -y install fonts-croscore
sudo fc-cache -frv
cp foot/foot.ini ~/.config/foot/
cp gtk-3.0/settings.ini ~/.config/gtk-3.0/
cp labwc/* ~/.config/labwc/
cp lxqt/* ~/.config/lxqt/
cp rofi/* ~/.config/rofi/
cp -r catppuccin-macchiato ~/.local/share/themes/
exit 0
