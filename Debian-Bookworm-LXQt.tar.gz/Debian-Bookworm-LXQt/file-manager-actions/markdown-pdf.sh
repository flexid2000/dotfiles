#!/bin/bash
for FILE in "$@"; do
	OPENSSL_CONF=/etc/ssl markdown-pdf -s ~/.local/bin/style.css --phantom-path /usr/lib/node_modules/phantomjs-prebuilt/lib/phantom/bin/phantomjs "${FILE}"
done
exit 0
