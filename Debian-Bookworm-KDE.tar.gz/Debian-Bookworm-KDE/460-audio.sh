#!/bin/bash
sudo apt-get install pipewire-audio gstreamer1.0-pipewire pipewire-alsa pipewire-audio pipewire-bin pipewire-pulse pipewire-v4l2 qml-module-org-kde-pipewire vlc-plugin-pipewire
systemctl --user --now enable wireplumber.service
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
sudo apt-get -y -t bookworm-backports install yt-dlp
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
