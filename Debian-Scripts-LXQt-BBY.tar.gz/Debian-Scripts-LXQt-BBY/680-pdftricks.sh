#!/bin/bash
sudo apt -y install libgtk-3-dev libgranite-dev meson valac ghostscript
git clone https://github.com/muriloventuroso/pdftricks.git
cd pdftricks
meson build --prefix=/usr
cd build
ninja test
sudo ninja install
cd ../..
rm -R pdftricks
if [ ! -d $HOME/.local/share/applications ]; then
	mkdir -p ~/.local/share/applications
fi
cp confiles/pdftricks.desktop ~/.local/share/applications
exit 0
