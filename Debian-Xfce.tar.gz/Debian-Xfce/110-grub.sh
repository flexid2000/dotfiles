#!/bin/bash

set -e  # Skript bei Fehler beenden

echo "📦 Installiere benötigte Pakete ..."
sudo apt-get update
sudo apt-get install -y \
    git desktop-base librsvg2-bin imagemagick \
    papirus-icon-theme arc-kde qt6-style-kvantum \
    arc-theme

echo "⚙️ Konfiguriere GRUB ..."
sudo sed -i 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT="3"/' /etc/default/grub
sudo sed -i 's/^GRUB_TIMEOUT_STYLE=.*/GRUB_TIMEOUT_STYLE="menu"/' /etc/default/grub
sudo sed -i '/^#GRUB_GFXMODE/c\
GRUB_GFXMODE="1024x768x32"\
GRUB_GFXPAYLOAD_LINUX="keep"\
GRUB_BACKGROUND="/usr/share/desktop-base/joy-theme/grub/grub-16x9.png"' /etc/default/grub
sudo update-grub

echo "🕐 Setze DefaultTimeoutStopSec auf 20s ..."
sudo sed -i 's/^#DefaultTimeoutStopSec=.*$/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf

echo "📁 Erstelle Artwork-Verzeichnis, falls nötig ..."
mkdir -p "$HOME/Bilder/artwork"
cp artwork/bby-wallpaper-shortcuts.png "$HOME/Bilder/artwork/"

echo "Konfiguriere LightDM"
sudo sed -i 's/#greeter-hide-users=false/greeter-hide-users=false/' /etc/lightdm/lightdm.conf
sudo sed -i 's/#allow-user-switching=true/allow-user-switching=true/' /etc/lightdm/lightdm.conf
sudo cp artwork/grub-4x3.png artwork/grub-16x9.png /usr/share/desktop-base/active-theme/grub

echo "✅ Alles erledigt."
exit 0


