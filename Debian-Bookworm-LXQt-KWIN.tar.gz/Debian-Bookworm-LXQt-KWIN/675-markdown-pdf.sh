#!/bin/bash
if ! command -v curl &> /dev/null
then sudo apt-fast -y install curl
fi
curl -sL https://deb.nodesource.com/setup_19.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo npm install -g phantomjs-prebuilt
sudo npm install -g markdown-pdf --ignore-scripts
