#!/bin/bash
# kernel-cleaner.sh – Interaktiver Kernel-Remover für Debian
# Entfernt Kernel-Images UND die zugehörigen Header
# Garantiert, dass mindestens 2 Kernel übrig bleiben
# Prüft zusätzlich die Auslastung der EFI-Systempartition (/boot/efi)
# Zeigt bei Platzmangel die größten Kernel-Dateien samt Paketnamen an
# Benötigt: whiptail (oder dialog)

# === Funktion: ESP-Auslastung prüfen ===
check_esp() {
    if mount | grep -q "on /boot/efi "; then
        usage=$(df -h /boot/efi | awk 'NR==2 {print $5}' | tr -d '%')
        echo "EFI-Systempartition (/boot/efi) Auslastung: $usage%"
        if [ "$usage" -ge 80 ]; then
            echo "⚠️  Warnung: /boot/efi ist zu ${usage}% voll!"
            echo "Es könnte zu Problemen bei zukünftigen Kernel-Installationen kommen."
            echo "👉 Größte Kernel-Dateien in /boot/efi (mit Paketbezug):"
            # Top 10 Dateien anzeigen und Versionsinfo extrahieren
            while read -r size path; do
                file=$(basename "$path")
                if [[ "$file" =~ ([0-9]+\.[0-9]+\.[0-9]+.*)-amd64 ]]; then
                    ver="${BASH_REMATCH[1]}-amd64"
                    pkg="linux-image-$ver"
                else
                    pkg="(kein Kernel-Paket erkannt)"
                fi
                printf "%-8s %-50s -> %s\n" "$size" "$file" "$pkg"
            done < <(sudo du -ah /boot/efi | grep -E 'initrd\.img|vmlinuz' | sort -hr | head -n 10)
            echo "Wähle im Menü den passenden Paketnamen ($pkg), um den Kernel sauber zu entfernen."
        fi
    else
        echo "ℹ️  /boot/efi ist nicht eingehängt – keine ESP-Prüfung möglich."
    fi
}

# === Start ===
check_esp

# Prüfen, ob whiptail vorhanden ist
if ! command -v whiptail >/dev/null; then
    echo "Bitte installiere zuerst 'whiptail' (sudo apt install whiptail)."
    exit 1
fi

# Liste aller installierten Kernel-Images holen
kernels=($(dpkg --list | awk '/linux-image-[0-9]/{print $2}' | sort -V))
if [ ${#kernels[@]} -lt 2 ]; then
    echo "Es sind weniger als zwei Kernel installiert – kein Entfernen möglich."
    exit 0
fi

# Aktuell laufenden Kernel feststellen
current=$(uname -r)

# Whiptail-Auswahlliste vorbereiten
options=()
for k in "${kernels[@]}"; do
    if [[ "$k" == *"$current"* ]]; then
        options+=("$k" "(läuft aktuell)" "OFF")
    else
        options+=("$k" "" "OFF")
    fi
done

# Auswahlmenü
selected=$(whiptail --title "Kernel-Remover" \
    --checklist "Wähle die zu entfernenden Kernel aus (Leertaste = markieren):" \
    20 80 10 \
    "${options[@]}" 3>&1 1>&2 2>&3)

# Wenn Abbruch oder nichts ausgewählt
if [ -z "$selected" ]; then
    echo "Abgebrochen – keine Kernel entfernt."
    exit 0
fi

# Aktuellen Kernel immer schützen
if [[ "$selected" == *"$current"* ]]; then
    echo "⚠️  Der aktuell laufende Kernel ($current) darf nicht entfernt werden."
    echo "Dieser wird automatisch geschützt."
    selected=$(echo "$selected" | sed "s/linux-image-$current//")
fi

# Sicherstellen, dass mindestens 2 Kernel bleiben
count_total=${#kernels[@]}
count_selected=$(echo "$selected" | wc -w)
count_remaining=$((count_total - count_selected))

if [ "$count_remaining" -lt 2 ]; then
    echo "⚠️  Du hast zu viele Kernel ausgewählt."
    echo "Es müssen mindestens 2 Kernel installiert bleiben (der aktuelle + ein Fallback)."
    echo "Abbruch."
    exit 1
fi

# Passende Header-Pakete zu den gewählten Images finden
to_remove=""
for k in $selected; do
    [ -z "$k" ] && continue
    to_remove+=" $k"
    ver="${k#linux-image-}"
    headers=$(dpkg --list | awk '/linux-headers-[0-9]/{print $2}' | grep "$ver")
    if [ -n "$headers" ]; then
        to_remove+=" $headers"
    fi
done

if [ -z "$to_remove" ]; then
    echo "Keine gültigen Kernel ausgewählt."
    exit 0
fi

# Bestätigung
echo "Folgende Pakete werden entfernt:"
echo "$to_remove"
read -rp "Fortfahren? (j/N) " confirm
if [[ "$confirm" =~ ^[Jj]$ ]]; then
    sudo apt purge -y $to_remove
    echo "✅ Entfernen abgeschlossen."
    echo "👉 Bitte führe 'sudo update-grub' aus, um den Bootloader zu aktualisieren."
else
    echo "Abgebrochen."
fi
