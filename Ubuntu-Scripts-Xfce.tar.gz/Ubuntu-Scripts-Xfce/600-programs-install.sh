#!/bin/bash
sudo apt-fast update
sudo apt-fast -y install alsa-firmware-loaders apt-transport-https arandr arc-theme arj audacious baobab bleachbit blueman bluetooth bluez-cups bluez-obexd bluez-tools breeze-cursor-theme cabextract calibre catfish clementine fonts-sil-charis conky cups cups-browsed cups-client cups-common cups-core-drivers cups-filters cups-filters-core-drivers cups-ipp-utils cups-pk-helper cups-ppdc cups-server-common curl dconf-editor default-jre default-jre-headless dkms exfalso file-roller evince faad feh ffmpeg ffmpegthumbnailer flac flvstreamer fonts-cantarell fonts-croscore fonts-inconsolata fonts-roboto-unhinted galternatives gcolor3 geany gigolo gimagereader gimp gimp-help-de gimp-plugin-registry git gnome-calculator gnome-packagekit gnome-system-tools gpa gparted grsync gstreamer1.0-gtk3 gvfs-backends gvfs-fuse hardinfo haveged htop hunspell hwinfo imagemagick lame language-selector-gnome libcanberra-pulse libdvd-pkg libgpod-dev libimobiledevice-dev libreoffice libreoffice-l10n-de libslf4j-java lightdm-gtk-greeter-settings menu-xdg mjpegtools mpv mtp-tools murrine-themes nextcloud-desktop ntp numlockx papirus-icon-theme pdfarranger plank playerctl plymouth-themes plymouth-x11 poppler-utils preload pulseaudio-module-bluetooth python3-pyinotify qt5-style-kvantum qt5-style-kvantum-l10n qt5-style-kvantum-themes qt5-style-plugins qt5ct redshift-gtk rar rfkill scrot seahorse shotwell simple-scan smplayer software-properties-gtk soundconverter subversion tesseract-ocr tesseract-ocr-deu tesseract-ocr-eng thunderbird thunderbird-locale-de transmission-gtk ttf-bitstream-vera ttf-mscorefonts-installer tumbler-plugins-extra unace unclutter unrar vlc vnstat vorbis-tools wavpack wmctrl wv wx-common xbindkeys xclip xdg-user-dirs-gtk xdg-utils xdotool xfce4-goodies xsettingsd xpad zip
sudo apt-fast -y purge atril quodlibet
sudo apt-fast -y autoremove --purge
sudo dpkg-reconfigure libdvd-pkg
sudo systemctl enable bluetooth.service
sudo systemctl start bluetooth.service
sudo sed -i 's/'#AutoEnable=false'/'AutoEnable=true'/g' /etc/bluetooth/main.conf
wget https://netcologne.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
exit 0
