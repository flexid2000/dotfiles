#/bin/bash
sudo apt install gettext-base dctrl-tools menu ssft zenity zenity-common
wget https://packages.siduction.org/extra/pool/main/k/kernel-remover/kernel-remover_3.1.17_all.deb
wget https://packages.siduction.org/extra/pool/main/c/creativecommons3/creativecommons3_1.1_all.deb
sudo dpkg -i creativecommons3* kernel-remover*
sudo rm creativecommons3* kernel-remover*
echo "Anwendung: sudo -H kernel-remover"
exit 0

