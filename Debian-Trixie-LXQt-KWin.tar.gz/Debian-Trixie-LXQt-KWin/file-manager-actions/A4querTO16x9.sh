#!/bin/bash
for FILE in "$@"; do
	pdftocairo -jpeg "${FILE}"
	img2pdf -o "${FILE%.*}"-16×9.pdf -S 280mmx157.5mm "${FILE%.*}"-*.jpg
	rm "${FILE%.*}"-*.jpg
done
exit 0
