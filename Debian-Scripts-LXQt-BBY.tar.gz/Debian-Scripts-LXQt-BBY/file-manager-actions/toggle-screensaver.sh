#!/bin/bash
xset s 600 600
if xset q | grep "Enabled"; then
	xset s off -dpms && sh -c "notify-send -u critical -t 3000 -i preferences-desktop-screensaver -- 'Screensaver OFF'"
else
	xset s on +dpms && sh -c "notify-send -u critical -t 3000 -i preferences-desktop-screensaver -- 'Screensaver ON'"
fi


