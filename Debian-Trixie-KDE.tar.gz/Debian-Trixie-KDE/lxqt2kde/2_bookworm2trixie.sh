#!/bin/bash

# Farben
RED="\033[1;31m"; GREEN="\033[1;32m"; YELLOW="\033[1;33m"; RESET="\033[0m"

# Bestätigungsfunktion
confirm() {
  echo -en "${YELLOW}$1 [j/N]: ${RESET}"
  read -r reply
  [[ "$reply" =~ ^[JjYy]$ ]]
}

set -euo pipefail

echo -e "${GREEN}8. Aufräumen nach dem Upgrade${RESET}"
sudo apt-get autoremove --purge

echo -e "${GREEN}Entferne obsolete Pakete mit aptitude.${RESET}"
sudo aptitude update
sudo aptitude purge '~o'

echo -e "${GREEN}Entferne übriggebliebene Konfigurationsdateien mit aptitude.${RESET}"
sudo aptitude purge '~c'

# tasksel-Check und KDE-Installation
if ! command -v tasksel &> /dev/null; then
  echo -e "${YELLOW}tasksel wird installiert...${RESET}"
  sudo apt-get install -y tasksel
fi

echo -e "${GREEN}KDE Plasma installieren.${RESET}"
sudo tasksel install kde-desktop

echo -e "${GREEN}Überflüssige Programme entfernen${RESET}"
sudo apt-get --auto-remove purge qpdfview* feathernotes* featherpad* qlipper* xarchiver* lximage-qt* screengrab* quassel* qps* qterminal* akonadi-server akregator dragonplayer hugin juk k3b kaccounts-integration kaccounts-providers kaddressbook kamoso kdeconnect kget kgpg kmag kmahjongg kmail kmines kmousetool kmouth konqueror kontrast korganizer kpat krdc ksystemlog ktouch kturtle kwordquiz pim-data-exporter pim-sieve-editor

echo -e "${GREEN}Upgrade abgeschlossen. Starte das System neu.${RESET}"
if confirm "Jetzt neu starten?"; then
  sudo reboot
fi
