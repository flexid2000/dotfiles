#!/bin/bash
cd binaries
chmod 755 *
sudo apt-get -y install xdotool redshift obconf-qt git xpad xclip picom caffeine libobrender32v5 libobrender32v5 gvfs-fuse libsecret-tools dbus-x11 gnome-keyring git
sudo dpkg -i openbox*
sudo apt-get -y -f install
sudo apt -y install obconf-qt
sudo cp redshift-qt winfuncs /usr/local/bin
if [ ! -d "${homedir}/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
cp ../bash-scripts/copy2clipboard.sh ~/.local/bin
exit 0
