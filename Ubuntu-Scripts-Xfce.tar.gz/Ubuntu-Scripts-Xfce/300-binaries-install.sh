#!/bin/bash
sudo apt-get -y install xdotool redshift redshift-gtk dkms accountsservice haveged git xpad xclip nextcloud-desktop
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
cp bash-scripts/* ~/.local/bin
exit 0
