#!/bin/bash
paru -S perl-rename poppler graphicsmagick-imagemagick-compat pandoc-bin xclip mupdf-tools unoconv libnotify --needed
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc" ]; then
	mkdir -p ~/.local/share/pandoc
fi
cp confiles/custom-reference.odt ~/.local/share/pandoc
cp file-manager-actions/*.sh file-manager-actions/*.py ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
exit 0
