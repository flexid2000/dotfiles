#!/bin/bash
wget https://deac-ams.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
if [ ! -d "$HOME/.config/gtk-3.0" ]; then
  mkdir -p ~/.config/gtk-3.0
fi
if [ ! -d "$HOME/.config/gtk-4.0" ]; then
  mkdir -p ~/.config/gtk-4.0
fi
if [ ! -d "$HOME/.config/lxqt" ]; then
  mkdir -p ~/.config/lxqt
fi
if [ ! -d "$HOME/.config/openbox" ]; then
  mkdir -p ~/.config/openbox
fi
if [ ! -d "$HOME/.config/picom" ]; then
  mkdir -p ~/.config/picom
fi
if [ ! -d "$HOME/.local/share/themes" ]; then
  mkdir -p ~/.local/share/themes
fi
if [ ! -d "$HOME/.config/kde.org" ]; then
  mkdir -p ~/.config/kde.org
fi
if [ ! -d "$HOME/.config/feathernotes" ]; then
  mkdir -p ~/.config/feathernotes
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
  mkdir -p ~/.local/share/pandoc/filters
fi
sudo apt-get -y install graphicsmagick
sudo cp graphicmagick-pdf.thumbnailer /usr/share/thumbnailers
cp yt-dlp/config ~/.config/yt-dlp
cp ghostwriter.conf ~/.config/kde.org
cp .bash_aliases ~/
source ~/.bashrc
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo apt-get -y install fonts-croscore
sudo fc-cache -frv
cp gtk-3.0/settings.ini ~/.config/gtk-3.0/
cp lxqt/globalkeyshortcuts.conf ~/.config/lxqt/
cp conky/conky.conf ~/.config/conky/
cp -r catppuccin-macchiato ~/.local/share/themes
cp -r openbox/rc.xml ~/.config/openbox
cp picom/picom.conf ~/.config/picom
cp feathernotes/* ~/.config/feathernotes
cp pagebreak.lua ~/.local/share/pandoc/filters
git clone https://github.com/davidphilipbarr/labwc-adwaita.git
cp -r labwc-adwaita/themes/* ~/.local/share/themes
sudo rm -r labwc-adwaita
ln -s $HOME/.config/gtk-3.0/settings.ini $HOME/.config/gtk-4.0
exit 0
