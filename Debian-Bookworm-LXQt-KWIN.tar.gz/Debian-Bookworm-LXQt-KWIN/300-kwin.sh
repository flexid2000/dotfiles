#!/bin/bash
sudo nala install plasma-workspace systemsettings plasma-desktop kwin-x11
cd binaries
chmod 755 *
sudo nala install xdotool redshift git xclip gvfs-fuse dbus-x11 git
exit 0
