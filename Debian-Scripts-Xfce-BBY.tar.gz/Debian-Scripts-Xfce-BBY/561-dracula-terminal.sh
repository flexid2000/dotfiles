#!/bin/bash
git clone https://github.com/dracula/xfce4-terminal.git
mkdir -p ~/.local/share/xfce4/terminal/colorschemes
mv xfce4-terminal/Dracula.theme ~/.local/share/xfce4/terminal/colorschemes/
git clone https://github.com/dracula/libreoffice.git
mkdir -p ~/.config/libreoffice/4/user/config/
cp libreoffice/dracula.soc ~/.config/libreoffice/4/user/config/
exit 0
