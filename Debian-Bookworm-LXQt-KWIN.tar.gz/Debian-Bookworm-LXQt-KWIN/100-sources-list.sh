#!/bin/bash
#
# sources.list in Debian bullseye anpassen
#
sudo apt-fast -y install curl
echo "deb http://mirror.ipb.de/debian/ bookworm main contrib non-free non-free-firmware" > /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ bookworm-updates main contrib non-free non-free-firmware" >> /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ bookworm-backports main contrib non-free non-free-firmware" >> /tmp/sources.list
echo "deb http://deb.debian.org/debian-security bookworm-security main" >> /tmp/sources.list
sudo cp /tmp/sources.list /etc/apt
sudo apt-fast update
exit 0
