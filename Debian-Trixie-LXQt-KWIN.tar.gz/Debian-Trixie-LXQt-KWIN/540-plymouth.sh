#!/bin/bash
sudo apt-get -y install plymouth plymouth-themes plymouth-x11
#sudo sed -i 's/BackgroundStartColor=0x000000/BackgroundStartColor=0x282a36/' /usr/share/plymouth/themes/spinner/spinner.plymouth
#sudo sed -i 's/BackgroundEndColor=0x000000/BackgroundEndColor=0x282a36/' /usr/share/plymouth/themes/spinner/spinner.plymouth
sudo sed -i 's/"quiet"/"quiet splash"/g' /etc/default/grub
sudo plymouth-set-default-theme -R spinner
exit 0
