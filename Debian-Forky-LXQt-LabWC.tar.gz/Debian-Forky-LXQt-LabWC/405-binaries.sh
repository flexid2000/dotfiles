#!/bin/bash

sudo dpkg -i binaries/labconf_1.0.0-2_amd64.deb binaries/labhotkey_01.2-28_amd64.deb binaries/labwc-tweaks_01.0.r28.forky-1_amd64.deb binaries/nwg-look_1.1.1-1_amd64.deb
