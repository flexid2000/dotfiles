#!/bin/bash
sudo apt-fast -y install rename poppler-utils graphicsmagick-imagemagick-compat pandoc xclip poppler-utils mupdf-tools unoconv libnotify-bin img2pdf librsvg2-bin libc6 libgcc-s1 libqt5core5a libqt5gui5 libqt5network5 libqt5printsupport5 libqt5svg5 libqt5webkit5 libqt5widgets5 libstdc++6 xdotool redshift redshift-gtk dkms accountsservice haveged git xpad xclip
wget https://github.com/wkhtmltopdf/packaging/releases/download/0.12.6.1-3/wkhtmltox_0.12.6.1-3.bookworm_amd64.deb
sudo dpkg -i wkhtmltox_0.12.6.1-3.bookworm_amd64.deb
wget https://github.com/jgm/pandoc/releases/download/3.1.4/pandoc-3.1.4-1-amd64.deb
sudo dpkg -i pandoc-3.1.4-1-amd64.deb
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
if [ ! -d "$HOME/.config/Thunar" ]; then
	mkdir -p ~/.config/Thunar
fi
cp custom-actions/uca.xml ~/.config/Thunar
cp custom-actions/custom-reference.odt ~/.local/share/pandoc
cp custom-actions/pagebreak.lua ~/.local/share/pandoc/filters
cp custom-actions/*.sh custom-actions/*.css ~/.local/bin
exit 0
