#!/bin/bash
sudo apt update && sudo apt -y full-upgrade
#sh 100-sources-list.sh
sh 110-grub-autologin.sh
sh 120-autostart.sh
sh 200-nextcloud.sh
sh 300-binaries-install.sh
sh 400-confiles.sh
sh 460-deemix.sh
sh 500-programs-install.sh
sh 510-yt-dlp.sh
sh 520-recoll.sh
sh 540-plymouth.sh
#sh 550-swapfile.sh
sh 561-dracula-terminal.sh
sh 570-brave-browser.sh
sh 580-img2pdf.sh
sh 590-typora.sh
sh 610-xfce-wallpapers.sh
sh 620-go-appimage.sh
sh 630-courier-prime-fonts.sh
exit 0
