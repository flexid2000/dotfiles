#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
paru -S simplicity-sddm-theme-git
sudo sed -i 's/^Session=.*/Session=lxqt.desktop/' /etc/sddm.conf
sudo sed -i "s/^User=.*/User=$USER/" /etc/sddm.conf
sudo sed -i 's/^Current=.*/Current=simplicity/' /etc/sddm.conf
sudo sed -i 's/^CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo cp artwork/grub-16x9.png /usr/share/sddm/themes/simplicity/images/background.png
echo "[General]" > /tmp/theme.conf.user
echo "background=/usr/share/sddm/themes/simplicity/images/background.png" >> /tmp/theme.conf.user
sudo cp /tmp/theme.conf.user /usr/share/sddm/themes/simplicity/
sudo sed -i 's/^timeout.*/timeout=0/' /boot/efi/loader/loader.conf
exit 0
