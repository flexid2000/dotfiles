#!/bin/bash
cp /etc/fstab /tmp
echo "/sharepoint	/home/kay/shared	9p	trans=virtio,version=9p2000.L,rw	0	0" >> /tmp/fstab
sudo cp /tmp/fstab /etc/fstab
exit 0
