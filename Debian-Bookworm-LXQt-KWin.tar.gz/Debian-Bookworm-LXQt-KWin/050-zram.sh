#!/bin/bash
sudo apt-get install vim ranger apt-file git curl wget systemd-zram-generator pipewire-audio isenkram-cli
sudo apt -y purge pulseaudio-module-bluetooth pulseaudio ofono
systemctl --user --now enable wireplumber.service
sudo isenkram-autoinstall-firmware
exit 0
