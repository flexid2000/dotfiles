#!/bin/bash
sudo apt -y install gvfs-fuse gnome-keyring nextcloud-desktop
sudo modprobe fuse
sudo groupadd fuse
sudo usermod -aG fuse $(whoami)
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
exit 0
