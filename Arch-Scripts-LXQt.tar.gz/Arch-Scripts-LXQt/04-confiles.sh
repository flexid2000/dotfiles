#!/bin/bash
if [ ! -d $HOME/.config/conky ]; then
  mkdir -p ~/.config/conky
fi
cp confiles/conky.conf ~/.config/conky
cp confiles/redshift.conf ~/.config
if [ ! -d $HOME/.config/yt-dlp ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if [ ! -d $HOME/.config/meteo-qt ]; then
  mkdir -p ~/.config/meteo-qt
fi
cp confiles/meteo-qt.conf ~/.config/meteo-qt/
if [ ! -d $HOME/.config/mpv ]; then
  mkdir -p ~/.config/mpv
fi
cp confiles/mpv.conf ~/.config/mpv
cp confiles/globalkeyshortcuts.conf ~/.config/lxqt
paru -S ksuperkey lxqt-arc-dark-theme-git kvantum-theme-arc
mkdir -p ~/Bilder/artwork
cp artwork/clipboard-dark.png ~/Bilder/artwork/
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
exit 0
