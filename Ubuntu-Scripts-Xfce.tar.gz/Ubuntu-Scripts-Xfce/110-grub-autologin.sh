#!/bin/bash
# Set Default Stop Time to 20 sec
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
cp /usr/share/lightdm/lightdm.conf.d/60-lightdm-gtk-greeter.conf /tmp
echo "autologin-user=$USER" >> /tmp/60-lightdm-gtk-greeter.conf
echo "autologin-user-timeout=0" >> /tmp/60-lightdm-gtk-greeter.conf
sudo cp /tmp/60-lightdm-gtk-greeter.conf /usr/share/lightdm/lightdm.conf.d/
exit 0

