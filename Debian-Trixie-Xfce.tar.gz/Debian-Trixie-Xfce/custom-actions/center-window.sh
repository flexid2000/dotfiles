#!/bin/sh

WIN=$(xdotool getactivewindow)

read SW SH <<EOF
$(xdotool getdisplaygeometry)
EOF

W=800
H=600

X=$(( (SW - W) / 2 ))
Y=$(( (SH - H) / 2 ))

xdotool windowsize "$WIN" "$W" "$H"
xdotool windowmove "$WIN" "$X" "$Y"

