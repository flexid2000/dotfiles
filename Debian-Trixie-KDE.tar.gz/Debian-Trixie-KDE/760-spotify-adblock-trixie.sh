#!/bin/bash
sudo apt-get update
sudo apt-get -y install curl build-essential make
curl -sS https://download.spotify.com/debian/pubkey_C85668DF69375001.gpg | sudo gpg --dearmor --yes -o /etc/apt/trusted.gpg.d/spotify.gpg
echo "deb https://repository.spotify.com stable non-free" | sudo tee /etc/apt/sources.list.d/spotify.list
sudo apt-get update
sudo apt-get -y install spotify-client rustc cargo
git clone https://github.com/abba23/spotify-adblock.git
cd spotify-adblock
make
sudo make install
rm -rf spotify-adblock
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
cp /usr/share/applications/spotify.desktop $HOME/.local/share/applications/
sed -i 's/^Exec=spotify/Exec=LD_PRELOAD=\/usr\/local\/lib\/spotify-adblock.so spotify/g;s/Name=Spotify/Name=Spotify Adblock/g' $HOME/.local/share/applications/spotify.desktop
exit 0

