#!/bin/bash
sudo apt-get -y install sddm-theme-breeze desktop-base
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze/' /etc/sddm.conf
sudo cp /usr/share/plymouth/themes/joy/background.png /usr/share/sddm/themes/breeze
sudo printf '[General]\nbackground=background.png\ntype=image\n' > theme.conf.user
sudo mv theme.conf.user /usr/share/sddm/themes/breeze
exit 0
