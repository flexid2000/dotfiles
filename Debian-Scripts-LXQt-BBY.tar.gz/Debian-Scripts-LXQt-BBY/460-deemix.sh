#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p $HOME/.local/bin
fi
wget https://www.dropbox.com/s/odn4tnu9cqlmq8h/deemix-linux-x64.AppImage?dl=0
mv deemix-linux-x64.AppImage?dl=0 ~/.local/bin/deemix.AppImage
chmod 755 ~/.local/bin/deemix.AppImage
if [ ! $HOME/.local/bin/appimaged-*-x86_64.AppImage ] ; then
	wget -c https://github.com/$(wget -q https://github.com/probonopd/go-appimage/releases -O - | grep "appimaged-.*-x86_64.AppImage" | head -n 1 | cut -d '"' -f 2) -P ~/.local/bin/
	chmod 755 ~/.local/bin/appimaged-*-x86_64.AppImage
	~/.local/bin/appimaged-*-x86_64.AppImage
fi
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf	
exit 0

