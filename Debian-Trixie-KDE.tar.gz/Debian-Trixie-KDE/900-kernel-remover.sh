#!/bin/bash
set -e

echo "🧼 Installiere Kernel Remover ..."
sudo apt-get install -y gettext-base dctrl-tools menu ssft

wget https://packages.siduction.org/extra/pool/main/k/kernel-remover/kernel-remover_3.1.17_all.deb
wget https://packages.siduction.org/extra/pool/main/c/creativecommons3/creativecommons3_1.1_all.deb

sudo dpkg -i creativecommons3_*.deb kernel-remover_*.deb
rm creativecommons3_*.deb kernel-remover_*.deb

echo "Anwendung: sudo -H kernel-remover"
echo "✅ Kernel-Entferner installiert."

