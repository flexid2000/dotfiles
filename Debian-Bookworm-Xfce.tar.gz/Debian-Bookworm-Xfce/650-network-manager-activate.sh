#!/bin/bash
sudo sed -i 's/managed=true/managed=false/g' /etc/NetworkManager/NetworkManager.conf
sudo sed "s/iface $(grep allow-hotplug /etc/network/interfaces | awk '{ print $2 }')/#iface/g" /etc/network/interfaces
exit 0
