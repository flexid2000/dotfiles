#!/bin/bash
git clone https://gitlab.com/isseigx/lxqt-arc-dark-theme.git
if [ ! -d /usr/share/lxqt/themes/arc-dark ]; then
		sudo mkdir -p /usr/share/lxqt/themes/arc-dark
fi
sudo cp -r lxqt-arc-dark-theme/arc-dark/* /usr/share/lxqt/themes/arc-dark/
sudo rm -R lxqt-arc-dark-theme
git clone https://github.com/sparkylinux/sparky5-lxqt-theme.git
if [ ! -d /usr/share/lxqt/themes/sparky5 ]; then
	sudo mkdir -p /usr/share/lxqt/themes/sparky5
fi
sudo cp -r sparky5-lxqt-theme/sparky5/* /usr/share/lxqt/themes/sparky5/
sudo rm -R sparky5-lxqt-theme
wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/arc-kde/master/install.sh | sh
exit 0

