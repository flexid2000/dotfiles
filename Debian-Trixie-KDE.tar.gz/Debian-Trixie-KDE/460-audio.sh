#!/bin/bash
sudo nala install pipewire-audio gstreamer1.0-pipewire pipewire-alsa pipewire-audio pipewire-bin pipewire-pulse pipewire-v4l2 qml-module-org-kde-pipewire vlc-plugin-pipewire yt-dlp
systemctl --user --now enable wireplumber.service
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
wget -O- https://uc6b2fdec7bbcd5e0875876a4499.dl.dropboxusercontent.com/cd/0/get/CTRAWxBF-DLyICwEYAjb4JxCCkQJ_t8a8nTkHqgtMgd1Dbw83AdBKCQDvT2zytdhzWpUhj3WIIwxcpm833j446-lxMioT34dZv7a26RJJmmBaBdrrP-rVvL_6Oq-gqDCSss/file?dl=1 > deemix-linux-x64.deb
sudo dpkg -i deemix-linux-x64.deb
exit 0
