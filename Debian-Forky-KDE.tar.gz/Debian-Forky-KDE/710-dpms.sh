#!/bin/bash
set -e
sudo apt-get install acpid libnotify-bin x11-xserver-utils
sudo systemctl enable acpid.service
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.config/autostart" ]; then
  mkdir ~/.config/autostart
fi
cp autostart/DPMS.desktop ~/.config/autostart
cp file-manager-actions/dpms.sh ~/.local/bin
chmod 755 ~/.local/bin/dpms.sh
exit 0
