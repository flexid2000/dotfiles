#!/bin/bash

set -eu

sudo apt-get -y install weasyprint pandoc img2pdf poppler-utils mupdf-tools rename

if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
cp file-manager-actions/*.sh file-manager-actions/*.css ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
exit 0
