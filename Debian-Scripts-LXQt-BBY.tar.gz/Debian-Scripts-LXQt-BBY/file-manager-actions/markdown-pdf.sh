#!/bin/bash
for f in "$@"; do
	~/.local/node_modules/markdown-pdf/bin/markdown-pdf -s ~/.local/bin/style.css "$f"
done
exit 0
