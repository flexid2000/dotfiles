#!/bin/bash
sudo apt-get -y install libobrender32v5 libobt2v5 picom obconf-qt obconf-qt-l10n
sudo dpkg -i binaries/openbox_3.6.2-1_amd64.deb
if [ ! -d "$HOME/.config/openbox" ]; then
  mkdir -p ~/.config/openbox
fi
if [ ! -d "$HOME/.config/picom" ]; then
  mkdir -p ~/.config/picom
fi
cp confiles/rc.xml $HOME/.config/openbox
cp confiles/picom.conf $HOME/.config/picom
# arc.obt installieren
git clone https://github.com/dglava/arc-openbox.git
obconf-qt --install arc-openbox/arc.obt
obconf-qt --install arc-openbox/arc-darker.obt
sudo rm -R arc-openbox
cp binaries/winfuncs $HOME/.local/bin
exit 0
