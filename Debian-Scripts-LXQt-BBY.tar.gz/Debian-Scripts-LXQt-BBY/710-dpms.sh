#!/bin/bash
sudo apt-fast -y install acpid libnotify-bin xscreensaver caffeine x11-xserver-utils
sudo systemctl enable acpid.service
cp autostart/DPMS.desktop ~/.config/autostart
cp file-manager-actions/dpms.sh ~/.local/bin
chmod 755 ~/.local/bin/actions/dpms.sh
exit 0
