#!/bin/bash

# Skript zur vollständigen Entfernung von LXQt-Konfigurationsdateien
# Muss als normaler Benutzer (nicht root) ausgeführt werden!

# Farben für die Ausgabe
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Sicherheitsabfrage
echo -e "${YELLOW}WARNUNG: Dies wird ALLE LXQt-Konfigurationen löschen!${NC}"
read -p "Fortfahren? (j/N): " answer
if [[ ! "$answer" =~ ^[JjYy].* ]]; then
    echo "Abbruch."
    exit 1
fi

# Überprüfen, ob das Skript als root ausgeführt wird
if [ "$(id -u)" -eq 0 ]; then
    echo -e "${RED}FEHLER: Dieses Skript darf NICHT als root ausgeführt werden!${NC}"
    echo "Bitte als normaler Benutzer starten."
    exit 1
fi

echo -e "${GREEN}=== Beginne LXQt-Konfigurationsbereinigung ===${NC}"

# Liste aller zu löschenden Konfigurationsdateien und -ordner
declare -a lxqt_configs=(
    "$HOME/.config/lxqt"
    "$HOME/.config/pcmanfm-qt"
    "$HOME/.config/qterminal.org"
    "$HOME/.config/lximage-qt"
    "$HOME/.config/openbox"
    "$HOME/.config/obconf"
    "$HOME/.config/lxqt-session"
    "$HOME/.cache/lxqt"
    "$HOME/.cache/pcmanfm-qt"
    "$HOME/.cache/qterminal.org"
    "$HOME/.local/share/lxqt"
    "$HOME/.local/share/pcmanfm-qt"
    "$HOME/.local/share/qterminal.org"
    "$HOME/.local/share/applications/lxqt-*.desktop"
    "$HOME/.local/share/applications/pcmanfm-qt.desktop"
    "$HOME/.local/share/applications/qterminal.desktop"
)

# Bereinigung durchführen
deleted_count=0
preserved_count=0

for config_path in "${lxqt_configs[@]}"; do
    if [ -e "$config_path" ] || [ -f "$config_path" ] || [ -d "$config_path" ]; then
        echo -e "${YELLOW}Lösche: $config_path${NC}"
        rm -rfv "$config_path"
        ((deleted_count++))
    else
        echo -e "Nicht vorhanden: $config_path"
        ((preserved_count++))
    fi
done

# Alte Autostart-Einträge bereinigen
echo -e "${YELLOW}Bereinige Autostart-Einträge...${NC}"
rm -fv "$HOME/.config/autostart/lxqt-*.desktop"
rm -fv "$HOME/.config/autostart/pcmanfm-qt.desktop"

# Ergebnis anzeigen
echo -e "${GREEN}=== Bereinigung abgeschlossen ===${NC}"
echo -e "Gelöschte Konfigurationen: ${deleted_count}"
echo -e "Nicht gefundene Einträge: ${preserved_count}"

# Optional: Desktop-Cache zurücksetzen
echo -e "${YELLOW}Setze Desktop-Cache zurück...${NC}"
xdg-desktop-menu forceupdate
update-desktop-database "$HOME/.local/share/applications"

echo -e "${GREEN}Fertig! Alle LXQt-Konfigurationen wurden entfernt.${NC}"