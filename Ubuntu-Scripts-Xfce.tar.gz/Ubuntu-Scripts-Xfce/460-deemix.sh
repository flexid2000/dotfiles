#!/bin/bash
sudo apt-fast -y install wget
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
wget https://www.dropbox.com/s/odn4tnu9cqlmq8h/deemix-linux-x64.AppImage?dl=0
mv deemix-linux-x64.AppImage?dl=0 ~/.local/bin/deemix.AppImage
chmod 755 ~/.local/bin/deemix.AppImage
sudo ln -s ${HOME}/.local/bin/deemix.AppImage /usr/local/bin/deemix
cp confiles/deemix.desktop ~/.local/share/applications
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
exit 0

