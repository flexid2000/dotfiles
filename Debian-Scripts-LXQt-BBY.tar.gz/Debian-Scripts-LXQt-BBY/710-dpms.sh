#!/bin/bash
cp autostart/DPMS.desktop ~/.config/autostart
cp file-manager-actions/dpms.sh ~/.local/share/file-manager/actions
chmod 755 ~/.local/share/file-manager/actions/dpms.sh
exit 0
