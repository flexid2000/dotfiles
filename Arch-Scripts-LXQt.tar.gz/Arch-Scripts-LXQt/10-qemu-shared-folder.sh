#!/bin/bash
sudo pacman --needed --noconfirm spice-vdagent xf86-video-qxl spice-gtk
if [ ! -d "$HOME/shared" ]; then
  mkdir -p ~/shared
fi
sudo sh -c "printf '/sharepoint\t/home/kay/shared\t9p\ttrans=virtio,version=9p2000.L,rw\t0\t0\n' >> /etc/fstab"
exit 0
