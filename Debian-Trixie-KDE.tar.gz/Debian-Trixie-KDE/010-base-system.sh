#!/bin/bash
set -e

echo "📦 Installiere Basis-Tools ..."
sudo apt-get update
sudo apt-get install -y \
    vim git curl wget apt-file ranger

sudo apt-file update

echo "✅ Basis-System aktualisiert."

