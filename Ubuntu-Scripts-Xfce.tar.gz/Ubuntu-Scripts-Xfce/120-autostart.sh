#!/bin/bash
mkdir -p ~/.config/autostart
mkdir -p ~/.local/bin
mkdir -p ~/.local/share/applications
mkdir -p ~/.config/conky
mkdir -p ~/.config/mpv
mkdir -p ~/.config/youtube-dl
cp autostart/* ~/.config/autostart/
exit 0
