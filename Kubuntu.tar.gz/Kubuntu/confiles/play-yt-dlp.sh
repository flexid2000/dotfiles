#!/bin/bash
LINK=$1
yt-dlp --restrict-filenames -f "best[height<=?720]" $LINK -o - | mpv --title="Stream with yt-dlp" --no-resume-playback -
exit 0

