#!/bin/bash
FOLDER="${1%.*}"
mkdir "$FOLDER"-images
cp $1 "$FOLDER"-images
cd "$FOLDER"-images
mutool extract -r "$1"
rm *.ttf *.cid
rm "$1"
cd ..
exit 0
