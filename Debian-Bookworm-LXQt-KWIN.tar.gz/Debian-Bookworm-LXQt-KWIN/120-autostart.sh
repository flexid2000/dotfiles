#!/bin/bash
if [ ! -d "$HOME/.config/autostart" ]; then
  mkdir ~/.config/autostart
fi
cp autostart/*.desktop ~/.config/autostart
exit 0
