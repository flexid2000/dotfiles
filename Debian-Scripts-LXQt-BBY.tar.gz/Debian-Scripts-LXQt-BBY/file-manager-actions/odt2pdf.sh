#!/bin/bash
for FILE in "$@"; do
	NAME="${FILE%.*}"
	echo $NAME
	unoconv -f pdf -o "${NAME}".pdf "${NAME}".odt
done
exit 0
