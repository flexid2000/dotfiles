#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# md2pdf-weasy.sh
# Konvertiert Markdown-Dateien nach PDF mit Pandoc + WeasyPrint
# Unterstützt \pagebreak durch Platzhalter-Ersatz
# FIX: Base-URL für relative Bildpfade
# -----------------------------------------------------------------------------

set -euo pipefail

# --- Konfiguration -----------------------------------------------------------
WEASYPRINT_BIN="/usr/bin/weasyprint"
CSS_FILE="$HOME/.local/bin/weasyprint.css"

# --- Eingabe prüfen ----------------------------------------------------------
if [[ $# -ne 1 ]]; then
    echo "Verwendung: $(basename "$0") <datei.md>" >&2
    echo "Erstellt: <datei.pdf>" >&2
    exit 1
fi

SRC_MD="$1"
if [[ ! -f "$SRC_MD" ]]; then
    echo "Fehler: Datei nicht gefunden: $SRC_MD" >&2
    exit 1
fi

if [[ ! -x "$WEASYPRINT_BIN" ]]; then
    echo "Fehler: WeasyPrint nicht gefunden oder nicht ausführbar: $WEASYPRINT_BIN" >&2
    exit 1
fi

if [[ ! -f "$CSS_FILE" ]]; then
    echo "Fehler: CSS-Datei nicht gefunden: $CSS_FILE" >&2
    exit 1
fi

# --- Dateinamen vorbereiten --------------------------------------------------
BASENAME="${SRC_MD%.md}"
OUT_PDF="${BASENAME}.pdf"

# WICHTIG: Absoluten Pfad zum Verzeichnis der Markdown-Datei ermitteln
SRC_DIR="$(cd "$(dirname "$SRC_MD")" && pwd)"

# --- Temporäre Dateien erstellen --------------------------------------------
TMP_MD=""
TMP_HTML=""
cleanup() {
    [[ -n "$TMP_MD" && -f "$TMP_MD" ]] && rm -f "$TMP_MD"
    [[ -n "$TMP_HTML" && -f "$TMP_HTML" ]] && rm -f "$TMP_HTML"
}
trap cleanup EXIT

TMP_MD="$(mktemp /tmp/weasy.XXXXXX.md)"
TMP_HTML="$(mktemp /tmp/weasy.XXXXXX.html)"

# --- Schritt 1: Platzhalter einsetzen ---------------------------------------
echo "Verarbeite: $(basename "$SRC_MD")"
sed 's|\\pagebreak|<PAGEBREAK>|g' "$SRC_MD" > "$TMP_MD"

# --- Schritt 2: Markdown → HTML ---------------------------------------------
echo "Konvertiere zu HTML..."
pandoc \
    --from markdown \
    --to html5 \
    --standalone \
    --metadata "title=${BASENAME}" \
    --metadata "lang=de" \
    --css "$CSS_FILE" \
    -V lang=de \
    -V graphics=yes \
    -o "$TMP_HTML" \
    "$TMP_MD" || {
    echo "Fehler bei Pandoc-Konvertierung" >&2
    exit 1
}

# --- Schritt 3: Platzhalter ersetzen durch HTML-Div --------------------------
sed -i 's|<PAGEBREAK>|<div style="page-break-after: always;"></div>|g' "$TMP_HTML"

# --- Schritt 4: PDF erzeugen -------------------------------------------------
echo "Erstelle PDF mit Base-URL: $SRC_DIR"
if ! "$WEASYPRINT_BIN" \
    --base-url "file://$SRC_DIR/" \
    --optimize-images \
    --quiet \
    "$TMP_HTML" \
    "$OUT_PDF"; then
    echo "Fehler bei PDF-Erstellung" >&2
    exit 1
fi

# --- Erfolgsmeldung ----------------------------------------------------------
if [[ -f "$OUT_PDF" ]]; then
    echo "✅ PDF erfolgreich erstellt: $OUT_PDF"
    echo "📄 Größe: $(du -h "$OUT_PDF" | cut -f1)"
else
    echo "❌ Unerwarteter Fehler: PDF wurde nicht erstellt" >&2
    exit 1
fi

