#!/bin/bash
sudo apt-fast -y install rename poppler-utils pandoc xclip poppler-utils mupdf-tools unoconv libnotify-bin img2pdf librsvg2-bin libc6 libgcc-s1 libqt5core5a libqt5gui5 libqt5network5 libqt5printsupport5 libqt5svg5 libqt5webkit5 libqt5widgets5 libstdc++6 xsel wkhtmltopdf
## pandoc
wget https://github.com/jgm/pandoc/releases/download/3.1.12.3/pandoc-3.1.12.3-1-amd64.deb
sudo dpkg -i pandoc-3.1.12.3-1-amd64.deb
## img2pdf from trixie
wget http://ftp.de.debian.org/debian/pool/main/i/img2pdf/img2pdf_0.5.1-1_all.deb
wget ftp.de.debian.org/debian/pool/main/i/img2pdf/python3-img2pdf_0.5.1-1_all.deb
sudo dpkg -i img2pdf_0.5.1-1_all.deb python3-img2pdf_0.5.1-1_all.deb
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
if [ ! -d "$HOME/.local/share/kio/servicemenus" ]; then
	mkdir -p ~/.local/share/kio/servicemenus
fi
cp confiles/custom-reference.odt ~/.local/share/pandoc
cp servicemenus/*.sh servicemenus/*.css ~/.local/bin
cp servicemenus/*.desktop ~/.local/share/kio/servicemenus
chmod 755 ~/.local/share/kio/servicemenus/*.desktop
cp confiles/pagebreak.lua ~/.local/share/pandoc/filters
exit 0
