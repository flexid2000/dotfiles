#!/bin/bash
set -euo pipefail

# ==================== #
# KONFIGURATION        #
# ==================== #

RED='\e[31m'
GREEN='\e[32m'
YELLOW='\e[33m'
NC='\e[0m'
LOG_FILE="/tmp/debian-upgrade-$(date +%Y%m%d).log"

# ==================== #
# FUNKTIONEN           #
# ==================== #

sudo_with_check() {
    # Einmalige sudo-Passwortabfrage mit Session-Erneuerung
    if ! sudo -n true 2>/dev/null; then
        echo -e "${YELLOW}[sudo] Passwort für $(whoami) eingeben:${NC}"
        sudo -v
    fi
    sudo "$@"
}

confirm() {
    local prompt="$1"
    while true; do
        read -rp "${YELLOW}${prompt} (j/n)${NC} " answer
        case "$answer" in
            [JjYy]* ) return 0;;
            [Nn]* ) exit 1;;
            * ) echo -e "${YELLOW}Bitte mit j/ja oder n/nein antworten.${NC}";;
        esac
    done
}

# ==================== #
# HAUPTSKRIPT          #
# ==================== #

exec > >(tee -a "$LOG_FILE") 2>&1
echo -e "${GREEN}=== Debian Upgrade-Skript gestartet: $(date) ===${NC}"

# 0. Initiale Berechtigungen prüfen
sudo_with_check true

# 1. Systemvorbereitung
echo -e "${GREEN}=== Phase 1: Systemvorbereitung ===${NC}"
sudo_with_check apt-get update
sudo_with_check apt-get install -y --no-install-recommends \
    aptitude \
    apt-transport-https \
    debian-archive-keyring \
    network-manager \
    wpasupplicant

# 2. LXQt Deinstallation
echo -e "${GREEN}=== Phase 2: LXQt Deinstallation ===${NC}"
confirm "LXQt deinstallieren?"

# Temporärer Schutz
export SUDO_FORCE_REMOVE=yes
sudo_with_check apt-mark hold sudo network-manager

LXQT_PKGS=(
    lxqt* pcmanfm-qt* qterminal* lximage-qt* featherpad* 
    openbox* obconf* lxmenu-data* xarchiver* xfwm4*
)

# Deinstallation
for pkg in "${LXQT_PKGS[@]}"; do
    sudo_with_check apt-get purge -y "$pkg"
done
sudo_with_check apt-get autoremove --purge -y

# 3. Systembereinigung
echo -e "${GREEN}=== Phase 3: Systembereinigung ===${NC}"
sudo_with_check aptitude purge '?narrow(?installed, ?not(?origin(Debian)))' --assume-yes
sudo_with_check aptitude purge '~o' --assume-yes
sudo_with_check aptitude purge '~c' --assume-yes

# 4. Upgrade auf Trixie
echo -e "${GREEN}=== Phase 4: Upgrade auf Trixie ===${NC}"
sudo_with_check cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo_with_check tee /etc/apt/sources.list <<EOF
deb https://deb.debian.org/debian trixie main contrib non-free
deb https://deb.debian.org/debian trixie-updates main contrib non-free
deb https://security.debian.org/debian-security trixie-security main
EOF

sudo_with_check apt-get update
sudo_with_check apt-get upgrade --without-new-pkgs -y
sudo_with_check apt-get dist-upgrade -y

# 5. KDE Installation
echo -e "${GREEN}=== Phase 5: KDE Installation ===${NC}"
sudo_with_check tasksel install kde-desktop

# 6. Netzwerkkonfiguration
echo -e "${GREEN}=== Phase 6: Netzwerkkonfiguration ===${NC}"
sudo_with_check sed -i '/^\[ifupdown\]$/,/^\[/ s/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf
sudo_with_check systemctl restart NetworkManager
sudo_with_check systemctl disable networking 2>/dev/null || true

# 7. Finale Bereinigung
echo -e "${GREEN}=== Phase 7: Finale Bereinigung ===${NC}"
sudo_with_check aptitude purge '~o' --assume-yes
sudo_with_check apt-get clean

echo -e "${GREEN}=== Upgrade erfolgreich! ===${NC}"
echo -e "Log: ${LOG_FILE}"
echo -e "Neustart mit: ${YELLOW}sudo reboot${NC}"
