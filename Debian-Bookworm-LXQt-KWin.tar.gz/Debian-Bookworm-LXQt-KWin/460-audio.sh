#!/bin/bash
sudo apt-get install pipewire-audio gstreamer1.0-pipewire pipewire-alsa pipewire-audio pipewire-bin pipewire-pulse pipewire-v4l2 vlc-plugin-pipewire yt-dlp volumeicon-alsa pavucontrol-qt pipewire pipewire-audio-client-libraries libspa-0.2-bluetooth wireplumber
sudo apt -t bookworm-backports install yt-dlp
sudo apt-get -y remove --purge pulseaudio
systemctl --user enable pipewire
systemctl --user enable pipewire-pulse
systemctl --user start pipewire
systemctl --user start pipewire-pulse
ln -sf /usr/share/doc/pipewire/examples/systemd/user/pipewire-pulse.* ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user restart pipewire pipewire-pulse
systemctl --user enable wireplumber
systemctl --user start wireplumber
systemctl --user --now enable wireplumber.service
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d $HOME/.config/systemd/user ]; then
	mkdir -p ~/.config/systemd/user
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
