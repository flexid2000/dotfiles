#!/bin/bash
if [ ! -d $HOME/.config/conky ]; then
  mkdir -p ~/.config/conky
fi
cp confiles/conky.conf ~/.config/conky
if [ ! -d $HOME/.config/yt-dlp ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if [ ! -d $HOME/.config/mpv ]; then
  mkdir -p ~/.config/mpv
fi
cp confiles/mpv.conf ~/.config/mpv
if [ ! -d $HOME/.recoll ]; then
  mkdir -p ~/.recoll
fi
cp confiles/mimeview confiles/recoll.conf ~/.recoll/
sudo cp confiles/recoll-index /etc/cron.daily/
sudo pacman -S cronie
sudo chmod 755 /etc/cron.daily/recoll-index
paru -S kvantum-theme-arc qt6-svg arc-gtk-theme
wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/arc-kde/master/install.sh | sh
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
sudo pacman -S ibus papirus-icon-theme
echo "GTK_IM_MODULE=ibus" > /tmp/environment
echo "QT_IM_MODULE=ibus" >> /tmp/environment
echo "XMODIFIERS=@im=ibus" >> /tmp/environment
sudo cp /tmp/environment /etc/environment
paru -S ibus-autostart-kimpanel ksuperkey
exit 0
