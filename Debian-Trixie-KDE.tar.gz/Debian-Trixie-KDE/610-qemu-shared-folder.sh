#!/bin/bash
set -e  # Bei Fehler abbrechen

echo "📦 Installiere SPICE-Gästeintegration ..."
sudo apt-get -y install spice-client-gtk spice-vdagent

echo "📁 Erstelle lokalen shared-Ordner, falls nicht vorhanden ..."
mkdir -p "$HOME/shared"

echo "🔧 Füge 9p-Mountpoint zu /etc/fstab hinzu (falls nicht vorhanden) ..."
if ! grep -q "/sharepoint" /etc/fstab; then
    echo -e '/sharepoint\t'"$HOME"'/shared\t9p\ttrans=virtio,version=9p2000.L,rw\t0\t0' | sudo tee -a /etc/fstab > /dev/null
    sudo sed -i -e '$a\\' /etc/fstab  # Stelle sicher, dass Datei mit Newline endet
fi

echo "🖥️ Setze xrandr auf 1920x1080 in SDDM Xsetup ..."
XSETUP="/usr/share/sddm/scripts/Xsetup"
XRANDR_LINE='xrandr --output "Virtual-1" --mode 1920x1080 --rate 60.00'
if ! grep -q "$XRANDR_LINE" "$XSETUP"; then
    echo "$XRANDR_LINE" | sudo tee -a "$XSETUP" > /dev/null
fi

echo "🚀 Erzeuge Autostart-Eintrag für Fullscreen-Modus ..."
AUTOSTART_DIR="$HOME/.config/autostart"
mkdir -p "$AUTOSTART_DIR"
cat > "$AUTOSTART_DIR/fullscreen.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Fullscreen
Exec=$XRANDR_LINE
X-GNOME-Autostart-enabled=true
EOF

echo "✅ Fertig."
exit 0

