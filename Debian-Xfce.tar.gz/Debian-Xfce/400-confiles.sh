#!/bin/bash
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky.conf ~/.config/conky/
cp conky-shortcuts.conf ~/.config/conky/
cp redshift.conf ~/.config
cp .xprofile ~/.xprofile
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/kde.org" ]; then
  mkdir -p ~/.config/kde.org
fi
echo "alias upgrade='sudo apt update && sudo apt -y full-upgrade && sudo apt -y autoremove --purge && sudo apt-get clean'" > ~/.bash_aliases
source ~/.bashrc
cp ghostwriter.conf ~/.config/kde.org
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo apt-fast -y install xfce4-dev-tools
#wget http://mxrepo.com/mx/repo/pool/main/x/xfce4-docklike-plugin/xfce4-docklike-plugin_0.4.0+git20211128-1~mx21+1_amd64.deb
wget http://mxrepo.com/mx/repo/pool/main/x/xfce-superkey-mx/xfce-superkey-mx_21.09.01_amd64.deb
#sudo dpkg -i xfce4-docklike-plugin_0.4.0+git20211128-1~mx21+1_amd64.deb xfce-superkey-mx_21.09.01_amd64.deb
sudo apt -y install fonts-croscore
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>w" -n -t string -s "exo-open --launch WebBrowser"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>m" -n -t string -s "exo-open --launch MailReader"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>t" -n -t string -s "exo-open --launch TerminalEmulator"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>f" -n -t string -s "exo-open --launch FileManager"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>e" -n -t string -s "geany"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>l" -n -t string -s "libreoffice --writer --nologo"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>x" -n -t string -s "xfce4-session-logout"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>Escape" -n -t string -s "xkill"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>n" -n -t string -s "xpad -t"
xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Super>Down" -n -t string -s "wmctrl -r :ACTIVE: -e 0,480,270,960,540"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Alt><Super>Down" -n -t string -s "tile_down_right_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Alt><Super>Left" -n -t string -s "tile_down_left_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Alt><Super>Right" -n -t string -s "tile_up_right_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Alt><Super>Up" -n -t string -s "tile_up_left_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>d" -n -t string -s "show_desktop_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>i" -n -t string -s "hide_window_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>Left" -n -t string -s "tile_left_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>q" -n -t string -s "close_window_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>Right" -n -t string -s "tile_right_key"
xfconf-query -c xfce4-keyboard-shortcuts -p "/xfwm4/custom/<Super>Up" -n -t string -s "maximize_window_key"
cp .hidden ~/
cp .bash_aliases ~/
source ~/.bashrc
exit 0
