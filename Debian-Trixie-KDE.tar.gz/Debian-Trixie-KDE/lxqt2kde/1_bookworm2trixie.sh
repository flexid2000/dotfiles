#!/bin/bash

# Farben
RED="\033[1;31m"; GREEN="\033[1;32m"; YELLOW="\033[1;33m"; RESET="\033[0m"

# Bestätigungsfunktion
confirm() {
  echo -en "${YELLOW}$1 [j/N]: ${RESET}"
  read -r reply
  [[ "$reply" =~ ^[JjYy]$ ]]
}

set -euo pipefail

# SDDM ausschalten
echo -e "${GREEN}Prüfe, ob SDDM läuft...${RESET}"
if systemctl is-active --quiet sddm; then
  echo -e "${YELLOW}SDDM ist aktiv und wird gestoppt.${RESET}"
  sudo systemctl stop sddm
else
  echo -e "${GREEN}SDDM läuft nicht.${RESET}"
fi

# Root-Passwort
echo -e "${GREEN}Prüfe, ob ein Root-Passwort gesetzt ist...${RESET}"

root_status=$(sudo passwd -S root | awk '{print $2}')
if [ "$root_status" = "L" ]; then
  echo -e "${YELLOW}Root-Account ist gesperrt. Soll ein Root-Passwort vergeben und entsperrt werden?${RESET}"
  if confirm "Root-Passwort setzen und Account entsperren?"; then
    sudo passwd root
  else
    echo -e "${GREEN}Root-Account bleibt gesperrt.${RESET}"
  fi
else
  echo -e "${GREEN}Root-Passwort ist gesetzt oder der Account ist nicht gesperrt.${RESET}"
fi

echo -e "${GREEN}1. Systemaktualisierung (Bookworm)${RESET}"
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get full-upgrade -y
sudo apt-get autoremove -y

echo -e "${YELLOW}=== Installiere essentielle Pakete ===${RESET}"
sudo apt-get update
sudo apt-get install -y sudo network-manager-gnome wpasupplicant aptitude

echo -e "${GREEN}2. LXQt Deinstallation${RESET}"
if confirm "LXQt deinstallieren?"; then
    sudo apt-get -y --auto-remove purge liblxqt-* lximage-qt* lxqt lxqt-* pavucontrol-qt task-lxqt-desktop pcmanfm-qt* libfm-qt12
fi

echo -e "${GREEN}3. Entferne obsolete Pakete mit aptitude.${RESET}"
sudo aptitude update
sudo aptitude -y purge '~o'

echo -e "${GREEN}4. Obsolete Pakete entfernt.${RESET}"

# Nicht-Debian-Pakete entfernen
if ! command -v apt-show-versions &> /dev/null; then
  echo "apt-show-versions wird installiert..."
  sudo apt-get update
  sudo apt-get install -y apt-show-versions
fi

echo -e "${GREEN}5. Nicht-Debian-Pakete werden gesucht...${RESET}"
local_pkgs=$(apt-show-versions | grep "No available version" | awk -F: '{print $1}' || true)
if [ -n "$local_pkgs" ]; then
  echo -e "${GREEN}Nicht-Debian-Pakete entfernen.${RESET}"
  sudo apt-get -y purge $local_pkgs
else
  echo -e "${GREEN}Keine Nicht-Debian-Pakete gefunden.${RESET}"
fi

# Hinweis auf Drittquellen
echo -e "${YELLOW}Prüfe gegebenenfalls auch /etc/apt/sources.list.d/ auf Bookworm-Einträge!${RESET}"

echo -e "${GREEN}6. /etc/apt/sources.list auf Trixie umstellen${RESET}"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo sed -i 's/bookworm/trixie/g' /etc/apt/sources.list

echo -e "${GREEN}7. Neue Paketlisten einlesen${RESET}"
sudo apt-get update

echo -e "${GREEN}8. Minimal-Upgrade (ohne neue Pakete)${RESET}"
sudo apt-get -y upgrade --without-new-pkgs

echo -e "${GREEN}9. Volles System-Upgrade${RESET}"
sudo apt-get -y full-upgrade

echo -e "${GREEN}Erster Teil des Upgrades abgeschlossen. Starte das System neu.${RESET}"
if confirm "Jetzt neu starten?"; then
  sudo reboot
fi
