#!/bin/bash
paru -S --needed perl-rename poppler pandoc-bin xclip mupdf-tools unoconv libnotify python-weasyprint
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
if [ ! -d "$HOME/.local/share/kio/servicemenus" ]; then
	mkdir -p ~/.local/share/kio/servicemenus
fi
if [ ! -d "$HOME/.config/kde.org" ]; then
	mkdir -p ~/.config/kde.org
fi
cp confiles/custom-reference.odt ~/.local/share/pandoc
cp confiles/pagebreak.lua ~/.local/share/pandoc/filters
cp servicemenus/md2weasyprint.sh servicemenus/md2odt.sh servicemenus/weasyprint.css servicemenus/slugify-umlaute.sh ~/.local/bin
cp confiles/ghostwriter.conf ~/.config/kde.org
cp servicemenus/*.desktop ~/.local/share/kio/servicemenus
chmod 755 servicemenus/*.desktop
exit 0
