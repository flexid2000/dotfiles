#!/bin/bash
if [ ! -d $HOME/Applications ]; then
  mkdir -p $HOME/Applications
fi
wget https://www.dropbox.com/s/odn4tnu9cqlmq8h/deemix-linux-x64.AppImage?dl=0
mv deemix-linux-x64.AppImage?dl=0 ~/Applications/deemix.AppImage
chmod 755 ~/Applications/deemix.AppImage
#cp confiles/deemix.desktop ~/.local/share/applications
wget https://github.com/probonopd/go-appimage/releases/download/continuous/appimaged-650-x86_64.AppImage
mv appimaged-650-x86_64.AppImage ~/Applications
chmod 755 ~/Applications/appimaged-650-x86_64.AppImage
~/Applications/appimaged-650-x86_64.AppImage
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf	
exit 0
