#!/bin/bash
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
cp bash-scripts/* ~/.local/bin
exit 0
