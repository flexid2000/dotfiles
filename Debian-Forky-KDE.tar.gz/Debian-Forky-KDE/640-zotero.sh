#!/bin/bash
set -e
curl -sL https://raw.githubusercontent.com/retorquere/zotero-deb/master/install.sh | sudo bash
sudo apt-fast update
sudo apt-get install zotero
exit 0
