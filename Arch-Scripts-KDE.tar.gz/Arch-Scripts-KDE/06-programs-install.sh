#!/bin/bash
paru -S --needed --noconfirm alsa-firmware alsa-utils antiword arj ark aspell-de atomicparsley \
audacious audacious-plugins audiocd-kio bluedevil bluez-utils cabextract catdoc \
chromium cmark conky dolphin-plugins exfatprogs ffmpegthumbs firefox \
firefox-i18n-de fwupd geoip ghostwriter gimp gnu-free-fonts grsync gst-libav \
gst-plugins-bad gst-plugins-bad-libs gst-plugins-good gst-plugin-pipewire \
gst-plugins-ugly gst-python gtksourceview3 gwenview \
fcitx5 fcitx5-configtool fcitx5-gtk fcitx5-qt imagemagick \
inkscape java-runtime kcharselect kcolorchooser kcron kde-gtk-config \
kde-system-meta kde-utilities-meta kdeconnect kdegraphics-thumbnailers \
kdeplasma-addons kfind kget kgpg khelpcenter kimageformats \
kinfocenter kio-fuse kpipewire krename kruler \
ksystemlog ktorrent kvantum kwallet-pam kwalletmanager libertinus-font \
libgsf libkeybinder3 libmythes libreoffice-fresh libreoffice-fresh-de \
mariadb-libs mathjax mkinitcpio-firmware mpg123 mpv nextcloud-client \
okular opus-tools \
p7zip packagekit-qt6 perl-archive-zip perl-image-exiftool \
pipewire-alsa pipewire-pulse pipewire-v4l2 pipewire-zeroconf \
plasma plasma-browser-integration plasma-workspace-wallpapers \
plocate poppler-glib powerdevil print-manager pstoedit pstotext \
python-dbus python-musicbrainzngs python-pycryptodome \
python-pyinotify qt5-declarative qt5-wayland quodlibet \
qt5-quickcontrols2 recoll scour sddm-kcm sharutils skanpage \
spectacle sshfs strawberry \
svgpart system-config-printer thunderbird thunderbird-i18n-de \
tk ttf-caladea ttf-carlito ttf-croscore noto-fonts-emoji \
ttf-roboto inter-font ttf-fira-code ttf-opensans ttf-dejavu \
twolame unace unarchiver unrar unrtf unzip \
uudeview vlc wireplumber xdg-desktop-portal-kde xsettingsd \
yakuake yt-dlp zip inter-font ttf-fira-code
sudo cp confiles/local.conf /etc/fonts
sudo fc-cache -frv
exit 0
