#!/bin/bash
for FILE in "$@"; do
	pandoc -s "${FILE}" \
	-f markdown+emoji \
	--pdf-engine=wkhtmltopdf \
	--css=$HOME/.local/bin/pandoc.css \
	--pdf-engine-opt="-L" \
	--pdf-engine-opt="20mm" \
	--pdf-engine-opt="-R" \
	--pdf-engine-opt="20mm" \
	--pdf-engine-opt="-T" \
	--pdf-engine-opt="15mm" \
	--pdf-engine-opt="-B" \
	--pdf-engine-opt="20mm" \
	--pdf-engine-opt="--footer-center" \
	--pdf-engine-opt="[page]" \
	--pdf-engine-opt="--footer-font-size" \
	--pdf-engine-opt="11" \
	--lua-filter=pagebreak.lua \
	-o "${FILE%.*}".pdf
done
exit 0
