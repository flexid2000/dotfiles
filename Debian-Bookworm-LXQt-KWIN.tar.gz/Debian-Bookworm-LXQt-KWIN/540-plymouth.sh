#!/bin/bash
sudo apt-fast -y install plymouth plymouth-themes plymouth-x11
#sudo sed -i 's/BackgroundStartColor=0x000000/BackgroundStartColor=0x282a36/' /usr/share/plymouth/themes/spinner/spinner.plymouth
#sudo sed -i 's/BackgroundEndColor=0x000000/BackgroundEndColor=0x282a36/' /usr/share/plymouth/themes/spinner/spinner.plymouth
sudo plymouth-set-default-theme -R spinner
sudo apt-fast -y install systemd-boot
echo "sudo su"
echo "cd /boot/efi/loader/entries"
echo "splash in XXXXXX-amd64.conf einfügen"
exit 0
