#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
sddm --example-config > /tmp/sddm.conf
sudo cp /tmp/sddm.conf /etc/sddm.conf
sudo pacman --noconfirm --needed qt5-quickcontrols2 qt5-graphicaleffects
wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/materia-kde/master/install.sh | sh
sudo sed -i 's/Session=/Session=lxqt.desktop/' /etc/sddm.conf
sudo sed -i "s|User=|User=$USER|g" /etc/sddm.conf
sudo sed -i 's/Current=/Current=materia/' /etc/sddm.conf
sudo sed -i 's/CursorTheme=/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo cp artwork/grub-16x9.png /usr/share/sddm/themes/materia/images/background.png
exit 0
