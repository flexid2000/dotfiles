#!/bin/bash
rename 's/Ä|ä/ae/g;s/Ö|ö/oe/g;s/Ü|ü/ue/g;s/ß/ss/g;s/,/-/g;s/"//g;s/\?//g;s/–//g;s/É/e/g;s/é/e/g;s/è/e/g;s/_/-/g;s/ /-/g;s/-{2,}/-/g;y/A-Z/a-z/' "$1"
exit 0
