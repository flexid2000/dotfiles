#!/bin/bash
sudo apt-fast -y install rename poppler-utils graphicsmagick graphicsmagick-imagemagick-compat pandoc xclip poppler-utils mupdf-tools unoconv libnotify-bin img2pdf wkhtmltopdf librsvg2-bin
if [ ! -d "$HOME/.local/share/kio/servicemenus" ]; then
  mkdir -p ~/.local/share/kio/servicemenus
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc/filters" ]; then
	mkdir -p ~/.local/share/pandoc/filters
fi
cp confiles/custom-reference.odt ~/.local/share/pandoc
cp servicemenus/*.sh servicemenus/*.css ~/.local/bin
cp servicemenus/*.desktop ~/.local/share/kio/servicemenus
cp confiles/pagebreak.lua ~/.local/share/pandoc/filters
exit 0
