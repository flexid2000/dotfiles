#!/bin/bash
#
# sources.list in Debian Trixie anpassen
#
sudo apt-get -y install curl
echo "deb http://mirror.ipb.de/debian/ trixie main contrib non-free non-free-firmware" > /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ trixie-updates main contrib non-free non-free-firmware" >> /tmp/sources.list
echo "deb http://mirror.ipb.de/debian/ trixie-backports main contrib non-free non-free-firmware" >> /tmp/sources.list
echo "deb http://deb.debian.org/debian-security trixie-security main" >> /tmp/sources.list
sudo cp /tmp/sources.list /etc/apt
sudo apt-get update
exit 0
