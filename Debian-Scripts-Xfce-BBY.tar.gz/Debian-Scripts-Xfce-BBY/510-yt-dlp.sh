#!/bin/bash
if ! command -v curl &> /dev/null
then
    sudo apt -y install curl
fi
sudo apt-fast -y install smplayer
if ! command -v /usr/bin/youtube-dl &> /dev/null
then
    sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
else
    sudo apt-fast -y purge youtube-dl
    sudo apt-fast -y autoremove --purge
    sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
fi
sudo chmod a+rx /usr/local/bin/yt-dlp
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if ! command -v /usr/bin/python &> /dev/null
then
    sudo ln -s /usr/bin/python3 /usr/bin/python
fi
sudo ln -s /usr/local/bin/yt-dlp /usr/local/bin/youtube-dl
exit 0
