#!/bin/bash

# Standardwerte setzen
DEFAULT_QUALITY=85
DEFAULT_INTERLACE="true"
DEFAULT_REDUCE_COLORS="true"  # Farbreduzierung jetzt standardmäßig AKTIV
DEFAULT_REMOVE_METADATA="true"
MAX_SIZE="1920x1080>"

# Prüfen, ob mindestens eine Datei angegeben wurde
if [[ $# -lt 1 ]]; then
    echo "Nutzung: $0 [quality] [interlace] [reduce_colors] [remove_metadata] bild1 bild2 ..."
    exit 1
fi

# Falls die ersten vier Argumente Optionen sind, übernehmen – sonst Standardwerte setzen
if [[ "$1" =~ ^[0-9]+$ ]]; then
    QUALITY="$1"; shift
    INTERLACE="$1"; shift
    REDUCE_COLORS="$1"; shift
    REMOVE_METADATA="$1"; shift
else
    QUALITY=$DEFAULT_QUALITY
    INTERLACE=$DEFAULT_INTERLACE
    REDUCE_COLORS=$DEFAULT_REDUCE_COLORS
    REMOVE_METADATA=$DEFAULT_REMOVE_METADATA
fi

# Schleife über alle angegebenen Dateien
for INPUT in "$@"; do
    if [[ ! -f "$INPUT" ]]; then
        echo "Datei nicht gefunden: $INPUT"
        continue
    fi

    BASENAME="${INPUT%.*}"
    EXT="${INPUT##*.}"
    OUTPUT="${BASENAME}-web.${EXT}"
    TMP_OUTPUT="${BASENAME}-web-tmp.${EXT}"

    OPTIONS="-resize $MAX_SIZE -density 72 -units PixelsPerInch"
    [[ "$INTERLACE" == "true" ]] && OPTIONS="$OPTIONS -interlace Plane"
    [[ "$REMOVE_METADATA" == "true" ]] && OPTIONS="$OPTIONS -strip"

    if [[ "$EXT" == "jpg" || "$EXT" == "jpeg" ]]; then
        OPTIONS="$OPTIONS -quality $QUALITY -sampling-factor 4:2:0"
    elif [[ "$EXT" == "png" ]]; then
        OPTIONS="$OPTIONS -quality $QUALITY"
    fi

    # Erstes Speichern ohne Farbreduktion
    convert "$INPUT" $OPTIONS "$TMP_OUTPUT"

    if [[ "$REDUCE_COLORS" == "true" && "$EXT" == "png" ]]; then
        convert "$TMP_OUTPUT" -colors 256 "$OUTPUT"

        ORIG_SIZE=$(stat -c %s "$TMP_OUTPUT")
        REDUCED_SIZE=$(stat -c %s "$OUTPUT")

        if [[ "$REDUCED_SIZE" -ge "$ORIG_SIZE" ]]; then
            echo "Farbreduktion war nicht effektiv für $INPUT – Original bleibt erhalten."
            mv "$TMP_OUTPUT" "$OUTPUT"
        else
            echo "Farbreduktion angewendet für $INPUT: Datei wurde kleiner."
        fi
    else
        mv "$TMP_OUTPUT" "$OUTPUT"
    fi

    echo "Bild gespeichert als: $OUTPUT"
done
