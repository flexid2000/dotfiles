#!/bin/bash
set -e

echo "🧠 Installiere systemd-zram-generator ..."
sudo apt-get install -y systemd-zram-generator

# Optional: Deaktiviere alte Audiopakete
sudo apt-get purge -y pulseaudio-module-bluetooth pulseaudio ofono

echo "✅ ZRAM-Konfiguration abgeschlossen."

