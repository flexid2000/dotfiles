#!/bin/bash
set -e

echo "🎨 Installiere Desktop-Zubehör ..."
sudo apt-get install -y \
    kdegraphics-thumbnailers okular svgpart \
    strawberry quodlibet numlockx dolphin-plugins \
    plasma-browser-integration xbindkeys \
    qt6-style-kvantum
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky* ~/.config/conky
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp config ~/.config/yt-dlp
cp .bash_aliases ~/
source ~/.bashrc
mkdir -p ~/.config/libreoffice/4/user/template
cp babylonia.ott ~/.config/libreoffice/4/user/template
cp kscreen.desktop $HOME/.local/share/applications
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
cp dolphinrc katerc konsolerc okularpartrc ~/.config
cp .hidden ~/ || true
sudo systemctl enable bluetooth.service
sudo systemctl start bluetooth.service
sudo sed -i 's/'#AutoEnable=false'/'AutoEnable=true'/g' /etc/bluetooth/main.conf

echo "✅ Desktop-Komponenten installiert."

