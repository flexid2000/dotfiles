#!/bin/bash
paru -S --needed git kvantum-qt5 faba-icon-theme moka-icon-theme papirus-icon-theme dracula-gtk-theme ant-dracula-kvantum-theme-git dracula-openbox-theme
mkdir -p dracula-tmp
cd dracula-tmp
git clone https://github.com/matheuuus/dracula-icons.git
mv dracula-icons Dracula
sed -i 's/Inherits=/Inherits=Faba,Moka,Papirus/g' Dracula/index.theme
sudo cp -r Dracula /usr/share/icons/
sudo cp ~/Downloads/Arch-Scripts-LXQt/confiles/Dracula.colorscheme /usr/share/qtermwidget5/color-schemes/
git clone https://github.com/dracula/libreoffice.git
mkdir -p ~/.config/libreoffice/4/user/config
cp libreoffice/dracula.soc ~/.config/libreoffice/4/user/config/
cd ..
sudo rm -R dracula-tmp
exit 0




