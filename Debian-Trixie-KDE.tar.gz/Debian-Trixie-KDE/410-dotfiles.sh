#!/bin/bash
set -e

echo "⚙️ Kopiere Konfigurationsdateien ..."
mkdir -p ~/.config/conky ~/.local/bin ~/.local/share/applications ~/.config/libreoffice/4/user/template

cp confiles/conky* ~/.config/conky
cp confiles/babylonia.ott ~/.config/libreoffice/4/user/template
sudo cp confiles/40-libinput.conf /etc/X11/xorg.conf.d/

echo "✅ Dotfiles und LibreOffice-Vorlagen installiert."

