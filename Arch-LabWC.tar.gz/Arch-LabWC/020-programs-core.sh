#!/bin/bash

set -e

# Pakete aus den offiziellen Repos installieren
paru -S --needed accountsservice adwaita-cursors adwaita-fonts adwaita-icon-theme arc-kde cliphist feathernotes featherpad firefox firefox-i18n-de gammastep greetd greetd-tuigreet grim gvfs gvfs-mtp haveged hunspell hunspell-de hyprpicker ibus ibus-unikey inter-font kanshi kimageformats kvantum labwc libappindicator-gtk3 libheif lximage-qt lxqt-archiver lxqt-config mako mesa network-manager-applet networkmanager papirus-icon-theme pcmanfm-qt pixman qemu-guest-agent qt6ct rofi-wayland seatd slurp spice-gtk spice-vdagent swaybg swayidle swaylock ttf-croscore ttf-dejavu ttf-firacode-nerd virglrenderer vulkan-intel waybar wl-clipboard

# Pakete aus dem AUR
paru -S --needed meteo-qt wdisplays wlogout wlopm wlrctl wlroots-nogpu xcursor-breeze

# Veraltete Pakete aus dem Archiv
wget https://archive.archlinux.org/packages/a/arc-gtk-theme/arc-gtk-theme-20221218-2-any.pkg.tar.zst
sudo pacman -U arc-gtk-theme-20221218-2-any.pkg.tar.zst
wget https://archive.archlinux.org/packages/o/otf-font-awesome/otf-font-awesome-7.0.0-4-any.pkg.tar.zst
sudo pacman -U otf-font-awesome-7.0.0-4-any.pkg.tar.zst

