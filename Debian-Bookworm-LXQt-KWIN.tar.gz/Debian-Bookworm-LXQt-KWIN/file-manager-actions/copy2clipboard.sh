#!/bin/bash
readlink -f -z $1 | xclip -selection clipboard
exit 0
