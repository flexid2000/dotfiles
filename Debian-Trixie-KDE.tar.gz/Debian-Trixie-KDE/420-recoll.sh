#!/bin/bash
set -e

echo "🔍 Installiere Recoll und Konfiguration ..."
sudo apt-get install -y \
    recoll aspell-de python3 xsltproc unzip poppler-utils \
    antiword wv libwpd-tools catdoc libchm-bin info tar \
    librdf-icalendar-perl unrtf untex libimage-exiftool-perl \
    python3-chardet python3-yaml

mkdir -p ~/.recoll
cp confiles/mimeview ~/.recoll/
cp confiles/recoll.conf ~/.recoll/
sudo cp confiles/recoll-index /etc/cron.daily/
sudo chmod 755 /etc/cron.daily/recoll-index

echo "✅ Recoll-Installation abgeschlossen."

