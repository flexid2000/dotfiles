#!/bin/bash
convert "$@" converted2pdf.pdf
exit 0
