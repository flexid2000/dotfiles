#!/bin/bash
sudo apt -y install dialog ssft zenity zenity-common
wget https://packages.siduction.org/extra/pool/main/k/kernel-remover/kernel-remover_3.1.17_all.deb
sudo dpkg -i *.deb
exit 0
