#!/bin/bash

CSS="$HOME/.local/bin/weasyprint.css"

for FILE in "$@"; do
    pandoc \
       --from markdown+emoji \
       --to html5 \
       --standalone \
       --css "$CSS" \
       -V lang=de \
       -V graphics=yes \
       -V include-before-body='<style>img { max-width: 100% }</style>' \
       --metadata pagetitle="${FILE%.*}" \
       --metadata lang="de" \
       --pdf-engine=weasyprint \
       --pdf-engine-opt="--quiet" \
       -o "${FILE%.md}.pdf" \
       "$FILE"
done
exit $?
