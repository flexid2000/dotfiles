#!/bin/bash
sudo apt -y install recoll python3 xsltproc unzip poppler-utils antiword wv libwpd-tools catdoc libchm-bin info tar librdf-icalendar-perl unrtf untex dvi2ps libimage-exiftool-perl python3-chardet
mkdir -p ~/.recoll
cp confiles/mimeview ~/.recoll/
cp confiles/recoll.conf ~/.recoll/
sudo cp confiles/recoll-index /etc/cron.daily/
exit 0
