#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget https://www.dropbox.com/s/odn4tnu9cqlmq8h/deemix-linux-x64.AppImage?dl=0
mv deemix-linux-x64.AppImage?dl=0 ~/.local/bin/deemix.AppImage
chmod 755 ~/.local/bin/deemix.AppImage
cp confiles/deemix.desktop ~/.local/share/applications
exit 0
