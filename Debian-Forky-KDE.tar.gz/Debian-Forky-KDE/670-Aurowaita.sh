#!/bin/bash

set -e

git clone https://github.com/sabaneko-run/aurowaita.git
cd aurowaita
mkdir -p ~/.local/share/aurorae/themes/
cp -r src/* ~/.local/share/aurorae/themes/
rm -r aurowaita

git clone https://github.com/GabePoel/KvLibadwaita.git
cd KvLibadwaita
./install.sh
rm -r KvLibadwaita

exit 0

