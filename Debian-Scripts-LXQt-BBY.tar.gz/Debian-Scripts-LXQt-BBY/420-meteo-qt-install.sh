#!/bin/bash
echo "Kann aus dem Repositories von Debian Bookworm installiert werden"
read
sudo apt-fast -y purge meteo-qt meteo-qt-l10n
sudo apt-fast -y install python3-pyqt5 python3-sip python3-lxml pyqt5-dev-tools qttools5-dev-tools git pyqt5-dev-tools python3-distutils
git clone https://github.com/dglent/meteo-qt.git
cd meteo-qt
sudo python3 setup.py install
if [ ! -d $HOME/.config/meteo-qt ]; then
  mkdir -p ~/.config/meteo-qt
fi
cd ..
cp confiles/meteo-qt.conf ~/.config/meteo-qt/
sudo rm -R meteo-qt
exit 0
