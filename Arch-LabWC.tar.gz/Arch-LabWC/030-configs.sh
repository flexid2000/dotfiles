#!/bin/bash

set -e

# Ordner anlegen
if [ ! -d $HOME/.config ]; then
  mkdir -p ~/.config
fi
if [ ! -d $HOME/.local/share ]; then
  mkdir -p ~/.local/share
fi
if [ ! -d $HOME/Bilder/artwork ]; then
  mkdir -p ~/Bilder/artwork
fi

# Konfigurationsdateien kopieren
cp -R config/feathernotes config/foot config/kanshi config/labwc config/mako config/meteo-qt config/rofi config/waybar $HOME/.config/
cp -R local_share/themes $HOME/.local/share

# Hintergrundsbild
cp artwork/labwc.png $HOME/Bilder/artwork

# Login-Manager
sudo useradd -r -M -G seat -s /bin/nologin greetd
sudo usermod -aG seat $USER
sudo usermod -aG video $USER
sudo systemctl enable seatd
sudo cp config/config.toml /etc/greetd/

exit 0
