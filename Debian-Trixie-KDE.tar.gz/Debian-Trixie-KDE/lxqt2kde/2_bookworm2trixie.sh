#!/bin/bash

# Farben
RED="\033[1;31m"; GREEN="\033[1;32m"; YELLOW="\033[1;33m"; RESET="\033[0m"

# Bestätigungsfunktion
confirm() {
  echo -en "${YELLOW}$1 [j/N]: ${RESET}"
  read -r reply
  [[ "$reply" =~ ^[JjYy]$ ]]
}

set -euo pipefail

echo -e "${GREEN}1. Aufräumen nach dem Upgrade${RESET}"
sudo apt-get -y autoremove --purge

echo -e "${GREEN}2. Entferne obsolete Pakete.${RESET}"
sudo aptitude update
sudo aptitude -y purge '~o'

echo -e "${GREEN}3. Entferne verwaiste Konfigurationsdateien.${RESET}"
sudo aptitude -y purge '~c'

# tasksel-Check und KDE-Installation
if ! command -v tasksel &> /dev/null; then
  echo -e "${YELLOW}tasksel wird installiert...${RESET}"
  sudo apt-get install -y tasksel
fi

echo -e "${GREEN}4. KDE Plasma installieren.${RESET}"
sudo tasksel install -y kde-desktop

echo -e "${GREEN}5. Überflüssige Programme entfernen${RESET}"
sudo apt-get -y --auto-remove purge qpdfview* feathernotes* featherpad* qlipper* xarchiver* lximage-qt* screengrab* quassel* qps* qterminal* akonadi-server akregator dragonplayer hugin juk k3b kaccounts-integration kaccounts-providers kaddressbook kamoso kdeconnect kget kgpg kmag kmahjongg kmail kmines kmousetool kmouth konqueror kontrast korganizer kpat krdc ksystemlog ktouch kturtle kwordquiz pim-data-exporter pim-sieve-editor

# Root-Account sperren
echo -e "${GREEN}6. Root-Account sperren${RESET}"
sudo passwd -l root

echo -e "${GREEN}Upgrade abgeschlossen. Starte das System neu.${RESET}"
if confirm "Jetzt neu starten?"; then
  sudo reboot
fi


