| Aktion                             | Shortcut                |
| ---------------------------------- | ----------------------- |
| App Starter: Rofi             | Alt + Leertaste         |
| Ausschneiden                       | Strg + X                |
| Kopieren                           | Strg + C                |
| Einfügen                           | Strg + V                |
| Neuer Tab im Browser   | Strg + T                |
| Tab schließen                  | Strg + W                |
| Cursor in Adresszeile     | Strg + L                |
| Fenster in Vollbild           | F11                     |
| Fenster nach links kacheln     | Windows + links         |
| Fenster nach rechts kacheln  |  Windows + rechts   |
| Fenster vergrößern                 | Windows + hoch          |
| Fenster verkleinern und zentrieren | Windows + Bild runter        |
| Fenster nach links oben kacheln    | Windows + Alt + rechts    |
| Fenster nach links unten kacheln   | Windows + Alt + runter  |
| Fenster nach rechts unten kacheln  | Windows + Alt + links  |
| Fenster nach rechts oben kacheln   | Windows + Alt + hoch  |
| Fenster schließen                  | Windows + Q                |
| File Manager                       | Windows + F             |
| LibreOffice Writer                 | Windows + L             |
| Mail Reader                        | Windows + M             |
| Terminal                           | Windows + Return             |
| Web Browser                        | Windows + B             |
| Logout                             | Windows + X             |
| Menü                               | Alt + F1                 |
| Schreibtisch anzeigen              | Windows + D             |
| Text bis Dokumentende markieren (LO)    | Strg + Umschalt + End |
| Zum Seitenanfang                   | Strg + Pos1             |
| Zum Seitenende                     | Strg + End              |