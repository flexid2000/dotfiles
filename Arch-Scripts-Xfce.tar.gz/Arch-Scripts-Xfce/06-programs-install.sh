#!/bin/bash
paru -S --needed --noconfirm atomicparsley audacious audacious-plugins brave-bin clementine conky evince file-roller fuse2 geany ghostscript gimp gimp-help-de gnome-calculator gst-libav gst-plugins-bad gst-plugins-base gst-plugins-base-libs gst-plugins-good gst-plugins-ugly gtk-engine-murrine gtk-engines inkscape java-runtime kvantum-qt5 libappindicator-gtk3 libmythes libpaper libreoffice-fresh libreoffice-fresh-de man-db man-pages man-pages-de mariadb-libs mlocate noto-fonts noto-fonts-emoji p7zip plank poppler-data pstoedit python-pycryptodome qt5ct rtmpdump sdl sdl_image seahorse smplayer smplayer-skins smplayer-themes soundconverter thunderbird thunderbird-i18n-de ttf-caladea ttf-carlito ttf-croscore ttf-liberation ttf-roboto vlc wmctrl xclip xdotool xpad yt-dlp
sudo cp ~/Downloads/Arch-Scripts-Xfce/confiles/local.conf /etc/fonts
sudo fc-cache -frv
exit 0
