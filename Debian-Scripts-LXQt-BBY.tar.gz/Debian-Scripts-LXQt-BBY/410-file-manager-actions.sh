#!/bin/bash
sudo apt-fast -y install rename
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
sudo apt-fast -y install xclip
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
cp file-manager-actions/*.sh file-manager-actions/*.py ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
exit 0
