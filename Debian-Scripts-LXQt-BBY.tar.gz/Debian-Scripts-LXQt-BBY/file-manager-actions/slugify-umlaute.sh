#!/bin/bash
# Debian: `sudo apt install rename`
# Arch: `sudo pacman -S perl-rename`
for i in "$@"; do
	perl-rename 's/\:|\?|\!|\<|\>|@|\[|\]|\#|\&//g;s/ä|Ä/ae/g;s/ö|Ö/oe/g;s/ü|Ü/ue/g;s/ß/ss/g;s/\(|\)//g;s/,/-/g;s/"//g;s/–//g;s/É|é/e/g;s/è/e/g;s/_/-/g;s/ /-/g;s/-{2,}/-/g;y/A-Z/a-z/;s/-\./\./g' "$i"
done
exit 0

