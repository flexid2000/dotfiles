#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
if [ ! -d /etc/sddm.conf.d ]; then
  sudo mkdir -p /etc/sddm.conf.d
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sudo cp confiles/kde_settings.conf /etc/sddm.conf.d
sudo sed -i 's/^timeout.*/timeout=0/' /boot/loader/loader.conf
sudo pacman --needed -S papirus-icon-theme kvantum kvantum nordic-theme qt6-multimedia-gstreamer plasma-workspace librsvg

echo "Erstelle Hintergrundsbild"
sudo mkdir -p /usr/share/wallpapers/solid
sudo magick -size 1920x1080 xc:"#3c4454" /usr/share/wallpapers/solid/1920x1080-nordic.png

echo "🖼️ Konfiguriere SDDM ..."
sddm --example-config | sudo tee /etc/sddm.conf > /dev/null
sudo sed -i 's/^CursorTheme=.*/CursorTheme=Breeze_Snow/' /etc/sddm.conf
sudo sed -i 's/^InputMethod=qtvirtualkeyboard/InputMethod=/' /etc/sddm.conf

echo "🎨 Erstelle Breeze-No-Blur-Theme für SDDM ..."
sudo cp -r /usr/share/sddm/themes/breeze /usr/share/sddm/themes/breeze-no-blur
sudo chown -R root:root /usr/share/sddm/themes/breeze-no-blur
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze-no-blur/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze-no-blur/' /etc/sddm.conf

echo "📄 Schreibe theme.conf.user für breeze-no-blur ..."
sudo tee /usr/share/sddm/themes/breeze-no-blur/theme.conf.user > /dev/null <<EOF
[General]
background=/usr/share/wallpapers/solid/1920x1080-nordic.png
type=image
EOF

echo "👤 Setze individuelles Benutzer-Icon ..."
sudo rm -f /usr/share/sddm/faces/.face.icon
rsvg-convert -a -w 144 -f svg /usr/share/icons/Papirus/22x22@2x/apps/desktop-environment-kde.svg -o /tmp/face.svg
mv /tmp/face.svg ~/.face.icon
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon

echo "🔐 Setze Berechtigungen für SDDM auf Benutzericon ..."
setfacl -m u:sddm:x "$HOME"
setfacl -m u:sddm:r "$HOME/.face.icon"

echo "✅ Alles erledigt."

exit 0
