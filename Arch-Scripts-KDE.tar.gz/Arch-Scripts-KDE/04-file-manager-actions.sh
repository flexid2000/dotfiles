#!/bin/bash
paru -S perl-rename poppler graphicsmagick-imagemagick-compat pandoc-bin xclip mupdf-tools unoconv libnotify
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc" ]; then
	mkdir -p ~/.local/share/pandoc
fi
cp confiles/custom-reference.odt ~/.local/share/pandoc
exit 0
