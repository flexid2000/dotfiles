#!/bin/bash
sudo pacman -S --needed --noconfirm base-devel git accountsservice haveged reflector bat rsync openssl-1.1
sudo systemctl enable accounts-daemon.service
sudo systemctl enable haveged.service
git clone https://aur.archlinux.org/paru-bin
cd paru-bin
makepkg -si
cd ..
sudo rm -R paru-bin
sudo reflector --protocol http,https --country Germany --latest 5 --sort rate --save /etc/pacman.d/mirrorlist
sudo pacman -Syu
sudo sed -i 's/#ParallelDownloads/ParallelDownloads/' /etc/pacman.conf
sudo sed -i 's/MAKEFLAGS="-j1"/MAKEFLAGS="-j$(nproc)"/' /etc/makepkg.conf
sudo sed -i 's/#BottomUp/BottomUp/' /etc/paru.conf
exit 0
