#!/bin/bash
for f in "$@"; do
	pandoc --reference-doc=$HOME/.local/share/pandoc/custom-reference.odt --lua-filter=pagebreak.lua -o "${f%.*}".odt "$f"
done
exit 0

