#!/bin/bash
sudo apt -y install git qt5-style-kvantum faba-icon-theme moka-icon-theme papirus-icon-theme arc-theme
mkdir -p dracula-tmp
cd dracula-tmp
git clone https://github.com/dracula/gtk.git
mv gtk Dracula
sudo mkdir -p /usr/share/Kvantum
sudo cp -r Dracula/kde/kvantum/* /usr/share/Kvantum/
sudo cp -r Dracula /usr/share/themes
sudo rm -R Dracula
git clone https://github.com/matheuuus/dracula-icons.git
mv dracula-icons Dracula
sed -i 's/Inherits=/Inherits=Faba,Moka,Papirus/g' Dracula/index.theme
sudo cp -r Dracula /usr/share/icons/
git clone https://github.com/dracula/wallpaper.git
mv wallpaper ~/Bilder/Dracula
homedir=$HOME
sudo cp ~/Downloads/Debian-Scripts-LXQt-BBY/confiles/Dracula.colorscheme /usr/share/qtermwidget5/color-schemes/
git clone https://github.com/the-zero885/dracula-Openbox.git
mkdir -p ~/.local/share/themes
mv dracula-Openbox/Dracula dracula-Openbox/Dracula-withoutBorder ~/.local/share/themes
mkdir -p ~/.config/libreoffice/4/user/config
git clone https://github.com/dracula/libreoffice.git
cp libreoffice/dracula.soc ~/.config/libreoffice/4/user/config/
cd ..
sudo rm -R dracula-tmp
exit 0




