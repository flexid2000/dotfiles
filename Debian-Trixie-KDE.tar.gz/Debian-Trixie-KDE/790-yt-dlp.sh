#!/bin/bash
set -e
sudo wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux -O /usr/local/bin/yt-dlp
sudo chmod +x /usr/local/bin/yt-dlp
exit 0

