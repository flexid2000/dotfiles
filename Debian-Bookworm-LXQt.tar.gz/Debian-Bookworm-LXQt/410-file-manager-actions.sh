#!/bin/bash
sudo apt-fast -y install rename poppler-utils graphicsmagick-imagemagick-compat pandoc xclip poppler-utils mupdf-tools unoconv libnotify-bin img2pdf
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/pandoc" ]; then
	mkdir -p ~/.local/share/pandoc
fi
cp confiles/custom-reference.odt ~/.local/share/pandoc
cp file-manager-actions/*.sh file-manager-actions/*.py file-manager-actions/*.css ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
exit 0
