#!/bin/bash
sudo apt-fast -y install zram-tools
sudo sed -i 's/#PERCENT=50/PERCENT=50/g' /etc/default/zramswap
exit 0
