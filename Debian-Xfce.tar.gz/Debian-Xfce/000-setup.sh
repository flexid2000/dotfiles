#!/bin/bash
set -e

SCRIPTS=(
  "010-base-system.sh"
  "020-zram.sh"
  "030-pipewire.sh"
  "110-grub-autologin-sddm.sh"
  "200-nextcloud.sh"
  "300-programs-core.sh"
  "400-confiles.sh"
  "405-custom-actions.sh"
  "410-dotfiles.sh"
  "430-autostart.sh"
  "520-recoll.sh"
  "540-plymouth.sh"
  "610-xfce-wallpapers.sh"
)

for script in "${SCRIPTS[@]}"; do
  echo "🔧 Starte $script ..."
  bash "./$script"
done

sudo bash 330-sudo-switch-to-iwd.sh

echo "✅ System vollständig eingerichtet."

