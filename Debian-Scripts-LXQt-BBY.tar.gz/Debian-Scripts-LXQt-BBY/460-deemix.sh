#!/bin/bash
myuser=$(id -nu 1000)
homedir=$HOME
if [ ! -d "${homedir}/.local/bin" ]; then
  mkdir ${homedir}/.local/bin
fi
cd ~/.local/bin
wget https://www.dropbox.com/s/odn4tnu9cqlmq8h/deemix-linux-x64.AppImage?dl=0
mv deemix-linux-x64.AppImage?dl=0 deemix.AppImage
chmod 755 deemix.AppImage
sudo ln -s /home/${myuser}/.local/bin/deemix.AppImage /usr/local/bin/deemix
cd ~/Downloads/Debian-Scripts-LXQt-BBY
cp confiles/deemix.desktop ~/.local/share/applications
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
exit 0

