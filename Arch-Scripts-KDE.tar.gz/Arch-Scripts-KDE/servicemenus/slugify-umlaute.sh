#!/bin/bash

# Sicherstellen, dass rename installiert ist
if ! command -v perl-rename &>/dev/null; then
    echo "Fehler: 'perl-rename' ist nicht installiert. Bitte installieren Sie es mit 'sudo pacman -S perl-rename'."
    exit 1
fi

# Funktion zur Slugifizierung eines Dateinamens
slugify() {
    local file="$1"

    # Überprüfen, ob die Datei existiert
    if [[ ! -e "$file" ]]; then
        echo "Fehler: Datei '$file' existiert nicht." >&2
        return 1
    fi

    # Slugify den Dateinamen
    perl-rename -n      's/Ä|ä/ae/g;
                    s/Ö|ö/oe/g;
                    s/Ü|ü/ue/g;
                    s/ß/ss/g;
                    s/[éèê]/e/g;
                    y/A-Z/a-z/;
                    s/[^a-z0-9_. -]//g;
                    s/\s+/-/g;
                    s/_/-/g;
                    s/-+/-/g' "$file"

    # Tatsächliche Umbenennung durchführen
    perl-rename      's/Ä|ä/ae/g;
                 s/Ö|ö/oe/g;
                 s/Ü|ü/ue/g;
                 s/ß/ss/g;
                 s/[éèê]/e/g;
                 y/A-Z/a-z/;
                 s/[^a-z0-9_. -]//g;
                 s/\s+/-/g;
                 s/_/-/g;
                 s/-+/-/g' "$file"
}

# Alle übergebenen Dateien verarbeiten
for file in "$@"; do
    slugify "$file"
done

exit $?



