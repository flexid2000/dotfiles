#!/bin/bash
# Set Default Stop Time to 20 sec
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
exit 0

