#!/bin/bash
set -e

echo "📦 Installiere zentrale Desktop-Programme ..."
sudo apt-get update
sudo apt-get install -y \
accountsservice acpid alsa-firmware-loaders antiword arc-theme arj \
aspell-de audacious bleachbit bluedevil bluetooth bluez-cups \
bluez-obexd \
bluez-tools breeze-cursor-theme cabextract catdoc chromium \
chromium-l10n \
cmark conky-std cups \
cups-browsed cups-client cups-common cups-core-drivers cups-filters \
cups-filters-core-drivers cups-ipp-utils cups-pk-helper cups-ppdc \
cups-server-common curl discount dkms dolphin-nextcloud \
dolphin-plugins \
faad ffmpeg ffmpegthumbnailer ffmpegthumbs firefox-esr-l10n-de \
flac flvstreamer fonts-cantarell fonts-croscore fonts-firacode \
fonts-inconsolata fonts-inter fonts-open-sans fonts-roboto fsearch \
galternatives gimp git ghostwriter grsync gvfs gvfs-backends haveged \
htop hunspell hunspell-de-de hwinfo hyphen-de ibus ibus-gtk4 ibus-m17n \
icoextract-thumbnailer img2pdf info inkscape kcharselect \
kcolorchooser kdegraphics-thumbnailers kget kgpg kruler ktorrent lame \
libcanberra-pulse libchm-bin libgpod-dev libgsf-bin \
libimage-exiftool-perl \
libimobiledevice-dev libnotify-bin libqt5gui5t64 librdf-icalendar-perl \
libreoffice libreoffice-help-de libreoffice-l10n-de librsvg2-bin \
libwpd-tools markdownpart menu-xdg mjpegtools mpv mtp-tools \
mupdf-tools \
mythes-de netselect-apt nextcloud-desktop numlockx ooo-thumbnailer \
papirus-icon-theme pavucontrol-qt pdfarranger \
phonon4qt5-backend-gstreamer \
pipewire-audio plasma-browser-integration plasma-sdk \
plasma-workspace-wallpapers plocate plymouth plymouth-themes \
poppler-utils pwgen python3 python3-chardet python3-pip \
python3-pyinotify recoll rename sddm-theme-debian-breeze \
skanpage smplayer spice-client-gtk spice-vdagent strawberry svgpart \
subversion synaptic systemd-zram-generator tar task-german-desktop \
task-laptop thunderbird thunderbird-l10n-de ttf-bitstream-vera \
ttf-mscorefonts-installer tumbler tumbler-plugins-extra twolame unace \
unclutter unrar unrtf untex unzip vim vlc vorbis-tools wavpack \
weasyprint webext-allow-html-temp \
webext-privacy-badger \
webext-ublock-origin-firefox webext-ublock-origin-chromium \
webext-vimium-chromium webext-vimium-firefox \
wv wx-common xbindkeys xdg-desktop-portal-kde \
xsettingsd xsltproc zip

echo "✅ Desktop-Basispakete installiert."

