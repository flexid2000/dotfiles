#!/usr/bin/env bash
# ==============================================================================
# install-systemd-boot-debian.sh
# Migration von GRUB auf systemd-boot unter Debian Trixie
# Muss als root ausgeführt werden.
# ==============================================================================

set -euo pipefail

# ------------------------------------------------------------------------------
# Farben und Hilfsfunktionen
# ------------------------------------------------------------------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
RESET='\033[0m'

info()    { echo -e "${BLUE}[INFO]${RESET}  $*"; }
ok()      { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
error()   { echo -e "${RED}[FEHLER]${RESET} $*" >&2; }
heading() { echo -e "\n${BOLD}=== $* ===${RESET}"; }
fail()    { error "$*"; exit 1; }

# ------------------------------------------------------------------------------
# Root-Prüfung
# ------------------------------------------------------------------------------
if [[ $EUID -ne 0 ]]; then
    fail "Dieses Skript muss als root ausgeführt werden (sudo -i)."
fi

# ------------------------------------------------------------------------------
# Schritt 0: Voraussetzungen prüfen
# ------------------------------------------------------------------------------
heading "Schritt 0: Voraussetzungen prüfen"

# UEFI-Modus?
if [[ ! -d /sys/firmware/efi ]]; then
    fail "System läuft nicht im UEFI-Modus. systemd-boot ist nicht möglich."
fi
ok "UEFI-Modus erkannt."

# ESP vorhanden und eingehängt?
ESP_MOUNT=$(findmnt -n -o TARGET --target /boot/efi 2>/dev/null || true)
if [[ -z "$ESP_MOUNT" ]]; then
    fail "Keine ESP unter /boot/efi eingehängt. Bitte zuerst mounten und /etc/fstab anpassen."
fi
ok "ESP eingehängt unter: $ESP_MOUNT"

# ESP-Partitionstyp prüfen (muss EF00 sein, nicht EF02)
ESP_DEV=$(findmnt -n -o SOURCE /boot/efi)
ESP_PARTTYPE=$(blkid -o value -s PART_ENTRY_TYPE "$ESP_DEV" 2>/dev/null || true)
if [[ "$ESP_PARTTYPE" == "21686148-6449-6e6f-744e-656564454649" ]]; then
    fail "ESP-Partition $ESP_DEV hat den Typ EF02 (BIOS Boot), nicht EF00. \
System wurde im BIOS/Legacy-Modus installiert – Migration nicht möglich."
fi
ok "ESP-Partitionstyp korrekt ($ESP_DEV)."

# ------------------------------------------------------------------------------
# Schritt 1: GRUB-Variablen und Root-UUID einlesen
# ------------------------------------------------------------------------------
heading "Schritt 1: Konfiguration einlesen"

if [[ ! -f /etc/default/grub ]]; then
    fail "/etc/default/grub nicht gefunden."
fi

# shellcheck source=/dev/null
. /etc/default/grub
ok "GRUB-Konfiguration eingelesen."

ROOT_UUID=$(findmnt / -o UUID --noheadings | tr -d ' ')
if [[ -z "$ROOT_UUID" ]]; then
    fail "Root-UUID konnte nicht ermittelt werden."
fi
info "Root-UUID: $ROOT_UUID"

CMDLINE="root=UUID=${ROOT_UUID} ${GRUB_CMDLINE_LINUX} ${GRUB_CMDLINE_LINUX_DEFAULT}"
# Doppelte Leerzeichen bereinigen
CMDLINE=$(echo "$CMDLINE" | tr -s ' ')
info "Kernel-Kommandozeile: $CMDLINE"

# ------------------------------------------------------------------------------
# Schritt 2: /etc/kernel/cmdline schreiben
# ------------------------------------------------------------------------------
heading "Schritt 2: /etc/kernel/cmdline schreiben"

mkdir -p /etc/kernel
echo "$CMDLINE" > /etc/kernel/cmdline
ok "Geschrieben: /etc/kernel/cmdline"
info "Inhalt: $(cat /etc/kernel/cmdline)"

# ------------------------------------------------------------------------------
# Schritt 3: systemd-boot installieren
# ------------------------------------------------------------------------------
heading "Schritt 3: systemd-boot installieren"

apt-get install -y systemd-boot
ok "systemd-boot installiert."

# loader.conf prüfen / anlegen
LOADER_CONF="/boot/efi/loader/loader.conf"
if [[ ! -f "$LOADER_CONF" ]]; then
    warn "loader.conf nicht gefunden – wird angelegt."
    mkdir -p /boot/efi/loader
    touch "$LOADER_CONF"
fi

# ------------------------------------------------------------------------------
# Schritt 4: Timeout konfigurieren
# ------------------------------------------------------------------------------
heading "Schritt 4: Boot-Menü-Timeout konfigurieren"

if grep -q '^timeout' "$LOADER_CONF"; then
    sed -i 's/^timeout.*/timeout 4/' "$LOADER_CONF"
    ok "Timeout in loader.conf aktualisiert."
else
    echo "timeout 4" >> "$LOADER_CONF"
    ok "Timeout in loader.conf eingetragen."
fi
info "Inhalt von loader.conf:"
cat "$LOADER_CONF" | sed 's/^/    /'

# ------------------------------------------------------------------------------
# Schritt 5: GRUB-Fallback-Eintrag anlegen
# ------------------------------------------------------------------------------
heading "Schritt 5: GRUB-Fallback-Eintrag anlegen"

ENTRIES_DIR="/boot/efi/loader/entries"
mkdir -p "$ENTRIES_DIR"

GRUB_EFI="/boot/efi/EFI/debian/grubx64.efi"
if [[ -f "$GRUB_EFI" ]]; then
    printf 'title Grub\nefi /EFI/debian/grubx64.efi\n' > "${ENTRIES_DIR}/grub.conf"
    ok "GRUB-Fallback-Eintrag angelegt: ${ENTRIES_DIR}/grub.conf"
else
    warn "GRUB-EFI-Datei nicht gefunden ($GRUB_EFI) – kein Fallback-Eintrag angelegt."
fi

# ------------------------------------------------------------------------------
# Schritt 6: efibootmgr installieren und alten Ubuntu-Eintrag entfernen
# ------------------------------------------------------------------------------
heading "Schritt 6: EFI-Bootreihenfolge bereinigen"

apt-get install -y efibootmgr
ok "efibootmgr installiert."

# Alle aktiven Boot-Einträge auflisten
info "Aktuelle EFI-Booteinträge:"
efibootmgr -v | grep -E '^Boot[0-9A-F]{4}' | sed 's/^/    /'

# Debian/GRUB-Eintrag (Shim) finden und entfernen
UBUNTU_ENTRIES=$(efibootmgr | grep -i 'debian\|shim' | grep -oP 'Boot\K[0-9A-F]{4}' || true)
if [[ -n "$UBUNTU_ENTRIES" ]]; then
    for ENTRY in $UBUNTU_ENTRIES; do
        info "Entferne EFI-Eintrag: Boot${ENTRY} (Debian/Shim)"
        efibootmgr -b "$ENTRY" -B
        ok "Eintrag Boot${ENTRY} entfernt."
    done
else
    warn "Kein Debian/Shim-Eintrag gefunden – nichts zu entfernen."
fi

# ------------------------------------------------------------------------------
# Schritt 7: Abschlusskontrolle
# ------------------------------------------------------------------------------
heading "Schritt 7: Abschlusskontrolle"

FEHLER=0

check() {
    local beschreibung="$1"
    local ergebnis="$2"   # "ok" oder "fehler"
    local detail="$3"
    if [[ "$ergebnis" == "ok" ]]; then
        ok "$beschreibung"
        [[ -n "$detail" ]] && echo "         $detail"
    else
        error "$beschreibung"
        [[ -n "$detail" ]] && echo "         $detail"
        FEHLER=$(( FEHLER + 1 ))
    fi
}

# /etc/kernel/cmdline
if [[ -s /etc/kernel/cmdline ]]; then
    check "/etc/kernel/cmdline vorhanden" "ok" "$(cat /etc/kernel/cmdline)"
else
    check "/etc/kernel/cmdline vorhanden" "fehler" "Datei fehlt oder ist leer."
fi

# loader.conf
if [[ -f "$LOADER_CONF" ]]; then
    check "loader.conf vorhanden" "ok" "$(cat $LOADER_CONF | tr '\n' ' ')"
else
    check "loader.conf vorhanden" "fehler" ""
fi

# Timeout in loader.conf
if grep -q '^timeout' "$LOADER_CONF" 2>/dev/null; then
    check "Timeout konfiguriert" "ok" "$(grep '^timeout' $LOADER_CONF)"
else
    check "Timeout konfiguriert" "fehler" "Kein timeout-Eintrag in loader.conf."
fi

# Boot-Einträge unter /boot/efi/loader/entries/
ENTRY_COUNT=$(ls "${ENTRIES_DIR}"/*.conf 2>/dev/null | wc -l)
if [[ "$ENTRY_COUNT" -gt 0 ]]; then
    check "Boot-Einträge vorhanden ($ENTRY_COUNT)" "ok" "$(ls ${ENTRIES_DIR}/*.conf | xargs -I{} basename {})"
else
    check "Boot-Einträge vorhanden" "fehler" "Keine .conf-Dateien in ${ENTRIES_DIR}."
fi

# systemd-boot in der ESP
if [[ -f /boot/efi/EFI/systemd/systemd-bootx64.efi ]]; then
    check "systemd-bootx64.efi in ESP" "ok" ""
else
    check "systemd-bootx64.efi in ESP" "fehler" "Datei fehlt: /boot/efi/EFI/systemd/systemd-bootx64.efi"
fi

# Linux Boot Manager als EFI-Eintrag
if efibootmgr | grep -qi 'linux boot manager'; then
    LBM_ENTRY=$(efibootmgr | grep -i 'linux boot manager' | head -1)
    check "EFI-Eintrag 'Linux Boot Manager'" "ok" "$LBM_ENTRY"
else
    check "EFI-Eintrag 'Linux Boot Manager'" "fehler" "Nicht in efibootmgr gefunden."
fi

# Debian/Shim-Eintrag sollte weg sein
if efibootmgr | grep -qi 'debian\|shim'; then
    REMAINING=$(efibootmgr | grep -i 'debian\|shim')
    check "Alter Debian/Shim-EFI-Eintrag entfernt" "fehler" "Noch vorhanden: $REMAINING"
else
    check "Alter Debian/Shim-EFI-Eintrag entfernt" "ok" ""
fi

# Aktuelle Boot-Reihenfolge anzeigen
echo ""
info "Aktuelle EFI-Bootreihenfolge:"
efibootmgr | grep -E '^BootOrder|^Boot[0-9A-F]{4}' | sed 's/^/    /'

# ------------------------------------------------------------------------------
# Zusammenfassung
# ------------------------------------------------------------------------------
echo ""
if [[ "$FEHLER" -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}✓ Migration abgeschlossen – keine Fehler.${RESET}"
    echo -e "  Beim nächsten Neustart bootet Debian Trixie über systemd-boot."
else
    echo -e "${RED}${BOLD}✗ Migration abgeschlossen – ${FEHLER} Fehler aufgetreten.${RESET}"
    echo -e "  Bitte die markierten Punkte oben prüfen, bevor das System neu gestartet wird."
fi
echo ""
