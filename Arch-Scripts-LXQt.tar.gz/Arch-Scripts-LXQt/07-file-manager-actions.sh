#!/bin/bash
paru -S --needed xclip img2pdf
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
cp confiles/md-to-pdf.sh confiles/md2odt.sh confiles/multiply.sh confiles/stylesheet.css ~/.local/bin
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
paru -S --needed --noconfirm pandoc-bin
sudo pacman -S --needed --noconfirm dialog wkhtmltopdf texlive-core nodejs npm
sudo npm i -g md-to-pdf
exit 0
