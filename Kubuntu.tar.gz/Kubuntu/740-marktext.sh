#!/bin/bash
pkgver=0.17.1
wget https://github.com/marktext/marktext/releases/download/v${pkgver}/marktext-amd64.deb
sudo dpkg -i marktext-amd64.deb
sed -i 's/%U/%F/g' /usr/share/applications/marktext.desktop
rm marktext-amd64.deb
sudo apt-fast -y install npm
sudo npm install picgo -g
picgo upload /usr/share/xml/docbook/stylesheet/docbook-xsl/images/callouts/1.png
cp confiles/config.json ~/.picgo
firefox https://smms.app
exit 0

