#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
sudo pacman -U binaries/openbox-3.6.1-11-x86_64.pkg.tar.zst
paru -S xdotool redshift obconf-qt git xpad xclip picom caffeine-ng redshift-qt libayatana-appindicator meteo-qt obconf-qt xorg-xwininfo nextcloud-client gnome-keyring seahorse fuse2
wget wget https://raw.githubusercontent.com/nazeeruddinikram/bashshell/master/winfuncs.sh
sudo mv winfuncs.sh /usr/local/bin/winfuncs
sudo chmod 755 /usr/local/bin/winfuncs
exit 0
