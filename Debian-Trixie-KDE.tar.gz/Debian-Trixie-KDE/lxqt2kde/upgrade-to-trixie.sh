#!/bin/bash
set -euo pipefail

# Farbdefinitionen
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Protokollierung
LOG_FILE="/var/log/debian-upgrade-$(date +%Y%m%d).log"
exec > >(tee -a "$LOG_FILE") 2>&1
echo -e "${GREEN}=== Upgrade-Protokoll $(date) ===${NC}"

# Funktion zur Bestätigung
confirm() {
    read -p "${YELLOW}$1 (j/n)${NC} " -n 1 -r
    echo
    [[ $REPLY =~ ^[JjYy]$ ]] || exit 1
}

# 1. Systemvorbereitung (Bookworm)
echo -e "${GREEN}=== Phase 1: Vorbereitung (Bookworm) ===${NC}"

# Netzwerkcheck
ping -c 1 deb.debian.org || {
    echo -e "${RED}Netzwerkfehler!${NC}" >&2
    ip a >&2
    exit 1
}

# 1. Geschützte Paketliste (volle LXQt-Deinstallation ohne Netzwerkrisiko)
LXQT_PKGS_FULL=(
    feathernotes feathernotes-l10n featherpad featherpad-l10n libfmqt12 
    liblxqt-globalkeys-ui1 liblxqt-l10n liblxqt1 libxfce4ui-2-0 
    libxfce4ui-common libxfce4util-bin libxfce4util-common libxfce4util7 
    libxfconf-0-3 lilxqt-globalkeys1 lximage-qt lximage-qt-l10n lxqt 
    lxqt-about lxqt-about-l10n lxqt-admin lxqt-admin-l10n lxqt-branding-debian 
    lxqt-config lxqt-config-l10n lxqt-core lxqt-globalkeys lxqt-globalkeys-l10n 
    lxqt-l10n lxqt-notificationd lxqt-openssh-askpass lxqt-openssh-askpass-l10n 
    lxqt-panel lxqt-panel-l10n lxqt-policykit lxqt-policykit-l10n 
    lxqt-powermanagement lxqt-powermanagement-l10n lxqt-qtplugin lxqt-runner 
    lxqt-runner-l10n lxqt-session lxqt-sudo lxqt-sudo-l10n lxqt-system-theme 
    lxqt-theme-debian lxqt-themes meteo-qt meteo-qt-l10n pavucontrol-qt 
    pcmanfm-qt pcmanfm-qt-l10n qlipper qpdfview qpdfview-djvu-plugin 
    qpdfview-pdf-poppler-plugin qpdfview-ps-plugin qpdfview-translations qps 
    qterminal qterminal-l10n quassel quassel-data screengrab task-lxqt-desktop 
    xarchiver xfwm4 xfwm4-theme-breeze
)

# 2. Schutzliste für kritische Pakete
PROTECTED_PKGS=(
    sudo network-manager wpasupplicant net-tools 
    iproute2 dhcpcd5 ifupdown resolvconf
)

# 3. Sicherer Deinstallationsbefehl
safe_purge() {
    echo -e "${YELLOW}=== Schütze essentielle Pakete ===${NC}"
    sudo apt-mark manual "${PROTECTED_PKGS[@]}"
    
    echo -e "${YELLOW}=== Deinstalliere LXQt vollständig ===${NC}"
    sudo apt-get purge -y "${LXQT_PKGS_FULL[@]}"
    
    echo -e "${YELLOW}=== Bereinige Abhängigkeiten ===${NC}"
    sudo apt-get autoremove --purge -y
    
    echo -e "${YELLOW}=== Reset Schutzmarkierungen ===${NC}"
    sudo apt-mark auto "${PROTECTED_PKGS[@]}"
}

# Ausführung mit Bestätigung
confirm "VOLLSTÄNDIGE LXQt-Deinstallation durchführen (inkl. aller Abhängigkeiten)?"
safe_purge

# 2. Paketbereinigung (Bookworm)
echo -e "${GREEN}=== Phase 2: Paketbereinigung (Bookworm) ===${NC}"

# Nicht-Debian-Pakete
sudo apt-get update
non_debian=$(aptitude search '?narrow(?installed, ?not(?origin(Debian)))' -F "%p" | xargs)
[ -n "$non_debian" ] && sudo apt-get purge --assume-yes $non_debian

# 3. Upgrade auf Trixie
echo -e "${GREEN}=== Phase 3: Upgrade auf Trixie ===${NC}"

# Quellen umstellen
confirm "Paketquellen auf Trixie umstellen?"
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
sudo tee /etc/apt/sources.list <<EOF
deb https://deb.debian.org/debian trixie main contrib non-free
deb https://deb.debian.org/debian trixie-updates main contrib non-free
deb https://security.debian.org/debian-security trixie-security main
EOF

# Upgrade-Phasen
echo -e "${GREEN}>>> Schritt 1: Upgrade ohne neue Pakete${NC}"
sudo apt-get update
sudo apt-get upgrade --without-new-pkgs -y

echo -e "${GREEN}>>> Schritt 2: Vollständiges Upgrade${NC}"
sudo apt-get dist-upgrade -y

# 4. Post-Upgrade-Bereinigung (KRITISCH)
echo -e "${GREEN}=== Phase 4: Post-Upgrade-Bereinigung ===${NC}"

echo -e "${YELLOW}>>> Entferne obsolete Pakete (~o)${NC}"
sudo aptitude purge '~o' --assume-yes

echo -e "${YELLOW}>>> Bereinige Konfigurationsdateien (~c)${NC}"
sudo aptitude purge '~c' --assume-yes

# 5. KDE Installation (Trixie)
echo -e "${GREEN}=== Phase 5: KDE Installation ===${NC}"
confirm "KDE Plasma installieren?"
sudo tasksel install kde-desktop

# 6. Finale Bereinigung
echo -e "${GREEN}=== Phase 6: Finale Bereinigung ===${NC}"
sudo apt-get autoremove --purge -y
sudo apt-get clean

# 12. Netzwerk-Konfiguration für KDE Plasma
echo -e "${GREEN}=== Netzwerk-Konfiguration für KDE ===${NC}"

# 12a. NetworkManager.conf anpassen
echo -e "${YELLOW}>>> Aktiviere NetworkManager Management${NC}"
sudo sed -i '/^\[ifupdown\]$/,/^\[/ s/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf

# 12b. Alte interfaces-Konfiguration deaktivieren
echo -e "${YELLOW}>>> Deaktiviere legacy network-interfaces${NC}"
sudo cp /etc/network/interfaces /etc/network/interfaces.bak
sudo sed -i '/^allow-hotplug enp[0-9]s[0-9]/s/^/#/' /etc/network/interfaces
sudo sed -i '/^iface enp[0-9]s[0-9] inet dhcp/s/^/#/' /etc/network/interfaces

# 12c. Dienste neu starten
echo -e "${YELLOW}>>> Starte Netzwerkdienste neu${NC}"
sudo systemctl restart NetworkManager
sudo systemctl disable networking.service 2>/dev/null || true

echo -e "${GREEN}=== Netzwerk-Konfiguration abgeschlossen ===${NC}"

# Finale Meldung
echo -e "${GREEN}=== Upgrade vollständig abgeschlossen! ===${NC}"
echo -e "Bitte neu starten: ${YELLOW}sudo reboot${NC}"
echo -e "Protokoll: ${YELLOW}$LOG_FILE${NC}"
