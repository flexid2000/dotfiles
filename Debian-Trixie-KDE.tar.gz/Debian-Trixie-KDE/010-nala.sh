#"/bin/bash
sudo apt-get -y install curl git nala vim
sudo nala fetch
sudo nala update
sudo nala full-upgrade
exit 0

