#!/bin/bash
cp confiles/picom.conf ~/.config
if [ ! -d $HOME/.config/conky ]; then
  mkdir -p ~/.config/conky
fi
cp confiles/conky.conf ~/.config/conky
if [ ! -d $HOME/.config/openbox ]; then
  mkdir -p ~/.config/openbox
fi
cp confiles/rc.xml ~/.config/openbox/rc.xml
cp confiles/redshift.conf ~/.config
if [ ! -d $HOME/.config/yt-dlp ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if [ ! -d $HOME/.config/meteo-qt ]; then
  mkdir -p ~/.config/meteo-qt
fi
cp confiles/meteo-qt.conf ~/.config/meteo-qt/
if [ ! -d $HOME/.config/mpv ]; then
  mkdir -p ~/.config/mpv
fi
cp confiles/mpv.conf ~/.config/mpv
cp confiles/globalkeyshortcuts.conf ~/.config/lxqt
paru -S --needed --noconfirm openbox-arc-git sddm-sugar-candy-git ksuperkey lxqt-arc-dark-theme-git arc-kde
mkdir -p ~/Bilder/artwork
cp artwork/clipboard-dark.png ~/Bilder/artwork/
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
exit 0
