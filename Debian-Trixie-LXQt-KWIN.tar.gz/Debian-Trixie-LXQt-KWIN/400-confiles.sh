#!/bin/bash
wget https://deac-ams.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
cd confiles
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky* ~/.config/conky
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/angrysearch" ]; then
  mkdir -p ~/.config/angrysearch
fi
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
if [ ! -d "$HOME/.config/kde.org" ]; then
  mkdir -p ~/.config/kde.org
fi
if [ ! -d "$HOME/.config/feathernotes" ]; then
  mkdir -p ~/.config/feathernotes
fi
sudo cp redshift-qt /usr/local/bin
sudo cp pdf.thumbnailer /usr/share/thumbnailers
cp apt-updates.sh ~/.local/bin
cp globalkeyshortcuts.conf ~/.config/lxqt
cp redshift.conf ~/.config
cp slugify.sh ~/.local/bin
cp deemix.desktop ~/.local/share/applications
cp config ~/.config/yt-dlp
cp ghostwriter.conf ~/.config/kde.org
cp fn.conf ~/.config/feathernotes
cp .bash_aliases ~/
source ~/.bashrc
mkdir -p ~/.config/libreoffice/4/user/template
cp babylonia.ott ~/.config/libreoffice/4/user/template
cp angrysearch.conf ~/.config/angrysearch
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo apt-get -y install fonts-croscore
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
# ksuperkey
sudo apt-get -y install git gcc make libx11-dev libxtst-dev pkg-config
git clone https://github.com/hanschen/ksuperkey.git
cd ksuperkey
make
sudo make install
exit 0
