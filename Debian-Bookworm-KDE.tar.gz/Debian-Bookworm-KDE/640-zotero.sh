#!/bin/bash
curl -sL https://raw.githubusercontent.com/retorquere/zotero-deb/master/install.sh | sudo bash
sudo apt-fast update
sudo nala install zotero
exit 0
