#!/bin/bash
echo "gtk-decoration-layout=close,minimize,maximize:menu" >> $HOME/.config/gtk-3.0/settings.ini
exit 0

