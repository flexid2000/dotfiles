#!/bin/bash
set -e

SCRIPTS=(
  "010-base-system.sh"
  "020-zram.sh"
  "030-pipewire.sh"
  "110-grub-sddm.sh"
  "300-programs-core.sh"
  "310-tools.sh"
  "320-desktop.sh"
  "400-servicemenus.sh"
  "410-dotfiles.sh"
  "420-recoll.sh"
  "430-autostart.sh"
  "500-plymouth.sh"
  "510-touchpad.sh"
  "650-joplin.sh"
  "780-flatpak-normcap"
  "950-aufraeumen.sh"
)

for script in "${SCRIPTS[@]}"; do
  echo "🔧 Starte $script ..."
  bash "./$script"
done

sudo bash 330-sudo-switch-to-iwd.sh

echo "✅ System vollständig eingerichtet."

