## Anmerkungen

- Datum: 23.12.2024
- Debian 13 (Trixie)
- In den Repositories fehlen:
    - gimp
    - gimp-plugin-repository
    - speedcrunch
    - software-properties-gtk  
- `730-qemu-shared-folder` führt zu Bootversagen
- Kurzbefehle für `KWIN` funktionieren nicht
	- Lösung: `cp /etc/xdg/autostart/kglobalacceld.desktop ~/.config/autostart`
	- `OnlyShowIn=KDE` entfernen
- `kvantum-qt6` noch nicht vorhanden
- Alternative: `Qt-Stil`: `Fusion`  
	Thema: `Frost`

