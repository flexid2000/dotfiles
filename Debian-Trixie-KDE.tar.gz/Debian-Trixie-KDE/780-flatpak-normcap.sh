#!/bin/bash

set -e

sudo apt update
sudo apt -y install flatpak
flatpak --user remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo
flatpak --user install com.github.dynobo.normcap
exit 0
