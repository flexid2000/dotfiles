#!/bin/bash
#sh 100-sources-list.sh
sh 110-grub-autologin.sh
sh 120-autostart.sh
sh 300-binaries-install.sh
sh 400-confiles.sh
sh 410-file-manager-actions.sh
sh 420-meteo-qt-install.sh
sh 440-yt-dlp.sh
sh 460-deemix.sh
# 470-dracula-theme.sh
sh 471-dracula-qterminal.sh
sh 475-lxqt-arc-dark-light.sh
sh 480-move-buttons-left.sh
sh 500-programs-install.sh
sh 520-recoll.sh
# 530-lightweight-apps.sh
sh 540-plymouth.sh
#sh 550-swapfile.sh
sh 570-brave-browser.sh
sh 580-img2pdf.sh
sh 590-typora.sh
#sh 130-replace-connman-with-network-manager.sh
# 600-kernel-remover.sh
sh 610-courier-prime-fonts.sh
sh 620-marktext.sh
exit 0


