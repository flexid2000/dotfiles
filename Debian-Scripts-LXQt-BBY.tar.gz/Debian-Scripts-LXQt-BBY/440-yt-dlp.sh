#!/bin/bash
homedir=$HOME
if ! command -v curl &> /dev/null
then
    sudo apt -y install curl
fi
sudo apt install smplayer
if ! command -v /usr/bin/youtube-dl &> /dev/null
then
    sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
else
    sudo apt -y purge youtube-dl
    sudo apt -y autoremove --purge
    sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
fi
sudo chmod a+rx /usr/local/bin/yt-dlp
if [ ! -d "${homedir}/.config/yt-dlp" ]; then
  mkdir ${homedir}/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if ! command -v /usr/bin/python &> /dev/null
then
    sudo ln -s /usr/bin/python3 /usr/bin/python
fi
exit 0
