#!/bin/bash
set -e

echo "📦 Installiere Basis-Tools ..."

sudo apt-get update
sudo apt-get install -y \
    vim vim-gtk3 git curl wget apt-file ranger

echo "📦 Umstellung der Repos ..."

echo "deb http://mirror.ipb.de/debian/ forky main contrib non-free non-free-firmware" | sudo tee /etc/apt/sources.list
echo "deb http://mirror.ipb.de/debian/ forky-updates main contrib non-free non-free-firmware" | sudo tee -a /etc/apt/sources.list
echo "deb http://mirror.ipb.de/debian/ forky-backports main" | sudo tee -a /etc/apt/sources.list
echo "deb http://deb.debian.org/debian-security forky-security main" | sudo tee -a /etc/apt/sources.list
sudo apt modernize-sources

echo "🔐 Ergänze fehlende Signed-By-Zeilen in .sources-Dateien ..."

for file in /etc/apt/sources.list.d/*.sources; do
  if grep -q '^Signed-By: *$' "$file"; then
    echo "🛠️  Ergänze Signed-By in $file ..."
    sudo sed -i "s|^Signed-By: *$|Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg|" "$file"
  fi
done

echo "✅ Signed-By-Felder ergänzt."

sudo apt update
sudo apt-file update

echo "✅ Basis-System aktualisiert."

