#!/bin/bash
sudo apt-get -y install sddm-theme-breeze desktop-base librsvg2-bin imagemagick
sudo sed -i '/^ *WallpaperFader {/,/^ *}/d' /usr/share/sddm/themes/breeze/Main.qml
sudo sed -i 's/^Current=.*/Current=breeze/' /etc/sddm.conf
convert -size 16x9 xc:'#44475A' -density 72 sddm-background.png
sudo mv sddm-background.png /usr/share/sddm/themes/breeze
sudo printf '[General]\nbackground=sddm-background.png\ntype=image\n' > theme.conf.user
sudo mv theme.conf.user /usr/share/sddm/themes/breeze
sudo rm /usr/share/sddm/faces/.face.icon
rsvg-convert -a -w 144 -f svg /usr/share/icons/Papirus/22x22@2x/apps/distributor-logo-debian.svg -o /tmp/face.svg
mv /tmp/face.svg ~/.face
sudo ln -s ~/.face.icon /usr/share/sddm/faces/.face.icon
setfacl -m u:sddm:x ~/
setfacl -m u:sddm:r ~/.face.icon
exit 0
