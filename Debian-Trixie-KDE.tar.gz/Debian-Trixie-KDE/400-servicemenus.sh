#!/bin/bash
set -e

echo "📁 Installiere Service-Menüs & Pandoc ..."
sudo apt-get install -y rename poppler-utils pandoc xclip mupdf-tools libnotify-bin img2pdf xsel weasyprint
mkdir -p ~/.local/share/{file-manager/actions,kio/servicemenus,pandoc/filters} ~/.local/bin
cp confiles/custom-reference.odt ~/.local/share/pandoc
cp servicemenus/*.sh servicemenus/*.css ~/.local/bin
cp servicemenus/*.desktop ~/.local/share/kio/servicemenus
chmod 755 ~/.local/share/kio/servicemenus/*.desktop
cp confiles/pagebreak.lua ~/.local/share/pandoc/filters

echo "✅ Service-Menüs installiert."

