#!/bin/bash
sudo apt update
sudo nala install recoll aspell-de python3 xsltproc unzip poppler-utils antiword wv libwpd-tools catdoc libchm-bin info tar librdf-icalendar-perl unrtf untex dvi2ps libimage-exiftool-perl python3-chardet
mkdir ~/.recoll
cp confiles/mimeview ~/.recoll/
cp confiles/recoll.conf ~/.recoll/
sudo cp confiles/recoll-index /etc/cron.daily/
sudo chmod 755 /etc/cron.daily/recoll-index
exit 0
