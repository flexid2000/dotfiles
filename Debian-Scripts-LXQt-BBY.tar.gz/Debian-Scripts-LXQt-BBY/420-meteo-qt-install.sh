#!/bin/bash
#sudo apt -y purge meteo-qt meteo-qt-l10n
#sudo apt -y install python3-pyqt5 python3-sip python3-lxml pyqt5-dev-tools qttools5-dev-tools git pyqt5-dev-tools python3-distutils
#cd ~/Downloads
#git clone https://github.com/dglent/meteo-qt.git
#cd meteo-qt
#sudo python3 setup.py install
sudo apt -y install python3 python3-lxml python3-pyqt5 python3-sip
sudo dpkg -i binaries/meteo-qt_3.1-1_amd64.deb
if [ ! -d $HOME/.config/meteo-qt ]; then
  mkdir -p ~/.config/meteo-qt
fi
cp confiles/meteo-qt.conf ~/.config/meteo-qt/
#sudo rm -R ~/Downloads/meteo-qt
exit 0
