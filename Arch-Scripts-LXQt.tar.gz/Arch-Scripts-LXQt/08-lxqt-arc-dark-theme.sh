#!/bin/bash
cd ~/Downloads
git clone https://gitlab.com/isseigx/lxqt-arc-dark-theme.git
cd lxqt-arc-dark-theme/arc-dark
#sed -i 's/rgb(82, 148, 226)/rgb(189, 147, 249)/g ; s/rgb(80, 140, 212)/rgb(189, 147, 249)/g ; s/#5294e2/#BD93F9/g' lxqt-panel.qss
sudo cp -r ~/Downloads/lxqt-arc-dark-theme/arc-dark /usr/share/lxqt/themes/
sudo rm -R ~/Downloads/lxqt-arc-dark-theme
wget -qO- https://raw.githubusercontent.com/PapirusDevelopmentTeam/arc-kde/master/install.sh | sh
exit 0

