#!/bin/bash
#
# für Debian Bullseye
#
echo "deb http://pubmirror.plutex.de/debian/ bullseye main contrib non-free" > /tmp/sources.list
echo "deb http://deb.debian.org/debian-security bullseye-security main contrib non-free" >> /tmp/sources.list
echo "deb http://pubmirror.plutex.de/debian/ bullseye-backports main contrib non-free" >> /tmp/sources.list
echo "deb http://pubmirror.plutex.de/debian/ bullseye-updates main contrib non-free" >> /tmp/sources.list
sudo cp /tmp/sources.list /etc/apt
sudo apt-fast update
sudo apt-fast -y install isenkram-cli
sudo isenkram-autoinstall-firmware
exit 0
