#!/bin/bash
sudo apt-get install systemd-zram-generator pipewire-audio
sudo apt -y purge pulseaudio-module-bluetooth pulseaudio ofono
systemctl --user --now enable wireplumber.service
exit 0
