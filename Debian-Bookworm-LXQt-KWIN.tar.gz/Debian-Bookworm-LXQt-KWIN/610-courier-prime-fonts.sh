#!/bin/bash
sudo apt-fast -y install unzip
wget https://quoteunquoteapps.com/courierprime/downloads/courier-prime.zip
wget https://quoteunquoteapps.com/courierprime/downloads/courier-prime-sans.zip
unzip courier-prime.zip
unzip courier-prime-sans.zip
sudo cp -r Courier\ Prime/ /usr/share/fonts/truetype
sudo mkdir -p /usr/share/fonts/truetype/Courier\ Prime\ Sans
sudo cp -r CourierPrimeSans-master/ttf/*.ttf /usr/share/fonts/truetype/Courier\ Prime\ Sans/
rm -r __MACOSX Courier\ Prime CourierPrimeSans-master courier-prime.zip courier-prime-sans.zip
sudo fc-cache -frv
exit 0





