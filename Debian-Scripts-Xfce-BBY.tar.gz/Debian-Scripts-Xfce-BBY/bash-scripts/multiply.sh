#!/bin/bash
name=`echo "$1" | cut -d'.' -f1`
echo "$name"
mkdir "$name"
cp "$1" "$name"
cd "$name"
for num in {01..13}; do cp "$1" $num."$1"; done
rm "$1"
cd ..
rm "$1"
exit 0


