#!/bin/bash
set -e

echo "📦 Installiere SPICE-Gästeintegration ..."
sudo pacman -S spice-vdagent xf86-video-qxl spice-gtk --needed

echo "📁 Erstelle lokalen shared-Ordner ..."
mkdir -p "$HOME/shared"

echo "🔧 Füge 9p-Mountpoint zu /etc/fstab hinzu ..."
if ! grep -q "/sharepoint" /etc/fstab; then
    # FESTE PROBLEMSTELLE: echo -e durch printf ersetzen!
    printf '/sharepoint\t%s/shared\t9p\ttrans=virtio,version=9p2000.L,rw\t0\t0\n' "$HOME" | sudo tee -a /etc/fstab > /dev/null
    # sed-Kommando vereinfachen
    sudo sed -i -e '$a\' /etc/fstab  # Newline am Ende sicherstellen
fi

echo "✅ Fertig."
