#!/bin/bash
sudo apt-get -y install python3-anyio python3-h11 python3-httpcore python3-httpx python3-sniffio python3-tomli python3-typer
wget https://gitlab.com/volian/nala/uploads/e230845dd7df230898bd96cacec15978/nala_0.15.2_all.deb
sudo dpkg -i nala_0.15.2_all.deb
rm nala_0.15.2_all.deb
sudo nala fetch
sudo nala update
sudo nala upgrade
exit 0
