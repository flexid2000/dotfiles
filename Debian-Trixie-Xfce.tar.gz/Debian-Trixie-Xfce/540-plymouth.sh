#!/bin/bash
set -e

sudo apt-get -y install plymouth plymouth-themes plymouth-x11
sudo plymouth-set-default-theme -R spinner

exit 0
