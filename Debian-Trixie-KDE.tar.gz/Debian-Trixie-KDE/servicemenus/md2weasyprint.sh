#!/bin/bash

CSS="$HOME/.local/bin/weasyprint.css"

for FILE in "$@"; do
    OUTPUT="${FILE%.md}.pdf"
    echo "Konvertiere $FILE → $OUTPUT"

    # 1. Markdown → HTML mit Pandoc
    TEMP_HTML=$(mktemp).html
    pandoc "$FILE" \
        --from markdown+emoji \
        --to html5 \
        --standalone \
        --css "$CSS" \
        -V lang=de \
        -V graphics=yes \
        -V include-before-body='<style>img { max-width: 100% }</style>' \
        -V mainfont="Inter Medium" \
        -V papersize=A4 \
        -V margin-left=1.5cm \
        -V margin-right=1.5cm \
        -V margin-top=2cm \
        -V margin-bottom=2cm \
        --metadata pagetitle="${FILE%.*}" \
        --metadata lang="de" \
        -o "$TEMP_HTML"

    # 2. HTML → PDF mit WeasyPrint
    weasyprint "$TEMP_HTML" "$OUTPUT" 2>&1 | grep -v "WARNING"

    # Aufräumen
    rm "$TEMP_HTML"
done
