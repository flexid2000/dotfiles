#!/bin/bash
paru -S --needed xclip img2pdf
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
cp file-manager-actions/*.desktop ~/.local/share/file-manager/actions
cp bash-scripts/*.sh ~/.local/bin
exit 0
