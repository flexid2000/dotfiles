#!/bin/bash
wget https://github.com/darktrojan/openwith/blob/master/webextension/native/open_with_linux.py
chmod u+x open_with_linux.py
mv open_with_linux.py ~/.local/bin
sh ~/.local/bin/open_with_linux.py install
cp file-manager-actions/play-yt-dlp.sh ~/.local/bin
echo "Firefox-Addon Open-With installieren und konfigurieren"
echo "Aufruf: /home/kay/.local/bin/play-yt-dlp.sh %s"
exit 0
