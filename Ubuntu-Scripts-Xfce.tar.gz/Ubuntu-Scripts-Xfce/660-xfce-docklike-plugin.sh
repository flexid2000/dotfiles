#!/bin/bash
sudo apt-fast -y install xfce4-dev-tools libwnck-3-dev libxfce4ui-2-dev libxfce4panel-2.0-dev
git clone https://gitlab.xfce.org/panel-plugins/xfce4-docklike-plugin.git
cd xfce4-docklike-plugin
./autogen.sh
make
sudo make install
exit 0
