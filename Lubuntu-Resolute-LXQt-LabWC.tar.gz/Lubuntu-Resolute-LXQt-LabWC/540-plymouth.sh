#!/bin/bash
sudo apt-get -y install plymouth plymouth-themes
sudo sed -i 's/BackgroundStartColor=0x000000/BackgroundStartColor=0x000000/' /usr/share/plymouth/themes/spinner/spinner.plymouth
sudo sed -i 's/BackgroundEndColor=0x000000/BackgroundEndColor=0x000000/' /usr/share/plymouth/themes/spinner/spinner.plymouth
sudo sed -i 's/"quiet"/"quiet splash"/g' /etc/default/grub
sudo sed -i 's/#GRUB_GFXMODE=1920x1080/GRUB_GFXMODE=auto\nGRUB_GFXPAYLOAD_LINUX=keep/' /etc/default/grub
convert -size 1920x1080 xc:'#000000' -density 96 background.png
sudo mv background.png /usr/share/plymouth/themes/spinner/background.png
sudo update-grub
 sudo update-alternatives --set default.plymouth /usr/share/plymouth/themes/spinner/spinner.plymouth
sudo update-initramfs -u
exit 0
