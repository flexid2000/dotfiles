#!/bin/bash

set -e

echo "📦 Überflüssige Pakte entfernen"

sudo apt-get -y --auto-remove purge \
akonadi-server akregator dragonplayer juk kaccounts-providers \
kaddressbook kdeconnect kdepim-runtime kdepim-themeeditors kget kgpg \
kmag kmail kmousetool kmouth konqueror kontrast im-config
sudo apt-get -y autoremove --purge
sudo apt-get clean

echo "✅ Überflüssige Pakete entfernt"

echo 0

