#!/bin/bash
if [ ! -d $HOME/.config/conky ]; then
  mkdir -p ~/.config/conky
fi
cp confiles/conky.conf ~/.config/conky
if [ ! -d $HOME/.config/yt-dlp ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
if [ ! -d $HOME/.config/mpv ]; then
  mkdir -p ~/.config/mpv
fi
cp confiles/mpv.conf ~/.config/mpv
if [ ! -d $HOME/.recoll ]; then
  mkdir -p ~/.recoll
fi
cp confiles/mimeview confiles/recoll.conf ~/.recoll/
sudo pacman -S --needed --noconfirm cronie
sudo cp confiles/recoll-index /etc/cron.daily/
sudo chmod 755 /etc/cron.daily/recoll-index
paru -S  qt6-svg fcitx5 fcitx5-configtool fcitx5-gtk fcitx5-qt
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
cp confiles/dolphinrc confiles/katerc confiles/konsolerc confiles/okularpartrc ~/.config
cp confiles/.hidden ~/
echo "konsole neu starten"
exit 0
