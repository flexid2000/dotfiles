#!/bin/bash
sudo apt -y install git qt5-style-kvantum papirus-icon-theme arc-theme
mkdir -p dracula-tmp
cd dracula-tmp
sudo cp ../confiles/Dracula.colorscheme /usr/share/qtermwidget5/color-schemes/
mkdir -p ~/.config/libreoffice/4/user/config
git clone https://github.com/dracula/libreoffice.git
cp libreoffice/dracula.soc ~/.config/libreoffice/4/user/config/
cd ..
sudo rm -R dracula-tmp
exit 0




