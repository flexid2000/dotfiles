#!/bin/bash
sudo apt-fast -y install rename
if [ ! -d "$HOME/.local/share/file-manager/actions" ]; then
  mkdir -p ~/.local/share/file-manager/actions
fi
cp file-manager-actions/* ~/.local/share/file-manager/actions
sudo apt-fast -y install xclip
if [ ! -d "$HOME/.local/bin" ]; then
	mkdir -p ~/.local/bin
fi
cp confiles/multiply.sh ~/.local/bin
cp file-manager-actions/file-manager-actions.desktop ~/Vorlagen
exit 0
