#!/bin/bash

set -e

# Grundlegende Programme installieren
sudo pacman -Syu
sudo pacman -S --needed base-devel linux-headers curl wget git accountsservice haveged reflector bat rsync openssl-1.1
sudo systemctl enable accounts-daemon.service
sudo systemctl enable haveged.service

# Chaotic AUR hinzufügen
sudo pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com
sudo pacman-key --lsign-key 3056513887B78AEB
sudo pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst'
sudo pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst'
cp /etc/pacman.conf /tmp/pacman.conf
echo -e '[chaotic-aur]\nInclude = /etc/pacman.d/chaotic-mirrorlist' >> /tmp/pacman.conf
sudo cp /tmp/pacman.conf /etc/pacman.conf
sudo pacman -Syu

# paru installieren
sudo pacman -S paru
sudo sed -i 's/^\#BottomUp/BottomUp/' /etc/paru.conf

# Mirrorlist anpassen
sudo reflector --protocol http,https --country Germany --latest 5 --sort rate --save /etc/pacman.d/mirrorlist
sudo pacman -Syu

# Anpassung von Systemdateien
sudo sed -i 's/#ParallelDownloads/ParallelDownloads/' /etc/pacman.conf
sudo sed -i 's/MAKEFLAGS="-j1"/MAKEFLAGS="-j$(nproc)"/' /etc/makepkg.conf
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sudo sed -i 's/^timeout.*/timeout=0/' /boot/loader/loader.conf

# ~/.local/bin in $PATH
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
source $HOME/.bashrc

# Kernel-Firmware
paru -S mkinitcpio-firmware

exit 0
