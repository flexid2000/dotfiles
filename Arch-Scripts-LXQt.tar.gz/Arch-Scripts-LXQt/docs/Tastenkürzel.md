# Tastenkürzel
| Tastenkombination      | Funktion                          |
| ---------------------- | --------------------------------- |
| Alt + Leertaste		 | App Starter						 |
| Alt + F11              | Fenster in Vollbild               |
| Windows + links        | Fenster nach links kacheln        |
| Windows + Alt + hoch   | Fenster nach links oben kacheln   |
| Windows + Alt + links  | Fenster nach links unten kacheln  |
| Windows + hoch         | Fenster nach oben kacheln         |
| Windows + rechts       | Fenster nach rechts kacheln       |
| Windows + Alt + Rechts | Fenster nach rechts oben kacheln  |
| Windows + Alt + runter | Fenster nach rechts unten kacheln |
| Windows + runter       | Fenster nach unten kacheln        |
| Alt + F4               | Fenster schließen                 |
| Alt + F10              | Fenster vergrößern                |
| Windows + F            | File Manager                      |
| Windows + L            | LibreOffice Writer                |
| Windows + X            | Logout                            |
| Windows + M            | Mailreader Thunderbird            |
| Windows                | Menu                              |
| Windows + D            | Schreibtisch anzeigen             |
| Windows + T            | Terminal                          |
| Windows + W            | Webbrowser Firefox                |
| Windows + ESC          | xkill                             |