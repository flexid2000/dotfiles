#!/bin/bash
sudo apt-get -y install kwin-x11 systemsettings
cd binaries
chmod 755 *
sudo apt-fast -y install xdotool redshift git xpad xclip gvfs-fuse libsecret-tools dbus-x11 gnome-keyring git
sudo cp redshift-qt winfuncs /usr/local/bin
exit 0
