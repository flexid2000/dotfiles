#!/bin/bash
sudo apt-fast -y install texlive-xetex
cp file-manager-actions/md2pdf.desktop menu-markdown.desktop ~/.local/share/file-manager/actions
cp file-manager-actions/md2pdf-xelatex.sh ~/.local/bin
exit 0

