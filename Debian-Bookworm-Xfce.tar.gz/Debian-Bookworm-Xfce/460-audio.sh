#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
sudo apt-fast -y install volumeicon-alsa
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
sudo apt -y -t bookworm-backports install yt-dlp
wget -qO- https://www.dropbox.com/scl/fi/yyrz4mydrlseepc2hi4d8/deemix-linux-x64.deb > deemix.deb
sudo dpkg -i deemix.deb
exit 0
