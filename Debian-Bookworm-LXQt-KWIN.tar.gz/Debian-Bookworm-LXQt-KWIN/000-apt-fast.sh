#!/bin/bash
sudo apt -y install curl vim
sudo /bin/bash -c "$(curl -sL https://git.io/vokNn)"
sudo apt-fast update
sudo apt-fast -y full-upgrade
exit 0
