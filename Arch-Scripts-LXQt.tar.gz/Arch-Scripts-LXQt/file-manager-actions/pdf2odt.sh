#!/bin/bash
mkdir -p tmp
pdftohtml "$1" tmp/"${1%.*}".html
for IMAGE in tmp/*.jpg; do
	mogrify -resize '643x945>' -density 96 -quality 90 -channel RGB $IMAGE
	# mogrify -resize '643x945>' -density 96 -quality 90 -channel RGB -negate $IMAGE
done
pandoc --reference-doc=$HOME/.local/share/pandoc/custom-reference.odt -o "${1%.*}".odt -f html -t odt tmp/"${1%.*}"s.html
rm -R tmp
exit 0
