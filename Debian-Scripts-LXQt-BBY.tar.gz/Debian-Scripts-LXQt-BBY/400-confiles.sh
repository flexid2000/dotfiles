#!/bin/bash
wget https://deac-ams.dl.sourceforge.net/project/aoo-extensions/374/17/pagination-1.3.10.oxt
cd confiles
cp picom.conf ~/.config
if [ ! -d "$HOME/.config/conky" ]; then
  mkdir -p ~/.config/conky
fi
cp conky* ~/.config/conky
if [ ! -d "$HOME/.config/openbox" ]; then
  mkdir -p ~/.config/openbox
fi
if [ ! -d "$HOME/.local/bin" ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d "$HOME/.local/share/applications" ]; then
  mkdir -p ~/.local/share/applications
fi
if [ ! -d "$HOME/.config/cmst" ]; then
  mkdir -p ~/.config/cmst
fi
if [ ! -d "$HOME/.config/angrysearch" ]; then
  mkdir -p ~/.config/angrysearch
fi
cp cmst.conf ~/.config/cmst
cp lxqt-rc.xml ~/.config/openbox
cp globalkeyshortcuts.conf ~/.config/lxqt
cp redshift.conf ~/.config
cp slugify.sh ~/.local/bin
cp deemix.desktop ~/.local/share/applications
cp .bash_aliases ~/
source ~/.bashrc
mkdir -p ~/.config/libreoffice/4/user/template
cp babylonia.ott ~/.config/libreoffice/4/user/template
mkdir -p ~/.config/abiword/templates
cp normal.awt-de_DE babylonia.awt ~/.config/abiword/templates
cp angrysearch.conf ~/.config/angrysearch
sudo cp 40-libinput.conf /etc/X11/xorg.conf.d/
sudo cp system.profile /usr/share/abiword-3.0
sudo cp policy.xml /etc/ImageMagick-6
sudo apt-fast -y install fonts-croscore
sudo cp local.conf /etc/fonts
sudo fc-cache -frv
# arc.obt installieren
git clone https://github.com/dglava/arc-openbox.git
obconf-qt --install arc-openbox/arc.obt
obconf-qt --install arc-openbox/arc-darker.obt
sudo rm -R arc-openbox
cp ../artwork/clipboard-dark.png ~/Bilder/artwork/
# ksuperkey
sudo apt-fast -y install git gcc make libx11-dev libxtst-dev pkg-config
git clone https://github.com/hanschen/ksuperkey.git
cd ksuperkey
make
sudo make install
rm -R ksuperkey
exit 0
