#!/bin/sh
pkgname=docfetcher
_name=DocFetcher
pkgver=1.1.25
homedir=$HOME
if [ ! -d "${homedir}/.local/bin" ]; then
  mkdir ${homedir}/.local/bin
fi
cd ${homedir}/.local/bin
wget https://downloads.sourceforge.net/project/${pkgname}/${pkgname}/${pkgver}/${pkgname}-${pkgver}-portable.zip
unzip ${pkgname}-${pkgver}-portable.zip
rm ${pkgname}-${pkgver}-portable.zip
cd ${_name}-${pkgver}
chmod 755 ${_name}-GTK3.sh
sudo ln -s ${homedir}/.local/bin/${_name}-${pkgver}/${_name}-GTK3.sh /usr/local/bin/${pkgname}
if [ ! -d "${homedir}/.local/share/applications" ]; then
  mkdir ${homedir}/.local/share/applications
fi  
cd ${homedir}/.local/share/applications
printf '[Desktop Entry]\nName=DocFetcher\nGenericName=\nComment=Volltextsuche\nExec=/usr/local/bin/docfetcher\nType=Application\nIcon=preferences-system-search\nTerminal=false\nCategories=Utility;' > ${pkgname}.desktop
if ! command -v default-jre &> /dev/null
then
    sudo apt -y install default-jre
fi
if ! command -v default-jre-headless &> /dev/null
then
    sudo apt -y install default-jre-headless
fi
cp /etc/sysctl.conf /tmp
echo "fs.inotify.max_user_watches=32000" >> /tmp/sysctl.conf
sudo cp /tmp/sysctl.conf /etc/sysctl.conf
sed -i 's/Xmx1g/Xmx2g\ -Xmx4g/' $homedir/.local/bin/DocFetcher-${pkgver}/DocFetcher-GTK3.sh
exit 0
