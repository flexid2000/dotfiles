#!/bin/bash
set -e

echo "🚀 Kopiere Autostart-Dateien ..."
mkdir -p ~/.config/autostart
cp autostart/*.desktop ~/.config/autostart

echo "✅ Autostart konfiguriert."

