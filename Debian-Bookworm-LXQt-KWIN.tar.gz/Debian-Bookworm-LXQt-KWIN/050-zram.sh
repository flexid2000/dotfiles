#!/bin/bash
sudo apt-fast -y install systemd-zram-generator
exit 0
