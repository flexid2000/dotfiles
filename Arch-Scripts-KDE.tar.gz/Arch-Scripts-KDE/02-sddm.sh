#!/bin/bash
if [ ! -d $HOME/.config/autostart ]; then
  mkdir -p ~/.config/autostart
fi
if [ ! -d /etc/sddm.conf.d ]; then
  sudo mkdir -p /etc/sddm.conf.d
fi
cp autostart/*.desktop ~/.config/autostart
sudo sed -i 's/#DefaultTimeoutStopSec=90s/DefaultTimeoutStopSec=20s/' /etc/systemd/system.conf
echo kernel.unprivileged_userns_clone = 1 | sudo tee /etc/sysctl.d/00-local-userns.conf
sudo cp confiles/kde_settings.conf /etc/sddm.conf.d
sudo sed -i 's/^timeout.*/timeout=0/' /boot/loader/loader.conf
sudo pacman --needed --noconfirm -S papirus-icon-theme kvantum qt6-multimedia-gstreamer plasma-workspace librsvg

echo "📄 Schreibe theme.conf.user für breeze"
sudo tee /usr/share/sddm/themes/breeze/theme.conf.user > /dev/null <<EOF
[General]
showClock=true
type=color
color=#1e1e2e
EOF

echo "✅ Alles erledigt."

exit 0
