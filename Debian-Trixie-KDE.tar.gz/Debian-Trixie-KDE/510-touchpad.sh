#!/bin/bash

set -e

echo "🎞️ Konfiguriere Touchpad"

sudo sed -i 's/touchpad\ catchall\"/touchpad\ catchall\"\n\tOption\ \"Tapping\"\ \"on\"\n\tOption\ \"ClickMethod\"\ \"clickfinger\"\n\tOption\ \"ScrollMethod\"\ \"twofinger\"/' /usr/share/X11/xorg.conf.d/40-libinput.conf
sudo cp /usr/share/X11/xorg.conf.d/40-libinput.conf /etc/X11/xorg.conf.d/40-libinput.conf

echo "✅ Touchpad konfiguriert."

exit 0
