#!/bin/bash
sudo pacman -R xcursor-breeze
sudo pacman -S --needed --noconfirm qt6-multimedia-gstreamer systemsettings kitemmodels plasma-desktop plasma-workspace
exit 0
