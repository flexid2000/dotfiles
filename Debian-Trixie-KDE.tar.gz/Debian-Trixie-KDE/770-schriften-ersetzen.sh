#!/bin/bash
# =============================================
# Font-Replacement-Skript (Debian/Ubuntu)
# Ersetzt systemweite Fonts durch LaTeX-Varianten
# =============================================

# ---- Konfiguration ----
LOCAL_FONT_DIR="$HOME/.local/share/fonts/texlive"

# Zu deinstallierende systemweite Font-Pakete
SYSTEM_FONTS_TO_REMOVE=(
    "fonts-noto*"
    "fonts-noto-extra*"
    "fonts-roboto*"
    "fonts-inconsolata*"
)

# Zu verlinkende LaTeX-Fonts (Zielname → Quelle)
declare -A TEX_FONTS=(
    ["ebgaramond"]="/usr/share/texlive/texmf-dist/fonts/opentype/public/ebgaramond"
    ["fira"]="/usr/share/texlive/texmf-dist/fonts/opentype/public/fira"
    ["inconsolata"]="/usr/share/texlive/texmf-dist/fonts/opentype/public/inconsolata"
    ["libertinus-fonts"]="/usr/share/texlive/texmf-dist/fonts/opentype/public/libertinus-fonts"
    ["tex-gyre"]="/usr/share/texmf/fonts/opentype/public/tex-gyre"
    ["roboto"]="/usr/share/texlive/texmf-dist/fonts/opentype/google/roboto"
    ["merriweather"]="/usr/share/texlive/texmf-dist/fonts/opentype/sorkin/merriweather"
    ["montserrat"]="/usr/share/texlive/texmf-dist/fonts/opentype/public/montserrat"
    ["noto"]="/usr/share/texlive/texmf-dist/fonts/truetype/google/noto"
    ["noto-emoji"]="/usr/share/texlive/texmf-dist/fonts/truetype/google/noto-emoji"
)

# ---- Sicherheitsabfrage ----
echo "=== WICHTIG ==="
echo "Dieses Skript wird:"
echo "1. Folgende systemweite Fonts deinstallieren:"
printf "   - %s\n" "${SYSTEM_FONTS_TO_REMOVE[@]}"
echo "2. LaTeX-Fonts verlinken nach: $LOCAL_FONT_DIR"
read -p "Fortfahren? [y/N] " confirm
if [[ ! "$confirm" =~ ^[yY] ]]; then
    echo "Abgebrochen."
    exit 1
fi

# ---- LaTeX-Fonts installieren ----
sudo apt-get -y --no-install-recommends install texlive-fonts-extra fonts-texgyre

# ---- 1. Systemweite Fonts deinstallieren ----
echo -e "\n=== Deinstalliere systemweite Fonts ==="
sudo apt purge "${SYSTEM_FONTS_TO_REMOVE[@]}" -y && \
sudo apt autoremove -y

# Systemweiten Font-Cache zurücksetzen
echo -e "\n=== Aktualisiere SYSTEMWEITEN Font-Cache ==="
sudo fc-cache -fv

# ---- 2. Lokale Font-Struktur erstellen ----
echo -e "\n=== Erstelle lokale Font-Verzeichnisse ==="
mkdir -p "$LOCAL_FONT_DIR" || {
    echo "Fehler: Konnte $LOCAL_FONT_DIR nicht anlegen!"
    exit 1
}

# ---- 3. LaTeX-Fonts verlinken ----
echo -e "\n=== Verlinke LaTeX-Fonts ==="
for font in "${!TEX_FONTS[@]}"; do
    src="${TEX_FONTS[$font]}"
    dest="$LOCAL_FONT_DIR/$font"

    if [ -d "$src" ]; then
        # Lösche vorhandenen Link/Ordner
        [ -e "$dest" ] && rm -rf "$dest"

        # Erstelle Symlink
        if ln -sv "$src" "$dest"; then
            echo "✔ $font"
        else
            echo "❌ $font (Fehler beim Verlinken)"
        fi
    else
        echo "⚠ $font (Quellordner nicht gefunden: $src)"
    fi
done

# ---- 4. Font-Caches aktualisieren ----
echo -e "\n=== Aktualisiere Font-Caches ==="
fc-cache -fv "$HOME/.local/share/fonts"
sudo fc-cache -fv

# ---- Erfolgsmeldung ----
echo -e "\n=== Fertig! Übersicht ==="
echo "Verlinkte Fonts in $LOCAL_FONT_DIR:"
ls -l "$LOCAL_FONT_DIR"

echo -e "\nFont-Überprüfung:"
for font in "${!TEX_FONTS[@]}"; do
    if fc-list | grep -qi "$font"; then
        echo "✔ $font wird geladen"
    else
        echo "⚠ $font nicht im Cache gefunden"
    fi
done

echo -e "\nHinweis: Für globale Änderungen ggf. neu starten."
