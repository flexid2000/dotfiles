#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
if [ ! -d $HOME/.local/share/applications ]; then
  mkdir -p ~/.local/share/applications
fi
wget https://www.dropbox.com/scl/fi/yyrz4mydrlseepc2hi4d8/deemix-linux-x64.deb?rlkey=1n8xr29xe446wj997mauq52vf
mv deemix-linux-x64.deb?rlkey=1n8xr29xe446wj997mauq52vf deemix-linux-x64.deb
sudo dpkg -i deemix-linux-x64.deb
sudo apt-fast -y install volumeicon-alsa pipewire pipewire-audio pipewire-alsa gstreamer1.0-pipewire vlc-plugin-pipewire pipewire-pulse pavucontrol-qt
sudo apt-fast -y purge pulseaudio-alsa pulseaudio-bluetooth pulseaudio gstreamer1.0-pulseaudio
systemctl --user --now enable wireplumber.service
sudo apt-fast -t bookworm-backports install yt-dlp
if [ ! -d "$HOME/.config/yt-dlp" ]; then
  mkdir -p ~/.config/yt-dlp
fi
cp confiles/config ~/.config/yt-dlp
exit 0
