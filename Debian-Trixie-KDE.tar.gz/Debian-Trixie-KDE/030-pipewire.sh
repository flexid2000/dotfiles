#!/bin/bash
set -e

echo "🎵 Installiere Pipewire und aktiviere WirePlumber ..."
sudo apt-get install -y \
    pipewire-audio \
    pipewire-alsa \
    pipewire-pulse \
    pipewire-bin \
    pipewire-v4l2 \
    pipewire-audio-client-libraries \
    gstreamer1.0-pipewire \
    vlc-plugin-pipewire \
    yt-dlp

systemctl --user --now enable wireplumber.service

mkdir -p "$HOME/.config/yt-dlp"
cp confiles/config "$HOME/.config/yt-dlp"

echo "✅ Pipewire-Konfiguration abgeschlossen."

