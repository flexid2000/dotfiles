alias upgrade='sudo apt update && sudo apt -y full-upgrade && sudo apt -y autopurge && sudo apt-get clean && flatpak --user update -y && flatpak --user remove --unused -y && flatpak --user uninstall --delete-data -y && flatpak --user list'

