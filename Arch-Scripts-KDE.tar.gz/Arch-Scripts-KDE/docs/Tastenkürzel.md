# Tastenkürzel
| Tastenkombination      | Funktion                          |
| ---------------------- | --------------------------------- |
| Alt + Leertaste		 | App Starter						 |
| Alt + F11              | Fenster in Vollbild               |
| Windows + links        | Fenster nach links kacheln        |
| Windows + Alt + hoch   | Fenster nach links oben kacheln   |
| Windows + Alt + links  | Fenster nach links unten kacheln  |
| Windows + hoch         | Fenster vergrößern         |
| Windows + rechts       | Fenster nach rechts kacheln       |
| Windows + Alt + Rechts | Fenster nach rechts oben kacheln  |
| Windows + Alt + runter | Fenster nach rechts unten kacheln |
| Windows + runter       | Fenster zentrieren        |
| Windows + Q               | Fenster schließen                 |
| Windows + F            | File Manager                      |
| Windows + L            | LibreOffice Writer                |
| Windows + X            | Logout                            |
| Windows + M            | Mailreader Thunderbird            |
| Windows                | Menu                              |
| Windows + D            | Schreibtisch anzeigen             |
| Windows + T            | Terminal                          |
| Windows + W            | Webbrowser Firefox                |
| Windows + ESC          | xkill                             |