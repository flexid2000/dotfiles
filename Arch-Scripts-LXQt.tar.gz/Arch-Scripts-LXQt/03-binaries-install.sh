#!/bin/bash
if [ ! -d $HOME/.local/bin ]; then
  mkdir -p ~/.local/bin
fi
sudo pacman -U binaries/openbox-window-snap-3.6.1-1-x86_64.pkg.tar.zst
paru -S --needed --noconfirm xdotool redshift obconf-qt git xpad xclip picom caffeine-ng redshift-qt libayatana-appindicator meteo-qt obconf-qt xorg-xwininfo nextcloud-client gnome-keyring seahorse fuse2
wget https://github.com/nazeeruddinikram/bashshell/blob/master/winfuncs.sh
sudo mv winfuncs /usr/local/bin
exit 0
