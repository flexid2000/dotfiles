#!/bin/bash
set -e

echo "📦 Installiere zentrale Desktop-Programme ..."
sudo apt-get update
sudo apt-get install -y \
accountsservice acpid alsa-firmware-loaders antiword arandr arj \
aspell-de audacious bleachbit blueman bluetooth bluez-cups bluez-obexd \
bluez-tools cabextract catdoc chromium chromium-l10n cmark conky-std \
cups cups-browsed cups-client cups-common cups-core-drivers \
cups-filters cups-filters-core-drivers cups-ipp-utils cups-pk-helper \
cups-ppdc cups-server-common curl discount dkms evince faad ffmpeg \
ffmpegthumbnailer ffmpegthumbs file-roller firefox-esr-l10n-de flac \
flvstreamer fonts-cantarell fonts-croscore fonts-firacode \
fonts-inconsolata fonts-inter-variable fonts-open-sans fonts-roboto \
fsearch galternatives ghostwriter gimp git grsync gvfs gvfs-backends \
haveged htop hunspell hunspell-de-de hwinfo hyphen-de ibus ibus-gtk4 \
ibus-m17n icoextract-thumbnailer img2pdf info inkscape kcharselect \
kcolorchooser kruler lame libcanberra-pulse libchm-bin libgpod-dev \
libgsf-bin libimage-exiftool-perl libimobiledevice-dev libnotify-bin \
librdf-icalendar-perl libreoffice libreoffice-help-de \
libreoffice-l10n-de librsvg2-bin libwpd-tools \
lightdm-gtk-greeter-settings markdownpart menu-xdg mjpegtools mpv \
mtp-tools mupdf-tools mythes-de netselect-apt numlockx ooo-thumbnailer \
orchis-gtk-theme package-update-indicator papirus-icon-theme \
pavucontrol-qt pdfarranger \
phonon4qt5-backend-gstreamer pipewire-audio plocate plymouth \
plymouth-themes poppler-utils pwgen python3 python3-chardet \
python3-pip python3-pyinotify qt-style-kvantum qt6ct recoll \
redshift-gtk rename simple-scan smplayer soundconverter strawberry \
subversion svgpart synaptic systemd-zram-generator tar \
task-german-desktop task-laptop thunderbird thunderbird-l10n-de \
ttf-bitstream-vera ttf-mscorefonts-installer tumbler \
tumbler-plugins-extra twolame unace unclutter unrar unrtf untex unzip \
vim vlc vorbis-tools wavpack weasyprint xdg-user-dirs-gtk xdotool \
xsltproc zip

echo "✅ Desktop-Basispakete installiert."

